/*==============[ The TesSeRact(TM) Compression System ]================*
 | Copyright (c) 1987-1993, Innovative Data Concepts, Inc.
 | All Rights Reserved.
 |
 | This Library is part of IDC's TesSeRact Development Tools product
 | line. For information about other IDC products, call 1-215-443-9705.
 *-V--------------------------------------------------------------------*
 | $Header:   tcmpdemo.c     200.8   12 Jul 1993 12:24:02  $
 |
 | $Log:   tcmpdemo.c    $
 *-D--------------------------------------------------------------------*
 | TcmpDemo.C : TCOMP User-level Demonstration Program.
 |
 | Syntax:  TCMPDEMO
 *-N-----------------------[ Notes and Caveats ]------------------------*
 | 1) Also requires TCXL library to link
 *======================================================================*/
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
#include <sys\types.h>
#include <sys\stat.h>
#include <TCOMP.h>
#include <TCXLmnu.h>                   /* TCXL menu/window/video        */
#include <TCXLinp.h>                   /* TCXL input                    */
#include <TCXLhlp.h>                   /* TCXL help                     */
#include <TCXLcur.h>                   /* TCXL cursor                   */
#include <TCXLmem.h>                   /* TCXL memory system            */
#include <TCXLfar.h>                   /* TCXL far-memory               */
#include <TCXLcod.h>                   /* TCXL key-codes                */
#include <TCXLnls.h>                   /* TCXL NLS sub-system           */
#include <TCXLsel.h>                   /* TCXL selection/windows/video  */
#include <TCXLent.h>                   /* TCXL entry sub-system         */
#include "demo\tcmpdemo.h"

#define  RESPFILENAME   "$resp.$$$"
#define  TEMPFILENAME   "$temp.$$$"

/*----------------------------[ Global data ]---------------------------*/

IntT  CDC   LeftRow, LeftCol;          /* main menu coords              */
IntT  CDC   RightRow, RightCol;
IntT  CDC   DemoFast = 0;              /* window wait flag              */
ChrT  CDC   inFileName[65];            /* input file name               */
ChrT  CDC   outFileName[65];           /* output file name              */
ChrT  CDC   respFileName[65];          /* response file name            */
IntT  CDC   theMethod;                 /* compression method            */
FILE        *respFile;

/*------------------------[ Function prototypes ]-----------------------*/

VOID  CTYP  DemoCompare(NOARG);        /* Compare demo                  */
VOID  CTYP  DemoCompress(NOARG);       /* Compress demo                 */
VOID  CTYP  DemoDecompress(NOARG);     /* Decompress demo               */
VOID  CTYP  DoCompress(ChrT mode);     /* do the compress/decompress    */


VOID  PAS   DisplayRead(ChrP Nm, DwdT Ln);
VOID  PAS   DisplayWrite(ChrP Nm, DwdT Ln);
VOID  PAS   DisplayEnc(ChrP Nm, DwdT Ln);
VOID  PAS   DisplayDec(ChrP Nm, DwdT Ln);
VOID  CTYP  DoIt(ChrT mode);
VOID  CTYP  Initialize1(NOARG);        /* Initialize TCXL for demo      */
VOID  CTYP  MainMenu(MbldP mp);        /* Display/process main menu     */
VOID  CTYP  MoveBarDn(NOARG);          /* Select next main-menu item    */
VOID  CTYP  NormalExit(NOARG);         /* Normal termination            */
VOID  CTYP  OpenBkgrnd(NOARG);         /* Display demo background       */
VOID  CTYP  PreHelp(NOARG);            /* Help-system "open" function   */
VOID  CTYP  PreMenu1(NOARG);           /* Main-menu "open" function     */
VOID  CTYP  TcompInfo(NOARG);          /* Display TCXL info window      */
VOID  CTYP  PrepItems(NOARG);
VOID  CTYP  FreeItems(NOARG);
ChrP  CTYP  YouSelected(ChrP msg, ChrP str);

/*----------------------------[ Global data ]---------------------------*/

LCL   IbldT CDC   UserItm[5] =         /*- Main Menu Items -------------*/
{  {  NULL, 0, 0, 0, 0, 1, TCMP_COMPRESS,   0, 0,
      NULL, DemoCompress,     NULL, NULL, NULL  },
   {  NULL, 0, 0, 1, 0, 2, TCMP_DECOMPRESS, 0, 0,
      NULL, DemoDecompress,   NULL, NULL, NULL  },
   {  NULL, 0, 0, 2, 0, 3, TCMP_COMPARE,  0, 0,
      NULL, DemoCompare,      NULL, NULL, NULL  },
   {  NULL, 0, 0, 3, 0, 4, 0,      0, 0,
      NULL, TcompInfo,        NULL, NULL, NULL  },
   {  NULL, 0, 0, 4, 0, 5, 0,      0, 0,
      NULL, NULL,             NULL, NULL, NULL  }
};
LCL   MbldT CDC   UserMnu =            /*- Main menu -------------------*/
{  &UserItm[0], 5,  0,  0,  0,  0, MNU_VER, BOX_SNG, LBLUE|_BLUE,
   LBLUE|_BLUE, LCYAN|_BLUE, WHITE|_BLUE, 0, BLUE|_LGREY,
   1, PreMenu1,  0, 19, 1, 0xFF, 0xFF, 0xFF
};

#define  NUM_METHODS 6
LCL   ChrP  CDC   methods[NUM_METHODS+1]; /* compression methods table  */

/*========================[ The TCOMP Compress Demo ]===================*
 |
 *----------------------------------------------------------------------*/

VOID  CTYP  DemoCompare(NOARG)         /* Compare demo                  */
{
   DwdT  Ln;
   WrdT  Size1, Size2;
   HdlT  File1, File2;
   BytP  Buf1, Buf2;
   ChrP  m;

   MouPush(MOU_FULL);                  /* full mouse support            */

   if(!WpopUp(CNT_CNT, 5, 9, 17, 70,   /* pop up the demo window        */
      3, WHITE|_BLUE, WHITE|_BLUE))
      ErrorExit(1);                    /* windowing error!              */
   AddShadow();                        /* add a shadow                  */

   Wputf(MsgPeek(TCMP_0012));
   HlpSet(TCMP_FILEPICK);              /* set help category             */
   SelParOn();
   SelDirOn();
   m = MsgRead(TCMP_0013);
   strcpy(inFileName,                  /* file select                   */
      YouSelected(m,
      SelFile((WrdT)(LeftRow + 2), (WrdT)(LeftCol - 17),
         (WrdT)(LeftRow + 15), (WrdT)(LeftCol + 45), 0,
         LCYAN|_RED, LGREY|_RED, RED|_LGREY, 1, "*.*", _VFVCP(AddShadow))));
   FreeN(m);
   if(0 == strlen(inFileName))
      goto quit;

   Wputf(MsgPeek(TCMP_0014));
   HlpSet(TCMP_FILEPICK);              /* set help category             */
   SelParOn();
   SelDirOn();
   m = MsgRead(TCMP_0015);
   strcpy(outFileName,                 /* file select                   */
      YouSelected(m, SelFile((WrdT)(LeftRow + 4), (WrdT)(LeftCol - 17), 
         (WrdT)(LeftRow + 17), (WrdT)(LeftCol + 45), 0, LCYAN|_RED,
      LGREY|_RED, RED|_LGREY, 1, "*.*", _VFVCP(AddShadow))));
   FreeN(m);
   if(0 == strlen(outFileName))
      goto quit;
   Buf1 = AllocNT(BytP, 4096);
   memset(Buf1, 0, 4096);
   Buf2 = AllocNT(BytP, 4096);
   memset(Buf2, 0, 4096);
   if(-1 == (File1 = open(inFileName, O_RDONLY|O_BINARY, S_IREAD)))
      goto done;
   if(-1 == (File2 = open(outFileName, O_RDONLY|O_BINARY, S_IREAD)))
      goto done;
   Ln = 0L;
   Size1 = (WrdT)read(File1, Buf1, 4096);

   do
   {  Size2 = (WrdT)read(File2, Buf2, 4096);
      if(Size1 != Size2)
      {  Wputf(MsgPeek(TCMP_0016));
         goto done;
      }
      Ln += Size1;
      Wputf(MsgPeek(TCMP_0017), Ln);
      if(0 != memcmp(Buf1, Buf2, Size1))
      {  Wputf(MsgPeek(TCMP_0018));
         goto done;
      }
      Size1 = (WrdT)read(File1, Buf1, 4096);
   }  while(Size1 > 0);
   Wputf(MsgPeek(TCMP_0019));

done:
   FreeN(Buf1);
   FreeN(Buf2);
   PressAKey1(10, 5);                     /* prompt for a key          */

quit:
   Wclose();                           /* close window                  */
   MouPop();                           /* restore mouse                 */
   MoveBarDn();                        /* select next main-menu item    */
}

VOID  CTYP  DemoCompress(NOARG)        /* Compress demo                 */
{
   DoCompress('C');
}

VOID  CTYP  DemoDecompress(NOARG)      /* Decompress demo               */
{
   DoCompress('D');
}

VOID  CTYP  DoCompress(ChrT mode)      /* do the compress/decompress    */
{
   ChrP  cp, m;
   WdfP  w;

   MouPush(MOU_FULL);                  /* full mouse support            */

   if(!WpopUp(CNT_CNT, 5, 9, 17, 70,   /* pop up the demo window        */
      3, WHITE|_BLUE, WHITE|_BLUE))
      ErrorExit(1);                    /* windowing error!              */
   AddShadow();                        /* add a shadow                  */
   w = WctlAct;

   HlpSet(TCMP_METHOD);                   /* set help category              */
   Wputf(MsgPeek(TCMP_0020));
   m = MsgRead(TCMP_0021);
   YouSelected(m,
      methods[theMethod = SelTxt(2, 3, YELLOW|_BLUE, methods, 0)]);
   FreeN(m);
   Wputf(MsgPeek(TCMP_0022));
   if(theMethod < 0)
      goto quit;

   EvtClear();
   m = MsgRead(TCMP_0023);
   Wputf(m, ((mode == 'C') ? MsgPeek(TCMP_0024) : MsgPeek(TCMP_0025)));
   FreeN(m);
   HlpSet(TCMP_FILEPICK);                 /* set help category             */
   SelParOn();
   SelDirOn();
   if((theMethod == 5) && (mode == 'C'))
   {  respFile = fopen(RESPFILENAME, "w");
      do
      {  cp = SelFile((WrdT)(LeftRow + 4), (WrdT)(LeftCol - 17),
            (WrdT)(LeftRow + 17), (WrdT)(LeftCol + 45), 0,
            LCYAN|_RED, LGREY|_RED, RED|_LGREY, 1, "*.*", _VFVCP(AddShadow));
         if(TcxlErr != W_ESCPRESS)
         {  strcpy(inFileName, YouSelected(MsgPeek(TCMP_0026), cp));
            fputs(inFileName, respFile);
            fputc('\n', respFile);
         }
      }  while(TcxlErr != W_ESCPRESS);
      fclose(respFile);
   }
   else
   {  cp = SelFile((WrdT)(LeftRow + 4), (WrdT)(LeftCol - 17),
         (WrdT)(LeftRow + 17), (WrdT)(LeftCol + 45), 0,
         LCYAN|_RED, LGREY|_RED, RED|_LGREY, 1, "*.*", _VFVCP(AddShadow));
      if(TcxlErr != W_ESCPRESS)
         strcpy(inFileName, YouSelected(MsgPeek(TCMP_0026), cp));
      else
         goto quit;
   }
   WctlAct = w;

   if((theMethod != 5) || (mode == 'C'))
   {  Wputf(MsgPeek(TCMP_0028));
      strcpy(outFileName, "            ");
      EntDef(LMAGENTA|_MAGENTA, WHITE|_LGREY, 1);
      EntFld(5, 28, outFileName, "FFFFFFFFFFFF", FLD_UPR|FLD_LJS|FLD_TRM,
         1, FLD_INI, NULL, TCMP_OUTFILE);
      EntGet(1);
      if(TcxlErr == W_ESCPRESS)
         goto quit;
   }

   if(theMethod == 5)
   {  theMethod = 4;                   /* use LZDHUF                   */
      if(mode == 'C')
      {  BuildIt(RESPFILENAME, TEMPFILENAME, DisplayRead);
         strcpy(inFileName, TEMPFILENAME);
         DoIt(mode);
         unlink(RESPFILENAME);
      }
      else
      {  strcpy(outFileName, TEMPFILENAME);
         DoIt(mode);
         UnBuild(outFileName, DisplayWrite);
      }
      unlink(TEMPFILENAME);
   }
   else
      DoIt(mode);

   PressAKey1(10, 5);                     /* prompt for a key          */

quit:
   Wclose();                           /* close window                  */
   MouPop();                           /* restore mouse                 */
   MoveBarDn();                        /* select next main-menu item    */
}

VOID  CTYP  DoIt(ChrT mode)
{
   DwdT End;

   if(TCompInit() == TCOMP_MEMFAIL)    /* memory allocation error       */
      ErrorExit(2);
   if(mode == 'C')
      TCmpDsp = DisplayEnc;
   else
      TCmpDsp = DisplayDec;
   TCmpFlg = CMP_T_D|CMP_F_D;
   TCmpIFl = inFileName;
   TCmpOFl = outFileName;
   TCompStart();

   switch(theMethod)
   {  case 0:
         if(mode == 'C')
            EncodeLZW();
         else
            DecodeLZW();
         break;
      case 1:
         if(mode == 'C')
            EncodeLZS();
         else
            DecodeLZS();
         break;

      case 2:
         if(mode == 'C')
            EncodeLZA();
         else
            DecodeLZA();
         break;

      case 3:
         if(mode == 'C')
            EncodeLZH();
         else
            DecodeLZH();
         break;

      case 4:
         if(mode == 'C')
            EncodeLZD();
         else
            DecodeLZD();
         break;
   }

   End = TCompEnd();
   TCompTerm();
   WscrBox(7, 3, 10, 59, 1, DIR_UP);
   Wputf(MsgPeek(TCMP_0029), End);
}

/*========================[ Various display routines ]==================*
 |
 *----------------------------------------------------------------------*/

VOID PAS  DisplayRead(ChrP Nm, DwdT Ln)
{
   LCL ChrT Nm1[65] = {'\0'};

   if(0 != strcmp(Nm, Nm1))
   {  strcpy(Nm1, Nm);
      WscrBox(7, 3, 10, 59, 1, DIR_UP);
   }
   Wputf(MsgPeek(TCMP_0030), Nm, Ln);
}

VOID PAS  DisplayWrite(ChrP Nm, DwdT Ln)
{
   LCL ChrT Nm1[65] = {'\0'};

   if(0 != strcmp(Nm, Nm1))
   {  strcpy(Nm1, Nm);
      WscrBox(7, 3, 10, 59, 1, DIR_UP);
   }
   Wputf(MsgPeek(TCMP_0031), Nm, Ln);
}

VOID PAS  DisplayEnc(ChrP Nm, DwdT Ln)
{
   LCL ChrT Nm1[65] = {'\0'};

   if(0 != strcmp(Nm, Nm1))
   {  strcpy(Nm1, Nm);
      WscrBox(7, 3, 10, 59, 1, DIR_UP);
   }
   Wputf(MsgPeek(TCMP_0032), Ln);
}

VOID PAS  DisplayDec(ChrP Nm, DwdT Ln)
{
   LCL ChrT Nm1[65] = {'\0'};

   if(0 != strcmp(Nm, Nm1))
   {  strcpy(Nm1, Nm);
      WscrBox(7, 3, 10, 59, 1, DIR_UP);
   }
   Wputf(MsgPeek(TCMP_0033), Ln);
}

VOID  CTYP  PrepItems(NOARG)
{
   REG IntT i;

   MnuPrepMsg(&UserMnu, TCMP_0002, 0);
   for(i = 0; i < NUM_METHODS; i++)
      methods[i] = MsgRead(TCMP_0007 + i);
   methods[i] = NULL;
}

VOID  CTYP  FreeItems(NOARG)
{
   REG IntT i;

   MnuFreeMsg(&UserMnu);
   for(i = 0; i < NUM_METHODS; i++)
      FreeN(methods[i]);
}

/*===============[ Initialize TCXL for the demo program ]===============*/

VOID  CTYP  Initialize1(NOARG)
{
   MsgHlpName("TCMPDEMO.MSG");
   TcxlInit();                         /* general initialization        */
   KextOff();                          /* no extended key BIOS          */
   CurPush(CUR_HID, CUR_NOR, 0, 0);    /* save the cursor state, hide   */
                                       /*    and home the cursor        */
   HlpDef("ADVDEMO.HLP", Key_F1,       /* initialize help system,       */
      YELLOW|_RED, YELLOW|_RED,        /*  help key = [F1]              */
      LRED|_RED, WHITE|_RED, RED|_LGREY, BOX_DBL, _VFVCP(PreHelp));

   LeftRow = ((VidDep - 1) / 2) - 5;   /* set up display coordinates    */
   RightRow = (IntT)(LeftRow + 6);
   LeftCol = ((VidWid - 1) / 2) - 9;
   RightCol = (IntT)(LeftCol + 19);

   PrepItems();
}  /* Initialize() */

/*==[ Main background, program title and system information windows ]===*/


VOID  CTYP  OpenBkgrnd(NOARG)
{
                                       /* demo background window        */
   if(ERR_ARG == Wopen(0, 0, VidDep - 2, VidWid - 1, 5, 0, LGREEN|_GREEN))
      ErrorExit(1);                    /* windowing error!              */

   WsetFil('\xB0');                    /* bottom status bar, fancy fill */
   if(ERR_ARG == Wopen(VidDep - 1, 0, VidDep - 1, VidWid - 1, 5, 0,
         LGREY|_RED))
      ErrorExit(1);                    /* windowing error!              */

   Wprts(0, 1, LGREY|_RED, MsgPeek(TCMP_0034));
   WprtCen(0, LGREY|_RED, MsgPeek(TCMP_0035));
   Wprtrj(0, MsByt(VidWid - 2), LGREY|_RED, MsgPeek(TCMP_0036));
   WsetFil(' ');                       /* blank fill again              */
                                       /* program title pop-up          */
   if(!WpopUp(CNT_HOR, 0, 12, 4, 66, 0, LRED|_MAGENTA, LRED|_MAGENTA))
      ErrorExit(1);                    /* windowing error!              */

   AddShadow();                        /* add a shadow, display text    */
   WprtCen(0, WHITE|_MAGENTA, MsgPeek(TCMP_0037));
   WprtCen(2, LCYAN|_MAGENTA, MsgPeek(TCMP_0038));
}  /* OpenBkgrnd() */

/*================[ Define and process a main demo menu ]===============*
 | First, push global help category onto help stack, so that when [F1] is
 | pressed while the selection bar is on an item without help, the global
 | help category will be used. Build the main menu defined by the Mbld
 | object at <mp> and process it
 *----------------------------------------------------------------------*/

VOID  CTYP  MainMenu(MbldP mp)
{
   HlpPush(TCMP_GLOBAL);                  /* push global help catagory     */

   MnuBuild(mp);                       /* define the main menu          */
   if(MnuGet() == -1)                  /* process the menu              */
      if(TcxlErr > W_ESCPRESS)
         ErrorExit(1);                 /* window error                  */

   HlpDrop();                          /* pop help category off stack   */
}  /* MainMenu() */

/*===========[ Move the selection bar down in the Main Menu ]===========*
 | Select the next menu item by getting the address of the current menu,
 | then setting the current tag-id to the tag-id of the next menu item.
 | If we had had not numbered the menu item tag-ids sequentially, this
 | would not work.
 *----------------------------------------------------------------------*/

VOID  CTYP  MoveBarDn(NOARG)
{
   REG TagT t = IdfTag(ItmCur());
   if(t < 10)                          /* from main menu only           */
      ItmNxt((TagT)(t + 1));           /* select next item              */
}  /* MoveBarDn() */

/*========================[ Normal termination ]========================*
 | Restore the original screen and cursor before exiting to DOS with
 | ERRORLEVEL 0.
 *----------------------------------------------------------------------*/

VOID  CTYP  NormalExit(NOARG)
{
   WcloseAll();
   MouPop();                           /* restore the mouse             */
   CurPop();                           /* restore the cursor            */
   FreeItems();
   exit(0);                            /* _TcxlTerm() will clean up     */
}  /* NormalExit() */

/*=====================[ Main menu "open" function ]====================*
 | Called when the main demo menu window is opened.
 *----------------------------------------------------------------------*/

VOID  CTYP  PreMenu1(NOARG)
{
   AddShadow();                        /* add a shadow                  */
}  /* PreMenu1() */

/*=======================[ Help "open" function ]=======================*
 | Called when the user presses the help key and the help window is
 | opened.
 *----------------------------------------------------------------------*/

VOID  CTYP  PreHelp(NOARG)
{
   AddShadow();                        /* add a shadow to window        */
}  /* PreHelp() */

/*=========[ Display window of information about TCXL and IDC ]=========*
 | Called from the [I]nformation item in the main demo menu
 *----------------------------------------------------------------------*/

VOID  CTYP  TcompInfo(NOARG)
{
   HlpAdd(TCMP_GLOBAL);                   /* save old, set new help        */
   HlpGet();
   HlpDrop();
}  /* TcompInfo() */

/*---------[ Display the selected string or an error message ]----------*
 |
 *----------------------------------------------------------------------*/

ChrP  CTYP  YouSelected(ChrP msg, ChrP str)
{
   ChrT buf[80];

   if(TcxlErr)                         /* error message                 */
   {  str = NULL;
      if(TcxlErr != W_ESCPRESS)
      {  WscrBox(7, 3, 10, 59, 1, DIR_UP);
         Wputf(MsgPeek(TCMP_0040), WerrMsg());
      }
   }
   else                                /* selected string               */
      Wputf(MsgSave(TCMP_0041, buf), msg, str);
   return (str);
}

/*=================[ The TCXL User-Level Demo Program ]=================*/

RegT CDC main(void)
{
   Initialize1();                      /* initialize TCXL               */
   OpenBkgrnd();                       /* build screen                  */
   UserMnu.mbgr = MsByt(LeftRow);      /* set main-menu position        */
   UserMnu.mbgc = MsByt(LeftCol);
   UserMnu.menr = MsByt(RightRow);
   UserMnu.menc = MsByt(RightCol);
   MainMenu(&UserMnu);                 /* display/process main menu     */
   NormalExit();                       /* we're done                    */
   return(0);                          /* *** never executed ***        */
}
