/*=====[ The TesSeRact(TM) CXL User Interface Development System ]======*
 | Copyright (c) 1987-1993, Innovative Data Concepts, Inc.
 | All Rights Reserved.
 |
 | This Library is part of IDC's TesSeRact Development Tools product
 | line. For information about other IDC products, call 1-215-443-9705.
 *-V--------------------------------------------------------------------*
 | $Header:   alltui.c     610.16   01 Sep 1993 11:32:12  $
 |
 | $Log:   alltui.c    $
 *-D--------------------------------------------------------------------*
 | ALLTUI.C : TCXL demo using TesSeRact User Interface (TUI)
 *-N-----------------------[ Notes and Caveats ]------------------------*
 | 
 *======================================================================*/

#include <tcxltui.h>
#include "demo\allTCXL.h"

/*============================[ Prototypes ]============================*/

LCL   VOID  CTYP  ViewFile(NOARG);
VOID  CTYP  CheckIt(TagT tag);
VOID  CTYP  CheckIt1(NOARG);
VOID  CTYP  CheckIt2(NOARG);
VOID  CTYP  CheckIt3(NOARG);
VOID  CTYP  CheckIt4(NOARG);
VOID  CTYP  CheckIt5(NOARG);
VOID  CTYP  CheckIt6(NOARG);

VOID  CTYP  MoveUp(NOARG);
VOID  CTYP  MoveDown(NOARG);
VOID  CTYP  MoveLeft(NOARG);
VOID  CTYP  MoveRight(NOARG);
VOID  CTYP  MovePageUp(NOARG);
VOID  CTYP  MovePageDown(NOARG);
VOID  CTYP  MovePageLeft(NOARG);       
VOID  CTYP  MovePageRight(NOARG);
VOID  CTYP  MoveHome(NOARG);
VOID  CTYP  MoveEnd(NOARG);
VOID  CTYP  MoveTop(NOARG);
VOID  CTYP  MoveBot(NOARG);

LCL   VOID  CTYP  DlgOK(NOARG);
LCL   VOID  CTYP  DlgCan(NOARG);
LCL   VOID  CTYP  ProdLst(NOARG);
LCL   VOID  CTYP  ProdCnt(NOARG);
LCL   VOID  CTYP  ProdStp(NOARG);
LCL   VOID  CTYP  DlgShip(NOARG);
LCL   VOID  CTYP  DlgDisk(NOARG);
LCL   VOID  CTYP  DlgPrnt(NOARG);


/*============================[ Local data ]============================*/

ChrT  filepath[80];
ChrT  deftitle[80] = "Viewer 1.0";
WndT  mwhandle; 
WrdT  Vrow = NEG1, Vcol = NEG1;
WndT  MainWh;

ChrP  CDC   EdTxt1 = NULL;             /* Editor demo text              */
ChrP  CDC   EdTxt2 = NULL;             /* Editor demo text              */

INFO1 TcxlI[] =               /* text displayed in Information screen   */
{  {  1, WHITE|_RED, NULL  },
   {  2, WHITE|_RED, NULL  },
   {  3, WHITE|_RED, NULL  },
   {  5, BLACK|_RED, NULL  },
   {  6, BLACK|_RED, NULL  },
   {  7, BLACK|_RED, NULL  }
};

FtypT types[] =                        /* Types for file-open dialog    */
{  {  "C Source(*.C)",  "*.c" },
   NULL_FTYP
};

LCL   ChrP  ProdPicked;
LCL   WrdT  Quantity;
LCL   WrdT  ShipType;
LCL   WrdT  DiskType;
LCL   WrdT  PrntType;
LCL   FlgT  Cancel;

/*==========================[ Window objects ]==========================*/

TuiWinT  MainWin  =                    /*- Main window -----------------*/
{  "TUI Sample Demonstration",         /* Title                         */
   (TWIN_FUL|TWIN_SYS|TWIN_TTL|TWIN_MIN|
   TWIN_MAX|TWIN_SIZ|TWIN_HSC|TWIN_VSC),  /* Window flags               */
   NEG1, NEG1, NEG1, NEG1,             /* Main window position, size    */
   NEG1, NEG1,                         /* Virtual depth, width          */
   SYS_MENU1,                          /* Attached system menu          */
   MID_MENU,                           /* Attached main menu            */
   KID_KEY,                            /* Attached Accelerators         */
   MOU_FULL,                           /* Mouse Ptr                     */
   CUR_SHO                             /* Cursor Type                   */
};

TuiWinT  ViewWin  =                    /*- Viewer window ---------------*/
{  deftitle,                           
   (TWIN_NOR|TWIN_SYS|TWIN_TTL|TWIN_MIN|
   TWIN_MAX|TWIN_SIZ|TWIN_HSC|TWIN_VSC),
   NEG1, NEG1, NEG1, NEG1,             
   NEG1, NEG1,                         
   SYS_MENU2,
   NULL_TAG,
   KID_VIEW,
   MOU_FULL,                           /* Mouse Ptr                     */
   CUR_SHO                             /* Cursor Type                   */
};

TuiWinT LoadWin =
{  deftitle,
   TWIN_NOR,
   13, 30, 19, 5,
   NEG1, NEG1,
   NULL_TAG,
   NULL_TAG,
   NULL_TAG,
   MOU_FULL|MOU_HOUR,CUR_HID
};

TuiWinT EntWin =
{  NULL,
   (TWIN_NOR|TWIN_SYS|TWIN_TTL|TWIN_MDL),
   2, 2, 74, 22, 
   NEG1, NEG1,
   SYS_MENU2,
   NULL_TAG,
   NULL_TAG,
   MOU_FULL|MOU_HOUR,0
};

/*=============================[ Help List ]============================*/

TuiHlpT  HlpLst[] =                    /*- Help List -------------------*/
{  {  MID_FILE,      HID_FILE       }, /* Tag ID, message/help number   */
   {  MID_DEFAULTS,  HID_DEFAULTS   },
   {  MID_OPTIONS,   HID_OPTIONS    },
   {  MID_QUIT,      HID_QUIT       },
   {  MID_HELP,      HID_HELP       },

   {  MID_VIEW,      HID_VIEW       },
   {  MID_SAVE,      HID_SAVE       },
   {  MID_ORDER,     HID_ORDER      },
   {  MID_NEW,       HID_NEW        },
   {  MID_DIR,       HID_DIR        },
   {  MID_EXE,       HID_EXE        },
   {  MID_SHELL,     HID_SHELL      },
   {  MID_QUIT1,     HID_QUIT1      },

   {  MID_TAB,       HID_TAB        },
   {  MID_TABX,      HID_TABX       },
   {  MID_INS,       HID_INS        },
   {  MID_IND,       HID_IND        },
   {  MID_WRAP,      HID_WRAP       },
   {  MID_SAVED,     HID_SAVED      },

   {  MID_BACK,      HID_BACK       },
   {  MID_BOX,       HID_BOX        },
   {  MID_LOADO,     HID_LOADO      },
   {  MID_SAVEO,     HID_SAVEO      },

   {  MID_QNO,       HID_QNO        },
   {  MID_QYES,      HID_QYES       },

   NULL_HLP                            /* End-of-list terminator        */
};

/*===========================[ Action Lists ]===========================*/

TuiActT  ActLst[] =                    /*- Main (global) Action list ---*/
{  {  MID_HELP,   _TuiHelp       },    /* Tag ID, Action function       */
   {  MID_VIEW,   ViewFile       },
   {  MID_SAVE,   DoNothing      },
   {  MID_ORDER,  EntryDemo      },
   {  MID_NEW,    DoNothing      },
   {  MID_DIR,    ShowDir        },
   {  MID_EXE,    DoNothing      },
   {  MID_SHELL,  DoNothing      },
   {  MID_QUIT1,  TuiClose       },
   {  MID_TAB,    DoNothing      },
   {  MID_TABX,   CheckIt1       },
   {  MID_INS,    CheckIt2       },
   {  MID_IND,    CheckIt3       },
   {  MID_WRAP,   CheckIt4       },
   {  MID_SAVED,  DoNothing      },
   {  MID_BACK,   CheckIt5       },
   {  MID_BOX,    CheckIt6       },
   {  MID_LOADO,  DoNothing      },
   {  MID_SAVEO,  DoNothing      },
   {  MID_QNO,    DoNothing      },
   {  MID_QYES,   TuiClose       },
   {  WV_EXIT,    TuiClose       },
   {  WV_UP,      MoveUp         },
   {  WV_DOWN,    MoveDown       }, 
   {  WV_LEFT,    MoveLeft       }, 
   {  WV_RIGHT,   MoveRight      },
   {  WV_PGUP,    MovePageUp     }, 
   {  WV_PGDN,    MovePageDown   }, 
   {  WV_PGLFT,   MovePageLeft   },
   {  WV_PGRGT,   MovePageRight  },
   {  WV_D_HOME,  MoveTop        }, 
   {  WV_D_END,   MoveBot        },
   {  WV_HOME,    MoveHome       }, 
   {  WV_END,     MoveEnd        },
   NULL_ACT                            /* End-of-list terminator        */
};

TuiActT  DlgAct1[] =                   /*- Dialog Action list ----------*/
{  {  DID_SELP1,  DlgOK    },
   {  DID_SELP2,  DlgCan   }, 
   {  DID_SELP3,  ProdLst  }, 
   {  DID_SELP4,  ProdCnt  }, 
   {  DID_SELP5,  ProdStp  }, 
   NULL_ACT                            /* End-of-list terminator        */
};

TuiActT  DlgAct2[] =                   /*- Dialog Action list ----------*/
{  {  DID_SELSA,  DlgOK    },
   {  DID_SELS2,  DlgShip  }, 
   {  DID_SELS3,  DlgShip  }, 
   {  DID_SELS4,  DlgShip  }, 
   {  DID_SELS5,  DlgShip  }, 
   {  DID_SELS6,  DlgShip  }, 
   {  DID_SELS7,  DlgShip  }, 
   {  DID_SELS8,  DlgShip  }, 
   {  DID_SELS9,  DlgShip  }, 
   NULL_ACT                            /* End-of-list terminator        */
};

TuiActT  DlgAct3[] =                   /*- Dialog Action list ----------*/
{  {  DID_SELD6,  DlgOK    },
   {  DID_SELD7,  DlgCan   }, 
   {  DID_SELD2,  DlgDisk  }, 
   {  DID_SELD3,  DlgDisk  }, 
   {  DID_SELD4,  DlgDisk  }, 
   {  DID_SELD5,  DlgDisk  }, 
   NULL_ACT                            /* End-of-list terminator        */
};

TuiActT  DlgAct4[] =                   /*- Dialog Action list ----------*/
{  {  DID_SELPR1, DlgPrnt  },
   {  DID_SELPR2, DlgPrnt  }, 
   {  DID_SELPR3, DlgPrnt  }, 
   {  DID_SELPR4, DlgPrnt  }, 
   {  DID_SELPR5, DlgPrnt  }, 
   {  DID_SELPR6, DlgPrnt  }, 
   {  DID_SELPR7, DlgOK    }, 
   {  DID_SELPR8, DlgCan   }, 
   NULL_ACT                            /* End-of-list terminator        */
};

/*===========================[ Resource List ]==========================*/

TuiResT  ResLst[] =                    /*- Resource List ---------------*/
{  {  MID_MENU,                        /* Main menu                     */
      NULL,
      "AllTui",
      NULL
   },
   {  KID_KEY,                         /* Global keys                   */
      NULL,
      "AllTuiKey",
      NULL
   },
   {  KID_VIEW,                        /* Viewer keys                   */
      NULL,
      "ViewKeys",
      NULL
   },
   {  DID_DLG1,                        /* Dialog                        */
      NULL,
      "SelProd",
      &DlgAct1[0]
   },
   {  DID_DLG2,                        /* Dialog                        */
      NULL,
      "SelShip",
      &DlgAct2[0]
   },
   {  DID_DLG3,                        /* Dialog                        */
      NULL,
      "SelDisk",
      &DlgAct3[0]
   },
   {  DID_DLG4,                        /* Dialog                        */
      NULL,
      "SelPrnt",
      &DlgAct4[0]
   },
   NULL_RES                            /* End-of-list terminator        */
};

/*=============================[ Routines ]=============================*/

/*----------------[ Read string data from message file ]----------------*/

VOID  CTYP  PrepItems(NOARG)
{
   REG IntT i;

   EdTxt1 = MsgRead(MSG_EDTXT1);
   EdTxt2 = MsgRead(MSG_EDTXT2);
   for(i = 0; i < 6; i++)
      TcxlI[i].Str = MsgRead(MSG_EDTXT3 + i);

   EntPrepMsg(&DemFrm, MSG_PMT0, MSG_FMT0);

   ReadValue(TRUE,  MSG_PROD1);
   ReadValue(FALSE, MSG_SHIP1);
   DiskArr = ReadArray(MSG_DISK1);
   PrntArr = ReadArray(MSG_PRNT1);
}

/*-----------------[ Free memory used by message data ]-----------------*/

VOID  CTYP  FreeItems(NOARG)
{
   REG IntT i;

   FreeN(EdTxt1);
   FreeN(EdTxt2);
   for(i = 0; i < 6; i++)
      FreeN(TcxlI[i].Str);

   EntFreeMsg(&DemFrm);
   FreeArray(ProdArr);
   FreeN(PriceArr);
   FreeArray(ShipArr);
   FreeN(ShipVal);
   FreeArray(DiskArr);
   FreeArray(PrntArr);
}

/*-------------[ Move cursor/scroll based on movement tag ]-------------*/

VOID  CTYP  MoveCurs(TagT typ)
{
   WdfP     w = TctlWin;
   WrdT     a,b,x,y;
   VposT    or, o;

   a = WdfSizR(w);
   b = WdfShaR(w);
   x = WdfSizC(w);
   y = WdfShaC(w);

   VposW(o)  = WdfWinW(w);
   VposW(or) = WdfOrgW(w);

   switch(typ)
   {  case  TUI_SB_LINEUP:
         if(VposR(o) > VposR(or))
            VposR(o)--;
         else if(VposR(or) > 0)
            VposR(or)--;
         break;

      case  TUI_SB_LINEDOWN:
         if(VposR(o) < (a - 1 + VposR(or)))
            VposR(o)++;
         else if(VposR(or) < (b - a + 1))
            VposR(or)++;
         break;

      case  TUI_SB_LINERIGHT:
         if(VposC(o) < (x - 1 + VposC(or)))
            VposC(o)++;
         else if(VposC(or) < (y - x + 1))
            VposC(or)++;
         break;

      case  TUI_SB_LINELEFT:
         if(VposC(o) > VposC(or))
            VposC(o)--;
         else if(VposC(or) > 0)
            VposC(or)--;
         break;

      case  TUI_SB_PAGEUP:
         if(VposR(or) > a)
            VposR(or) -= a;
         else
            VposR(o) = 0;
         break;

      case  TUI_SB_PAGEDOWN:
         VposR(or) += a;
         if(VposR(or) > (b - a + 1))
            VposR(or) = (b - a + 1);
         break;

      case  TUI_SB_PAGELEFT:
         if(VposC(or) > x)
            VposC(or) -= x;
         else
            VposC(o) = 0;
         break;

      case  TUI_SB_PAGERIGHT:
         VposC(or) += x;
         if(VposC(or) > (y - x + 1))
            VposC(or) = (y - x + 1);
         break;

      case  TUI_SB_LEFT:
         VposC(o) = 0;
         break;

      case  TUI_SB_RIGHT:
         VposC(o) = y;
         break;

      case  TUI_SB_TOP:
         VposW(or) = 0;
         break;

      case  TUI_SB_BOTTOM:
         VposR(o) = b;
         VposC(o) = 0;
         break;

      }

   if(VposW(or) != WdfOrgW(w))         /* position cursor and window    */
      WinPositionV(w, VposW(or));
   else if(VposW(o) != WdfWinW(w))
      WcurSetV(w, o);
#if (_TCXL_gui_ > 0)
   _SetScrlBar(w);                     /* update scroll bars            */
#endif
}

/*-------------------[ Make title for Viewer window ]-------------------*/

VOID CTYP ParseTitle(WndT wh, ChrP path)
{
   ChrT buf[80];

   MsgSave(MSG_VIEWTTL, buf);
   _Scat(buf, " - ");
   _Scat(buf,strupr(path));
   TuiTitle(wh, buf);
}

/*==========================[ Action objects ]==========================*/

LCL  VOID  CTYP  DlgOK(NOARG)          /* Action for OK button          */
{
   if(TrspPRC)
   {  TrspFlg = TACT_END;
      Cancel = FALSE;
   }
}

LCL  VOID  CTYP  DlgCan(NOARG)         /* Action for Cancel button      */
{
   if(TrspPRC)
   {  TrspFlg = TACT_END;
      Cancel = TRUE;
   }
}

LCL  VOID  CTYP  ProdStp(NOARG)
{
   if(TrspPRC)
   {  ProdPicked = NULL;
      TrspFlg = TACT_END;
   }      
}

LCL  VOID  CTYP  ProdLst(NOARG)
{
   ChrT   Picked[80];
   ChrI   s;
   ChrP   p = NULL;
   IntT   i, len;

   if(TrspINI)
   {  TuiDliSetLst(DID_SELP3, ProdArr);
      ProdPicked = NULL;
   }
   else if(TrspPRC)
   {  TuiDliGetStr(DID_SELP3, Picked, -1);
      for(i = 0, s = ProdArr; *s != NULL; s++, i++)
      {  p = *s;
         len = (IntT)_Slen(p);
         if(strncmp(p, Picked, len) == 0)
            break;
      }
      if(*s != NULL)
         ProdPicked = p;
   }
}

LCL  VOID  CTYP  ProdCnt(NOARG)
{
   if(TrspINI)
   {  Quantity = 1;
      TuiDliSetNum(DID_SELP4, Quantity, FALSE);
   }
   else if(TrspTRM)
      TuiDliGetNum(DID_SELP4, &Quantity, FALSE);
}

LCL  VOID  CTYP  DlgShip(NOARG)
{
   LCL FlgT f = TRUE;

   if(TrspINI)
   {  if(f == TRUE)
      {  ShipType = 0;
         TuiDliSetFlg(DID_SELS2, TRUE);
         f = FALSE;
      }
   }
   else if(TrspPRC)
   {  if(TrspBON)
         ShipType = (WrdT)(TrspTag - DID_SELS2);
   }
   else if(TrspTRM)
      f = TRUE;
}

LCL  VOID  CTYP  DlgDisk(NOARG)
{
   LCL FlgT f = TRUE;

   if(TrspINI)
   {  if(f == TRUE)
      {  DiskType = 0;
         TuiDliSetFlg(DID_SELD2, TRUE);
         f = FALSE;
      }
   }
   else if(TrspPRC)
   {  if(TrspBON)
         DiskType = (WrdT)(TrspTag - DID_SELD2);
   }
   else if(TrspTRM)
      f = TRUE;
}

LCL  VOID  CTYP  DlgPrnt(NOARG)
{
   LCL FlgT f = TRUE;

   if(TrspINI)
   {  if(f == TRUE)
      {  PrntType = 0;
         TuiDliSetFlg(DID_SELPR1, TRUE);
         f = FALSE;
      }
   }
   else if(TrspPRC)
   {  if(TrspBON)
         PrntType = (WrdT)(TrspTag - DID_SELPR1);
   }
   else if(TrspTRM)
      f = TRUE;
}

/*------------------------[ Viewer key actions ]------------------------*/

VOID CTYP MoveUp(NOARG)
{
   MoveCurs(TUI_SB_LINEUP);
}

VOID CTYP MoveDown(NOARG)
{
   MoveCurs(TUI_SB_LINEDOWN);
}

VOID CTYP MoveLeft(NOARG)
{
   MoveCurs(TUI_SB_LINELEFT);
}

VOID CTYP MoveRight(NOARG)
{
   MoveCurs(TUI_SB_LINERIGHT);
}

VOID CTYP MovePageUp(NOARG)
{
   MoveCurs(TUI_SB_PAGEUP);
}

VOID CTYP MovePageDown(NOARG)
{
   MoveCurs(TUI_SB_PAGEDOWN);
}

VOID CTYP MovePageLeft(NOARG)
{
   MoveCurs(TUI_SB_PAGELEFT);
}

VOID CTYP MovePageRight(NOARG)
{
   MoveCurs(TUI_SB_PAGERIGHT);
}

VOID CTYP MoveHome(NOARG)
{
   MoveCurs(TUI_SB_LEFT);
}

VOID CTYP MoveEnd(NOARG)
{
   MoveCurs(TUI_SB_RIGHT);
}

VOID CTYP MoveTop(NOARG)
{
   MoveCurs(TUI_SB_TOP);
}

VOID CTYP MoveBot(NOARG)
{
   MoveCurs(TUI_SB_BOTTOM);
}

/*-----------------[ File viewer, activated from menu ]-----------------*/

LCL  VOID  CTYP  ViewFile(NOARG)
{
   ChrP    Name, buf;
   _FfbT   ff;
   WrdT    size, rows = 0, cols = 0, i, k;
   FILE    *fp;
   WndT    wh1;
   FselT   sel;
   ChrT    pb[80];
   LCL WndT wh = -1;
   InfT    inf;

   if(wh != -1 && WinLoc(wh) != NULL)
   {  InfTtl(&inf) = MsgRead(MSG_VIEWTTL);
      InfStr(&inf) = MsgRead(MSG_VIEWDBL);
      InfTag(&inf) = NULL_TAG;
      InfIco(&inf) = ICON_WARN;
      InfFlg(&inf) = INF_OK;
      TuiInform(&inf);
      FreeN(InfTtl(&inf));
      FreeN(InfStr(&inf));
      TuiActiv(wh);
      return;
   }

   ParseFn(TcxlAv0, pb, NULL);         /* get path from our filename    */
   _Scat(pb, "\\DEMO");

   FselTyp(&sel) = types;              /* set up for file-open dialog   */
   FselTid(&sel) = 0;
   FselTtl(&sel) = NULL;
   FselDpt(&sel) = pb;
   FselFlg(&sel) = FSEL_SNG | FSEL_HRD;
   FselSel(&sel) = filepath;

   if(TuiSelFile(&sel))                /* get filename from dialog      */
   {  Name = filepath;                 /* name was returned here        */
      _FndFst(Name, &ff, 0);           /* find the file                 */
      size = (WrdT)_FfbSiz(ff);        /* get size                      */
      if(_FfbSiz(ff) > 35000L)         /* too big for demo?             */
      {  Wperror(MsgPeek(MSG_VIEWBIG));
      }
      else
      {  fp = fopen(Name, "rb");       /* open it                       */
         if(fp == NULL)
         {  Wperror(MsgPeek(MSG_VIEWOPN));
         }
         else
         {  wh = TuiWindow(&ViewWin);  /* open viewer window            */
            ParseTitle(wh, Name);

            MouPush(MOU_FULL|MOU_HOUR);   /* hourglass pointer          */
            CurPush(CUR_HID, -1, -1, -1);
            wh1 = TuiWindow(&LoadWin); /* open message window           */
            TuiPuts(wh1, 1, 2, MsgPeek(MSG_WAIT));

                                       /* read file into buffer         */
            buf = AllocNT(ChrP, size + 20);
            fread(buf, size, SIZ(ChrT), fp);
            buf[size] = EOS;
            for(i = k = 0; i < size; i++)
            {  if(buf[i] == '\n')
               {  rows++;
                  if(k > cols)
                     cols = k+1;
                  k = 0;
               }
               else
                  k++;
            }
            fclose(fp);
            cols += 2;
            rows += 5;

            TuiChange(wh, rows, cols); /* adjust virtual window size    */

            TuiPuts(wh, 0, 0, buf);    /* fill the window!              */
            FreeN(buf);                /* free the buffer               */
            WVgotoxy(wh, 0, 0);        /* home the cursor               */

            TuiActiv(wh1);             /* make the window active        */
            TuiClose();                /* user's done, close window     */

            CurPop();
            MouPop();                  /* restore mouse                 */
            TctlHlt = HID_VIEWF;       /* restore help context          */
         }
      }
   }
}

/*------------------------[ Entry-form routines ]------------------------*/

KeyT  CTYP  GetKey(NOARG)
{
   KeyT  x;

   x = TuiKeyGetc();
   if(x == Key_F9)                     /* Key_F9 in the last-key buffer */
   {  EntTrm(Key_F9);                  /* and return K_C_Ent to exit.   */
      x = Key_C_Ent;
   }
   return(x);
}  /* GetKey() */


VOID  CTYP  DrawEntry(NOARG)
{
   ChrP        t1, t2;

   if(EntWin.wttl == NULL)
   {  t1 = MsgRead(MSG_FRMTTL);
      t2 = MsgRead(MSG_FRM1);
      EntWin.wttl = AllocNT(ChrP, _Slen(t1) + _Slen(t2) + 7);
      _Scpy(EntWin.wttl, t1);
      _Scat(EntWin.wttl, " -");
      _Scat(EntWin.wttl, t2);
      FreeN(t1);
      FreeN(t2);
   }

   TuiWindow(&EntWin);
   EvtClear();
}

VOID  CTYP  StopEntry(NOARG)
{
   TuiClose();
   FreeN(EntWin.wttl);
   EntWin.wttl = NULL;
   EvtClear();
}

/*----------[ Select a product - string picking using a SelStr ]--------*/

VOID  CTYP  SelProd(NOARG)
{
   REG EdfP    e = EctlCur;
   FdfP        f, f1, f2 = NULL;
   ChrT        cnt[10];

   f = FldCur();
   if(FdfTag(f) != DID_PROD1 && strblank(FdfBfr(f)))
   {  switch(FdfTag(f))
      {  case DID_PROD5:
            f1 = FldLoc(DID_PROD4);
            if(!strblank(FdfBfr(f1)))
               break;
            f2 = f1;
                                       /* Else FALL THROUGH!!!!!        */
         case DID_PROD4:
            f1 = FldLoc(DID_PROD3);
            if(!strblank(FdfBfr(f1)))
               break;
            f2 = f1;
                                       /* Else FALL THROUGH!!!!!        */
         case DID_PROD3:
            f1 = FldLoc(DID_PROD2);
            if(!strblank(FdfBfr(f1)))
               break;
            f2 = f1;
                                       /* Else FALL THROUGH!!!!!        */
         case DID_PROD2:
            f1 = FldLoc(DID_PROD1);
            if(!strblank(FdfBfr(f1)))
               break;
            f2 = f1;
                                       /* Else FALL THROUGH!!!!!        */
      }
      if(f2 != NULL)
         EdfCur = f = f2;
   }

   TuiDialog(DID_DLG1);

   if(ProdPicked == NULL)
   {  f = FldLoc(DID_PRICE5);
      EdfCur = f;
      KquePut(Key_Tab);
      return;
   }
   else
   {  FldUpd(FdfTag(f), ProdPicked);
      cvtic(cnt, Quantity, 3);
      FldUpd((TagT)(FdfTag(f)+1), cnt);
      KquePut(Key_Tab);
      KquePut(Key_Tab);
   }
}

VOID  CTYP  SelShip(NOARG)
{
   FdfP        f;
   ChrT   fld[12];

   f = FldCur();
   TuiDialog(DID_DLG2);

   FldUpd(FdfTag(f), ShipArr[ShipType]);
   f = FldLoc(DID_SHIP2);
   cvtfc(fld, (DblT)ShipVal[ShipType], 7, 2);
   FldUpd(FdfTag(f), fld);
   KquePut(Key_Tab);
   KquePut(Key_Tab);
}

VOID  CTYP  SelDisk(NOARG)
{
   FdfP        f;

   f = FldCur();
   TuiDialog(DID_DLG3);

   FldUpd(FdfTag(f), DiskArr[DiskType]);
   KquePut(Key_Tab);
}

ChrP  CTYP  SelPrnt(NOARG)
{
   TuiDialog(DID_DLG4);
   if(Cancel == TRUE)
      return(NULL);
   else
      return(PrntArr[PrntType]);
}

VOID  CTYP  TryPrint(NOARG)
{
   ChrP        b;
   ChrT        c;

   WpopUp(CNT_CNT, 0, 0, 4, 40, BOX_SNG, WHITE|_RED, YELLOW|_RED);
   Wtitle(MsgPeek(MSG_PRINT1), TTL_CNT, WHITE|_RED);
   Wputc('\n');
   Wputs(MsgPeek(MSG_PRINT2));         /* do we want to print it?       */
   Wputc(NlsYes);
   Wputc('\b');
   c = KwGetYn(NlsYes);
   Wclose();
   if(c == 'Y')
   {  b = SelPrnt();                   /* print it where?               */
      if(b != NULL)
         PrintOrder(b);
   }
}

/*---------------------------[ Menu routines ]--------------------------*/

VOID  CTYP  CheckIt(TagT tag)
{
   if(FALSE == TuiMnuGetChk(tag))
      TuiMnuSetChk(tag, TRUE);
   else
      TuiMnuSetChk(tag, FALSE);
}

VOID  CTYP  CheckIt1(NOARG)
{
   CheckIt(MID_TABX);
}

VOID  CTYP  CheckIt2(NOARG)
{
   CheckIt(MID_INS);
}

VOID  CTYP  CheckIt3(NOARG)
{
   CheckIt(MID_IND);
}

VOID  CTYP  CheckIt4(NOARG)
{
   CheckIt(MID_WRAP);
}

VOID  CTYP  CheckIt5(NOARG)
{
   CheckIt(MID_BACK);
}

VOID  CTYP  CheckIt6(NOARG)
{
   CheckIt(MID_BOX);
}

/*========================[ Program main logic ]========================*/

int  CDC   TcxlMain(int argc, char **argv)
{
   WrdT i, j, k;

   argc = argc;
   argv = argv;

   MainWh = TuiInit(&MainWin, ResLst,  /* Startup                       */
         ActLst, HlpLst);

   MouPush(MOU_FULL|MOU_HOUR);         /* Hourglass pointer             */

   PrepItems();                        /* Retrieve message data         */

   TuiPutsw(MainWh, 0, 0, EdTxt1);     /* write stuff to the screen     */
   j = WdfWinR(TctlWin);
   k = WdfWinC(TctlWin);
   if(MouInit)
      TuiPutsw(MainWh, j, k, EdTxt2);

   j = WdfWinR(TctlWin) + 2;
   i = 0;
   do
   {  TuiPuts(MainWh, TcxlI[i].row + j, 0, TcxlI[i].Str);
   }  while(++i < 6);

   MouPop();                           /* Restore normal mouse pointer  */
   WgotoxyV(TctlWin, 0, 0);            /* Home cursor                   */
   CurPush(CUR_SHO, -1, -1, -1);       /* show cursor, save state       */

   TuiGet();                           /* Respond to user               */

   FreeItems();                        /* Free message-data memory      */

   return(0);                          /* Return                        */
}
