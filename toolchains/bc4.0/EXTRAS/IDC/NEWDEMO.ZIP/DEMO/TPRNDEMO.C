/*============[ The TesSeRact(TM) Printer Control System ]==============*
 | Copyright (c) 1987-1993, Innovative Data Concepts, Inc.
 | All Rights Reserved.
 |
 | This Library is part of IDC's TesSeRact Development Tools product
 | line. For information about other IDC products, call 1-215-443-9705.
 *-V--------------------------------------------------------------------*
 | $Header:   tprndemo.c     600.10   17 Apr 1993 16:31:16  $
 |
 | $Log:   tprndemo.c    $
 *-D--------------------------------------------------------------------*
 | 
 *-N-----------------------[ Notes and Caveats ]------------------------*
 | 
 *======================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <TCXLwin.h>
#include <TCXLsel.h>
#include <TCXLinp.h>
#include <TCXLcur.h>
#include <TCXLhlp.h>
#include <TPrint.H>

LCL IntT  CDC   LeftRow, LeftCol;      /* main menu coords              */

LCL   ChrP  CDC   prn_ports[] =        /* printer ports table           */
{
   "LPT1", "LPT2", "LPT3", "COM1", "COM2", "TPRNDEMO.PRN", NULL
};

VOID    CTYP    Initialize(NOARG);
VOID    CTYP    OpenBkgrnd(NOARG);
VOID    CTYP    AddShadow(NOARG);

VOID main (NOARG)
{
   IntT port;
   DblT wid,len;
   ChrT buffer[200];
   ChrP Prnt;

   Initialize();                       /* initialize TCXL               */

   WpopUp(CNT_CNT, 0, 0, 10, 60, BOX_DBL, LCYAN|_BLUE, LCYAN|_BLUE);

   WpopUp(CNT_CNT, 0, 0,  8, 56, BOX_SPA, LCYAN|_BLUE, LCYAN|_BLUE);

   Wtitle(MsgPeek(0x000C), TTL_LFT, LCYAN|_BLUE);

   Prnt = MsgRead(0x0001);
   Wputsw(Prnt);
   free(Prnt);

   Wputs(MsgPeek(0x000D));
   KeyGetc();

   port = SelStr(LeftRow, LeftCol, (WrdT)(LeftRow + 7), NEG1, 0, LGREEN|_RED, 
      LCYAN|_RED, RED|_LGREY, prn_ports, 0, NULL);

   if(port >= 0)
   {  Prnt = SelFile(LeftRow, LeftCol, (WrdT)(LeftRow + 7), NEG1, 0, LGREEN|_RED, 
         LCYAN|_RED, RED|_LGREY, 0, "DRIVER\\*.PRT", NULL);
      if(Prnt != NULL)
      {  wid = -1.0;
         len = -1.0;

         PrInit(Prnt,wid,len,3,3);

         PrStart(prn_ports[port], 12, 6);

         PrintCN(MsgPeek(0x000F), HEADERLINE);
         PrintCN(MsgPeek(0x0010), FOOTERLINE);


         Print(MsgPeek(0x0011), NORMALLINE);
         Print(MsgPeek(0x0012), NORMALLINE);

         PrintLN(MsgPeek(0x0013), NORMALLINE);
         PrintLN(MsgPeek(0x0014), NORMALLINE);
         PrintLN("\n", NORMALLINE);

         PrintRN(MsgPeek(0x0016), NORMALLINE);
         PrintRN(MsgPeek(0x0017), NORMALLINE);
         PrintLN("\n", NORMALLINE);

         PrintCN(MsgPeek(0x0019), NORMALLINE);
         PrintCN(MsgPeek(0x001A), NORMALLINE);
         PrintLN("\n", NORMALLINE);

         sprintf(buffer, MsgPeek(0x001C),
            BOLDon, UNDERon, ITALICon, ITALICoff, UNDERoff, BOLDoff);

         PrintCN(buffer, NORMALLINE);

         PrintCN(MsgPeek(0x001F), NORMALLINE);
         Print(PT07, NORMALLINE);
         PrintLN(MsgPeek(0x0020), NORMALLINE) ;

         PrintLN(MsgPeek(0x0021), NORMALLINE);

         PrMargin('L', 5);
         PrMargin('R', 100);

         PrintLN (MsgPeek(0x0022), NORMALLINE) ;
         PrintLN (MsgPeek(0x0023), NORMALLINE) ;

         Print(MsgPeek(0x0024), NORMALLINE);

         Print(MsgPeek(0x0011), NORMALLINE);
         Print(MsgPeek(0x0012), NORMALLINE);

         PrintLN(MsgPeek(0x0013), NORMALLINE);
         PrintLN(MsgPeek(0x0014), NORMALLINE);
         PrintLN("\n", NORMALLINE);

         PrintRN(MsgPeek(0x0016), NORMALLINE);
         PrintRN(MsgPeek(0x0017), NORMALLINE);
         PrintLN("\n", NORMALLINE);

         PrintCN(MsgPeek(0x0019), NORMALLINE);
         PrintCN(MsgPeek(0x001A), NORMALLINE);
         PrintLN("\n", NORMALLINE);

         PrintLN(PT10, NORMALLINE);
         PrintLN(MsgPeek(0x0030), NORMALLINE);
         PrintLN(PT12, NORMALLINE);
         PrintLN(MsgPeek(0x0031), NORMALLINE);

         sprintf(buffer, MsgPeek(0x0032), SUPERon, SUPERoff);
         PrintLN(buffer, NORMALLINE);
         sprintf(buffer, MsgPeek(0x0035), SUBSCon, SUBSCoff);
         PrintLN(buffer, NORMALLINE);

         PrCenterPage();

         PrWritePage();

         PrMargin('R', 75);

         PrintLN(MsgPeek(0x0036), NORMALLINE);
         sprintf(buffer, MsgPeek(0x0037),PrLineNo());

         Print(buffer, NORMALLINE);

         PrSkipLines(10);

         Print(MsgPeek(0x0038), NORMALLINE);
         sprintf(buffer,MsgPeek(0x0039),
            PrLineNo(), PrColNo(), PrRemainingLines());
         PrintLN(buffer, NORMALLINE);

         Print(MsgPeek(0x003A), NORMALLINE);

         PrCol(40);

         Print(MsgPeek(0x003B), NORMALLINE);

         PrWritePage();

         PrStop();

         PrRelease();

         Wputc('\n');
         Wputc('\n');

         sprintf(buffer, MsgPeek(0x003C), 
            prn_ports[port], Prnt);
         Wputsw(buffer);
         Wputs(MsgPeek(0x000D));
         KeyGetc();
      }
   }

   WcloseAll();                        /* restore the screen            */
}

VOID CTYP Initialize(NOARG)
{
   MsgHlpName("TPRNDEMO.MSG");
   TcxlInit();                         /* general initialization        */
   KextOff();                          /* no extended key BIOS          */
   CurPush(CUR_HID, CUR_NOR, 0, 0);    /* save the cursor state, hide   */
                                       /*    and home the cursor        */
   WsaveFull();                        /* save the screen               */
   LeftRow = ((VidDep - 1) / 2) - 5;   /* set up display coordinates    */
   LeftCol = ((VidWid - 1) / 2) - 5;
   OpenBkgrnd();                       /* build screen                  */
}  /* Initialize */


/*==[ Main background, program title and system information windows ]===*/

VOID CTYP OpenBkgrnd(NOARG)
{
                                       /* demo background window        */
   Wopen(0, 0, VidDep - 2, VidWid - 1, 5, 0, LGREEN|_GREEN);

   WsetFil('\xB0');                    /* bottom status bar, fancy fill */
   Wopen(VidDep - 1, 0, VidDep - 1, VidWid - 1, 5, 0, LGREY|_RED);

   WprtCen(0, LGREY|_RED, MsgPeek(0x003E));
   WsetFil(' ');                       /* blank fill again              */

                                       /* program title pop-up          */
   WpopUp(CNT_HOR, 0, 12, 4, 67, 0, LRED|_MAGENTA, LRED|_MAGENTA);
   AddShadow();                        /* add a shadow, display text    */
   WprtCen(0, WHITE|_MAGENTA, MsgPeek(0x003F));
   WprtCen(2, LCYAN|_MAGENTA, MsgPeek(0x0040));
}  /* OpenBkgrnd */

/*================[ Add a shadow to the current window ]================*/

VOID CTYP AddShadow(NOARG)
{
   Wshadow(LGREY|_BLACK);              /* simple, ain't it?             */
}  /* AddShadow */
