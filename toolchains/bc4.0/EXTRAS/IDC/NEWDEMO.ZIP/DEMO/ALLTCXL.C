/*=====[ The TesSeRact(TM) CXL User Interface Development System ]======*
 | Copyright (c) 1987-1993, Innovative Data Concepts, Inc.
 | All Rights Reserved.
 |
 | This Library is part of IDC's TesSeRact Development Tools product
 | line. For information about other IDC products, call 1-215-443-9705.
 *-V--------------------------------------------------------------------*
 | $Header:   alltcxl.c     610.16   07 Aug 1993 23:16:08  $
 |
 | $Log:   alltcxl.c    $
 *-D--------------------------------------------------------------------*
 | ALLTCXL.C : TCXL general demonstration program
 *-N-----------------------[ Notes and Caveats ]------------------------*
 |
 *======================================================================*/

#include "demo\allTCXL.h"              /* TCXL demo-specific            */

#define  MOV_HOME_D  0x29              /* app-specific event tags       */
#define  MOV_END_D   0x30

/*---------------------[ Local function prototypes ]--------------------*/

VOID  CTYP  EntryDemo(NOARG);

LCL   VOID  CTYP  DispSureMsg(NOARG);
LCL   VOID  CTYP  DrawEditor(NOARG);
LCL   VOID  CTYP  QuitWindow(NOARG);
LCL   VOID  CTYP  ToggleYN(NOARG);
LCL   VOID  CTYP  UpdateClock(NOARG);
LCL   VOID  CTYP  AddShadow(NOARG);
LCL   VOID  CTYP  ViewFile(NOARG);

/*----------------------------[ Local data ]----------------------------*/

WndT  CDC   Whdl;                      /* Window handle                 */
ChrP  CDC   EdTxt1 = NULL;             /* Editor demo text              */
ChrP  CDC   EdTxt2 = NULL;             /* Editor demo text              */

INFO1 TcxlI[] =         /* text displayed in Information screen         */
{  {  1, WHITE|_RED, NULL  },
   {  2, WHITE|_RED, NULL  },
   {  3, WHITE|_RED, NULL  },
   {  5, BLACK|_RED, NULL  },
   {  6, BLACK|_RED, NULL  },
   {  7, BLACK|_RED, NULL  }
};

TYP struct _DoMsg                      /* user type for messages        */
{  TagT     Msg;
   BytT     Brd;
   BytT     Col;
   AtrT     Atr;
   BytT     Pad;
}  DoMsg, *DoMsgP;

LCL DoMsg Msgs[2] =
{  { MSG_FRM1, BRD_BOT | MES_LFT,  5, LCYAN|_BLUE },
   { MSG_FRM2, BRD_BOT | MES_RGT,  5, LCYAN|_BLUE },
};

/*=======================[ Menu Data Structures ]=======================
 | The following set of initialized data objects describe the menus
 | used in this program.  Each pulldown or menu bar is built using an
 | MbldT ("menu-build") object which points to an array of IbldT
 | ("item-build") objects.  The MbldT object sets the overall
 | characteristics of the menu, such as colors and control flags.  Each
 | IbldT object describes an individual menu item, and contains flags,
 | a tag number, a help topic number, the names of the item's "before",
 | "select", and "after" functions, and so on.  Each menu item can point
 | to another menu, allowing menus to be nested to an arbitrary level.
 | Once this "tree" of data objects is created, the entire menu structure
 | is built in memory using the MnuBuild() function, and activated using
 | MnuGet().
 *======================================================================*/

IbldT  CDC   FilItm[8] =               /*- "File" pulldown items -------*/
{  {  NULL, 0, 0,       0, 0, MID_VIEW,     HID_VIEW,     Key_A_V, 0,
       NULL,   ViewFile,  NULL,       NULL, NULL   },
   {  NULL, 0, ITM_NSL, 1, 0, MID_SAVE,     HID_SAVE,     0,       0,
       NULL,   DoNothing, NULL,       NULL, NULL   },
   {  NULL, 0, 0,       2, 0, MID_ORDER,    HID_ORDER,    Key_A_R, 0,
       NULL,   EntryDemo, NULL,       NULL, NULL   },
   {  NULL, 0, ITM_NSL, 3, 0, MID_NEW,      HID_NEW,      0,       0,
       NULL,   DoNothing, NULL,       NULL, NULL   },
   {  NULL, 0, 0,       4, 0, MID_DIR,      HID_DIR,      0,       0,
       NULL,   ShowDir,   NULL,       NULL, NULL   },
   {  NULL, 0, ITM_NSL, 5, 0, MID_EXE,      HID_EXE,      0,       0,
       NULL,   DoNothing, NULL,       NULL, NULL   },
   {  NULL, 0, ITM_NSL, 6, 0, MID_SHELL,    HID_SHELL,    0,       0,
       NULL,   DoNothing, NULL,       NULL, NULL   },
   {  NULL, 0, ITM_ALL, 7, 0, MID_QUIT1,    HID_QUIT1,    0,       0,
      QuitWindow, NULL,      QuitWindow, NULL, NULL   }
};
MbldT CDC   FilMnu =                   /*- "File" pulldown menu --------*/
{  &FilItm[0], 8,  2,  1, 11, 20, MNU_PUL|MNU_SAV, BOX_SNG, LGREY|_BLUE,
   _BLUE, YELLOW|_BLUE, LCYAN|_BLUE, CYAN|_BLUE, YELLOW|_MAGENTA,
   MID_VIEW, NULL,  0, 15,  1, 0xFF, 0xFF, 0xFF
};

IbldT CDC   DefItm[8] =                /*- "Defaults" pulldown items----*/
{  {  NULL, 0, ITM_NSL, 0, 0, MID_TAB,      HID_TAB,      0,       0,
       NULL, DoNothing, NULL, NULL, NULL  },
   {  NULL, 0, 0,       1, 0, MID_TABX,     HID_TABX,     0,       0,
       NULL, ToggleYN,  NULL, NULL, NULL  },
   {  NULL, 0, 0,       2, 0, MID_INS,      HID_INS,      0,       0,
       NULL, ToggleYN,  NULL, NULL, NULL  },
   {  NULL, 0, 0,       3, 0, MID_IND,      HID_IND,      0,       0,
       NULL, ToggleYN,  NULL, NULL, NULL  },
   {  NULL, 0, 0,       4, 0, MID_WRAP,     HID_WRAP,     0,       0,
       NULL, ToggleYN,  NULL, NULL, NULL  },
   {  NULL, 0, ITM_NSL, 5, 0, MID_SAVED,    HID_SAVED,    0,       0,
       NULL, DoNothing, NULL, NULL, NULL  }
};
MbldT CDC   DefMnu =                   /*- "Defaults" pulldown menu ----*/
{  &DefItm[0], 6,  2, 14, 9, 36, MNU_PUL|MNU_SAV, BOX_SNG, LGREY|_BLUE,
   _BLUE, YELLOW|_BLUE, LCYAN|_BLUE, CYAN|_BLUE, YELLOW|_MAGENTA,
   MID_TABX, NULL,  0, 21,  1, 0xFF, 0xFF, 0xFF
};

IbldT CDC   OptItm[5] =                /*- "Options" pulldown items ----*/
{  {  NULL, 0, 0,       0, 0, MID_BACK,     HID_BACK,     0,       0,
       NULL, ToggleYN,   NULL, NULL, NULL  },
   {  NULL, 0, 0,       1, 0, MID_BOX,      HID_BOX,      0,       0,
       NULL, ToggleYN,   NULL, NULL, NULL  },
   {  NULL, 0, ITM_NSL, 2, 0, MID_LOADO,    HID_LOADO,    0,       0,
       NULL, DoNothing,  NULL, NULL, NULL  },
   {  NULL, 0, ITM_NSL, 3, 0, MID_SAVEO,    HID_SAVEO,    0,       0,
       NULL, DoNothing,  NULL, NULL, NULL  }
};
MbldT CDC   OptMnu =                   /*- "Options" pulldown menu -----*/
{  &OptItm[0], 4,  2, 30,  7, 51, MNU_PUL|MNU_SAV, BOX_SNG, LGREY|_BLUE,
   _BLUE, YELLOW|_BLUE, LCYAN|_BLUE, CYAN|_BLUE, YELLOW|_MAGENTA,
   MID_BACK, NULL,  0, 20,  1, 0xFF, 0xFF, 0xFF
};

IbldT CDC   QitItm[2] =                /*- "Quit" pulldown items -------*/
{  {  NULL, 0, ITM_AFT, 2, 0, MID_QYES,     HID_QYES,     0,       0,
      NULL, NULL, NULL, NULL, NULL  },
   {  NULL, 0, ITM_ALL, 3, 0, MID_QNO,      HID_QNO,      0,       0,
      NULL, NULL, NULL, NULL, NULL  }
};
MbldT CDC   QitMnu =                   /*- "Quit" pulldown menu --------*/
{  &QitItm[0], 2,  2, 44,  7, 62, MNU_PUL, BOX_SNG, LGREY|_BLUE,
   _BLUE, YELLOW|_BLUE, LCYAN|_BLUE, WHITE|_BLUE, YELLOW|_MAGENTA,
   MID_QYES, DispSureMsg,  0, 17, 7, 0xFF, 0xFF, 0xFF
};

IbldT CDC   TopItm[5] =                /*- Main bar items --------------*/
{  {  NULL, 0, ITM_PUL, 0,  2, MID_FILE,    HID_FILE,     Key_A_F, 0,
      NULL,       NULL,       NULL,       NULL, &FilMnu  },
   {  NULL, 0, ITM_PUL, 0, 15, MID_DEFAULTS,HID_DEFAULTS, Key_A_D, 0,
      NULL,       NULL,       NULL,       NULL, &DefMnu  },
   {  NULL, 0, ITM_PUL, 0, 31, MID_OPTIONS, HID_OPTIONS,  Key_A_O, 0,
      NULL,       NULL,       NULL,       NULL, &OptMnu  },
   {  NULL, 0, ITM_PUL, 0, 45, MID_QUIT,    HID_QUIT,     Key_A_Q, 0,
      QuitWindow, NULL,       QuitWindow, NULL, &QitMnu  },
   {  NULL, 0, ITM_NOR, 0, 57, MID_HELP,    HID_HELP,     Key_A_H, 0,
      NULL,       HlpGet,     NULL,       NULL, NULL     }
};
MbldT CDC   TopMnu =                   /*- Main bar menu ---------------*/
{  &TopItm[0], 5,  1,  1,  1, 0, MNU_HOR, BOX_SPA, CYAN,
   CYAN|_BLUE, YELLOW|_BLUE, LCYAN|_BLUE, 0, YELLOW|_MAGENTA,
   MID_FILE, NULL,  0,  0,  0, 0xFF, 0xFF, 0xFF
};

/*=============================[ Routines ]=============================*/

/*--------------------[ Get data from message file ]--------------------*/

LCL   VOID  CTYP  PrepItems(NOARG)
{
   REG IntT i;

   MnuPrepMsg(&TopMnu, MSG_TOP0, 0);   /* Get menu strings              */
   MnuPrepMsg(&FilMnu, MSG_FIL0, 0);
   MnuPrepMsg(&DefMnu, MSG_DEF0, 0);
   MnuPrepMsg(&OptMnu, MSG_OPT0, 0);
   MnuPrepMsg(&QitMnu, MSG_QIT0, 0);

   EdTxt1 = MsgRead(MSG_EDTXT1);       /* Get editor text               */
   EdTxt2 = MsgRead(MSG_EDTXT2);
   for(i = 0; i < 6; i++)
      TcxlI[i].Str = MsgRead(MSG_EDTXT3 + i);

                                       /* Get entry form strings        */
   EntPrepMsg(&DemFrm, MSG_PMT0, MSG_FMT0);

   ReadValue(TRUE,  MSG_PROD1);        /* Get misc. data for entry form */
   ReadValue(FALSE, MSG_SHIP1);
   DiskArr = ReadArray(MSG_DISK1);
   PrntArr = ReadArray(MSG_PRNT1);
}

/*-----------------[ Free memory for message-file data ]----------------*/

LCL   VOID  CTYP  FreeItems(NOARG)
{
   REG IntT i;

   MnuFreeMsg(&TopMnu);
   MnuFreeMsg(&FilMnu);
   MnuFreeMsg(&DefMnu);
   MnuFreeMsg(&OptMnu);
   MnuFreeMsg(&QitMnu);
   FreeN(EdTxt1);
   FreeN(EdTxt2);
   for(i = 0; i < 6; i++)
      FreeN(TcxlI[i].Str);

   EntFreeMsg(&DemFrm);
   FreeArray(ProdArr);
   FreeN(PriceArr);
   FreeArray(ShipArr);
   FreeN(ShipVal);
   FreeArray(DiskArr);
   FreeArray(PrntArr);
}

/*------------------[ Viewer scrolling event handler ]------------------*/

WrdT  CTYP  _DoScroll(TEvtP event, WdfP m, WrdT k);

LCL   IntT  CTYP  _ViewEvt(NOARG)
{
   WdfP     w = WctlAct;
   WrdT     k = 0, kk;
   VposT    o, or;
   WrdT     c = 0;
   WrdT     a,b,x,y;
   WhanP    next = WevtHan(WdfEvt(w));

   a = WdfSizR(w);
   b = WdfShaR(w);
   x = WdfSizC(w);
   y = WdfShaC(w);

   WevtUs1(WdfEvt(w)) = &c;

   while(k == 0)
   {  k = (*WhanFun(next))(next);
      kk = k;
      k = 0;

      VposW(o)  = WdfWinW(w);
      VposW(or) = WdfOrgW(w);

      switch(kk)                       /* Scroll based on generic       */
      {  case  MOV_UP:                 /*    MOV_??? codes              */
            if(VposR(o) > VposR(or))
               VposR(o)--;
            else if(VposR(or) > 0)
               VposR(or)--;
            break;

         case  MOV_DOWN:
            if(VposR(o) < (a - 1 + VposR(or)))
               VposR(o)++;
            else if(VposR(or) < (b - a + 1))
               VposR(or)++;
            break;

         case  MOV_RIGT:
            if(VposC(o) < (x - 1 + VposC(or)))
               VposC(o)++;
            else if(VposC(or) < (y - x + 1))
               VposC(or)++;
            break;

         case  MOV_LEFT:
            if(VposC(o) > VposC(or))
               VposC(o)--;
            else if(VposC(or) > 0)
               VposC(or)--;
            break;

         case  MOV_PGUP:
            if(VposR(or) > a)
               VposR(or) -= a;
            else
               VposR(o) = 0;
            break;

         case  MOV_PGDN:
            VposR(or) += a;
            if(VposR(or) > (b - a + 1))
               VposR(or) = (b - a + 1);
            break;

         case  MOV_PGLF:
            if(VposC(or) > x)
               VposC(or) -= x;
            else
               VposC(o) = 0;
            break;

         case  MOV_PGRT:
            VposC(or) += x;
            if(VposC(or) > (y - x + 1))
               VposC(or) = (y - x + 1);
            break;

         case  MOV_HOME:
            VposC(o) = 0;
            break;

         case  MOV_END:
            VposC(o) = y;
            break;

         case  MOV_HOME_D:
            VposW(or) = 0;
            break;

         case  MOV_END_D:
            VposR(o) = b;
            VposC(o) = 0;
            break;

         case  MOV_SELN:
            if(c != NEG1)
               k = kk;
            break;

         case MOV_POSN:
            k = 0;
            break;

         default:
            k = kk;
            break;

         case Key_Esc:
         case MOV_QUIT:
            c = k = kk;
            break;
         }

      if(VposW(or) != WdfOrgW(w))      /* position cursor and window    */
         WinPosition(VposW(or));
      else if(VposW(o) != WdfWinW(w))
         WcurSet(o);
   }

   return(c);
}

/*-------------------------[ Viewer event loop ]------------------------*/

WrdT  CTYP  _ViewMain(WhanP h)
{
   WrdT     k;
   TEvtP    event;

   event = &WevtEvt(WhanEvt(h));
   h = WhanNxt(h);


  if(h == NULL)                        /* If at end of chain, look in   */
  {   EvtNext(event);                  /*   event queue                 */
      k = 0;
  }
   else
      k = (*WhanFun(h))(h);            /* call down chain               */

   if(k == MOV_POSN)
      k = 0;

   if(event->typ == TEVT_AVAIL)        /* Translate Ctrl keys to        */
   {  switch(event->cod)               /* MOV_??? codes.  Other move-   */
      {  case  Key_C_PgUp:             /* ment keys are automatically   */
            k = MOV_HOME_D;            /* translated by default handler */
            break;

         case  Key_C_PgDn:
            k = MOV_END_D;
            break;

         case  Key_C_Lft:
            k = MOV_PGLF;
            break;

         case  Key_C_Rgt:
            k = MOV_PGRT;
            break;

         case  Key_Esc:
            k = MOV_QUIT;
            break;
      }
   }
   else if(event->typ == TEVT_BUT_REL)
   {  if(event->cod == Key_M_RelR)
         k = MOV_QUIT;
   }

   return(k);
}

/*----------------------------[ File Viewer ]---------------------------*/

LCL  VOID  CTYP  ViewFile(NOARG)
{
   ChrP    Name, buf, fs;
   _FfbT   ff;
   WrdT    size, rows = 0, cols = 0, i, k;
   FILE    *fp;
   WndT    wh, wh1;
   WdfP    w;
   BytT    ot;

   ot = WctlTab;                       /* set tab size for display      */
   WctlTab = 3;

   SelDirOn();                         /* make selection list           */
   SelParOn();
   fs = MsgRead(MSG_VIEWSPC);
   HlpAdd(HID_SELF);
   Name = SelFile(5, 5, 15, 25, BOX_SNG, YELLOW|_RED, WHITE|_RED,
      YELLOW|_LGREY, TRUE, fs, NULL);
   FreeN(fs);

   if(Name != NULL)                    /* open and read file            */
   {  MouPush(MOU_FULL|MOU_HOUR);      /* hourglass pointer             */
      CurPush(CUR_SHO, -1, -1, -1);    /* hide cursor                   */
      HlpAdd(HID_VIEWF);               /* set help category             */
      _FndFst(Name, &ff, 0);           /* find file                     */
      size = (WrdT)_FfbSiz(ff);        /* get size                      */
      if(_FfbSiz(ff) > 35000L)         /* too big for demo?             */
      {  Wperror(MsgPeek(MSG_VIEWBIG));
      }
      else
      {  fp = fopen(Name, "rb");       /* open it                       */
         if(fp == NULL)
         {  Wperror(MsgPeek(MSG_VIEWOPN));
         }
         else                          /* open viewer window            */
         {  wh = Wpopup(CNT_CNT, 0, 0, VidDep - 8, VidWid - 8, BOX_SNG,
                  WHITE|_BLUE, WHITE|_BLUE);
            if(ERR_ARG == wh)
               ErrorExit();
            w = WinLoc(wh);
            WVtitle(wh, Name, TTL_CNT, YELLOW|_BLUE);
            WVmessage(wh, MsgPeek(MSG_VIEWSTP),
               BRD_BOT | MES_CEN, 0, YELLOW|_BLUE);

                                       /* open message window           */
            wh1 = Wpopup(CNT_CNT, 0, 0, 3, 20, BOX_SNG, WHITE|_RED,
                  WHITE|_RED);
            if(ERR_ARG == wh1)
               ErrorExit();
            MsgPuts(MSG_WAIT);

                                       /* read the file into a buffer   */
            buf = AllocNT(ChrP, size + 20);
            fread(buf, size, SIZ(ChrT), fp);
            buf[size] = EOS;
            for(i = k = 0; i < size; i++)
            {  if(buf[i] == '\n')
               {  rows++;
                  if(k > cols)
                     cols = k+1;
                  k = 0;
               }
               else
                  k++;
            }
            fclose(fp);
            cols += 2;
            rows += 5;

                                       /* attach default event handler  */
            WdfScl(WctlAct) = _WinEvtScr;

            if(cols < WdfShaC(w))      /* vertical scroll bar           */
               cols = WdfShaC(w);
            else
               WScrBarV(w, TRUE, FALSE);

            if(rows < WdfShaR(w))      /* horizontal scroll bar         */
               rows = WdfShaR(w);
            else
               WScrBarV(w, TRUE, TRUE);

            WevtAddV(w, _WinEvtKey);   /* default kbd event handler     */
            WevtAddV(w, _ViewMain);    /* our custom event handler      */

            WVinChange(wh, rows, cols);   /* adjust virtual window size */

            WVputs(wh, buf);           /* fill the window -- one call!  */

            WVclose(wh1);              /* close the message window      */
            MouPush(MOU_FULL|MOU_NORM);   /* normal mouse pointer       */

            WVgotoxy(wh, 0, 0);        /* home the cursor               */
            _ViewEvt();                /* enter event loop              */

            FreeN(buf);                /* done, free buffer             */
            MouPop();                  /* restore mouse                 */
            WVclose(wh);               /* close viewer window           */
         }
      }
      HlpPop();                        /* restore help topic            */
      CurPop();                        /* restore cursor                */
      MouPop();                        /* restore mouse                 */
   }
   SelFree();                          /* free selection memory         */
   HlpPop();                           /* restore help                  */
   WctlTab = ot;                       /* restore tab setting           */
}

/*----------[ Select a product - string picking using a SelStr ]--------*/

VOID  CTYP  SelProd(NOARG)
{
   REG EdfP    e = EctlCur;
   REG IntT    s;
   FdfP        f, f1, f2 = NULL;
   WrdT        sr, sc;

   sr = WdfMinR(WctlAct) + 6;          /* get start row and column      */
   sc = WdfMinC(WctlAct) + 20;

   f = FldCur();
   if(FdfTag(f) != DID_PROD1 && strblank(FdfBfr(f)))
   {  switch(FdfTag(f))
      {  case DID_PROD5:
            f1 = FldLoc(DID_PROD4);
            if(!strblank(FdfBfr(f1)))
               break;
            f2 = f1;
                                       /* Else FALL THROUGH!!!!!        */
         case DID_PROD4:
            f1 = FldLoc(DID_PROD3);
            if(!strblank(FdfBfr(f1)))
               break;
            f2 = f1;
                                       /* Else FALL THROUGH!!!!!        */
         case DID_PROD3:
            f1 = FldLoc(DID_PROD2);
            if(!strblank(FdfBfr(f1)))
               break;
            f2 = f1;
                                       /* Else FALL THROUGH!!!!!        */
         case DID_PROD2:
            f1 = FldLoc(DID_PROD1);
            if(!strblank(FdfBfr(f1)))
               break;
            f2 = f1;
                                       /* Else FALL THROUGH!!!!!        */
      }
      if(f2 != NULL)
         EdfCur = f = f2;
   }

   if(ERR_ARG == (s = SelStr(sr, sc, sr+8, NEG1, BOX_SNG, YELLOW|_BLUE,
         YELLOW|_BLUE, WHITE|_LGREY, &ProdArr[0], 0, NULL)))
   {  if(TcxlErr != W_ESCPRESS)
         ErrorExit();
      else
      {  f = FldLoc(DID_PRICE5);
         EdfCur = f;
         KquePut(Key_Tab);
         return;
      }
   }

   FldUpd(FdfTag(f), ProdArr[s]);
   KquePut(Key_Tab);
}

VOID  CTYP  SelShip(NOARG)
{
   REG IntT    s;
   FdfP        f;
   WrdT        sr, sc;
   ChrT   fld[12];

   sr = WdfMinR(WctlAct) + 6;
   sc = WdfMinC(WctlAct) + 20;

   f = FldCur();
   if(ERR_ARG == (s = SelStr(sr, sc, sr+8, NEG1, BOX_SNG, YELLOW|_BLUE,
         YELLOW|_BLUE, WHITE|_LGREY, &ShipArr[0], 0, NULL)))
   {  if(TcxlErr != W_ESCPRESS)
         ErrorExit();
      else
         s = 0;
   }

   FldUpd(FdfTag(f), ShipArr[s]);
   f = FldLoc(DID_SHIP2);
   cvtfc(fld, (DblT)ShipVal[s], 7, 2);
   FldUpd(FdfTag(f), fld);
   KquePut(Key_Tab);
   KquePut(Key_Tab);
}

VOID  CTYP  SelDisk(NOARG)
{
   REG IntT    s;
   FdfP        f;
   WrdT        sr, sc;

   sr = WdfMinR(WctlAct) + 10;
   sc = WdfMinC(WctlAct) + 25;

   f = FldCur();
   if(ERR_ARG == (s = SelStr(sr, sc, sr+5, NEG1, BOX_SNG, YELLOW|_BLUE,
         YELLOW|_BLUE, WHITE|_LGREY, &DiskArr[0], 0, NULL)))
   {  if(TcxlErr != W_ESCPRESS)
         ErrorExit();
      else
         s = 0;
   }

   FldUpd(FdfTag(f), DiskArr[s]);
   KquePut(Key_Tab);
}

LCL   ChrP  CTYP  SelPrnt(NOARG)
{
   REG IntT    s;
   ChrP        p = NULL;
   WrdT        sr, sc;

   sr = WdfMinR(WctlAct);
   sc = WdfMinC(WctlAct) + 17;

   if(ERR_ARG == (s = SelStr(sr, sc, sr+6, NEG1, BOX_SNG, YELLOW|_BLUE,
         YELLOW|_BLUE, WHITE|_LGREY, &PrntArr[0], 0, NULL)))
   {  if(TcxlErr != W_ESCPRESS)
         ErrorExit();
   }
   else
      p = PrntArr[s];

   return(p);
}

/*--------------------------[ Draw entry form ]-------------------------*/

VOID  CTYP  DrawEntry(NOARG)
{
   IntT        i;
   DoMsgP      mp;

   if(ERR_ARG == WpopUp(CNT_CNT, 2, 2, 24, 77, BOX_SNG,
         LCYAN|_BLUE, LCYAN|_BLUE))
      ErrorExit();                     /* windowing error!              */

   AddShadow();                        /* add shadow, title, notes      */
   Wtitle(MsgPeek(MSG_FRMTTL), TTL_CNT, LCYAN|_BLUE);
   mp = &Msgs[0];
   for(i = 0; i < 2; i++)
   {  Wmessage(MsgPeek(mp->Msg), mp->Brd, mp->Col, mp->Atr);
      mp++;
   }
}

VOID  CTYP  StopEntry(NOARG)
{
   Wclose();
}

VOID  CTYP  TryPrint(NOARG)
{
   ChrP        b;
   ChrT        c;

   WpopUp(CNT_CNT, 0, 0, 4, 40, BOX_SNG, WHITE|_RED, YELLOW|_RED);
   Wtitle(MsgPeek(MSG_PRINT1), TTL_CNT, WHITE|_RED);
   Wputc('\n');
   Wputs(MsgPeek(MSG_PRINT2));         /* do we want to print it?       */
   Wputc(NlsYes);
   Wputc('\b');
   c = KwGetYn(NlsYes);
   if(c == 'Y')
   {  Wclear();
      Wputs(MsgPeek(MSG_PRINT3));
      b = SelPrnt();                   /* print it where?               */
      if(b != NULL)
         PrintOrder(b);
   }
   Wclose();
}

/*=========[ The TCXL Menu Demo, a simulated editor interface ]=========*/

LCL  VOID  CTYP  MenuDemo(NOARG)
{
   IntT     s = 0;

#if ((_TCXL_gui_ == 0) && (_TCXL_cp_ != _IDC_OS232_))
   _CerrPush(_AltCrit);
#endif
   KbndIdle(UpdateClock);              /* start clock display           */
   HlpPush(HID_PULL);                  /* push help category            */
   CurSave();                          /* save cursor state             */
   DrawEditor();

   TopMnu.menc = VidWid - 2;           /* adjust end-column             */
   MnuBuild(&TopMnu);                  /* build the menu tree           */

   s = MnuGet();                       /* process the menu              */
   while(KbndClr(Key_M_ClkL) == 0)     /* clear left mouse macros       */
      ;
   if(s == -1 && TcxlErr > W_ESCPRESS)
      ErrorExit();                     /* windowing error!              */

   Wclose();                           /* close up windows              */
   Wclose();                           /* restore screen                */

   CurPop();                           /* restore cursor                */
   KbndIdle(NULL);                     /* kill the clock                */
   KbndSet(Key_A_M, NULL, 0);
   HlpDrop();                          /* pop the help stack            */
#if ((_TCXL_gui_ == 0) && (_TCXL_cp_ != _IDC_OS232_))
   _CerrPop();
#endif
}


/*-------------------[ Display "Are you sure" prompt ]------------------*/

LCL  VOID  CTYP  DispSureMsg(NOARG)
{
   Wprts(0, 2, WHITE|_BLUE, MsgPeek(MSG_SUREMSG));
}


/*---------------------[ Draw a fake editor screen ]--------------------*/


LCL  VOID  CTYP  DrawEditor(NOARG)
{
   IntT  i, j;

   Whdl = Wopen(0, 0, VidDep - 1, VidWid - 1, 0, CYAN, CYAN);
   if(ERR_ARG == Whdl)
      ErrorExit();                     /* can't open the window!        */

   WdrwHor(1, 0, VidWid - 2,           /* draw the editor screen        */
      0, CYAN);

   if(ERR_ARG == WVopen(3, 1, VidDep - 2, VidWid - 2, NEG1, NEG1, WDF_VIS,
         BOX_SPA, CYAN, CYAN))
      ErrorExit();                     /* can't open the window!        */

   Wgotoxy(0, 0);                      /* home the cursor               */
   WsetTxt(YELLOW);                    /* set text attribute            */
   Wputsw(EdTxt1);                     /* display the sample text       */
   if(MouInit)
      Wputsw(EdTxt2);

   j = WdfWinR(WctlAct) + 2;
   i = 0;
   do
   {  Wprts(TcxlI[i].row + j, 0, TcxlI[i].Atr, TcxlI[i].Str);
   }  while(++i < 6);

}


/*---------------[ Display the [Q]uit item pop-up window ]--------------*
 | Called anytime the selection bar moves on or off a [Q]uit menu item.
 *----------------------------------------------------------------------*/

LCL  VOID  CTYP  QuitWindow(NOARG)
{
   LCL WndT    h = 0;

   if(h)
   {  WVclose(h);                      /* then close it                 */
      h = 0;
   }
   else                                /* open window                   */
   {  h = Wopen(14, 41, 17, 70, 0, YELLOW|_RED, WHITE|_RED);
      Wputsw(MsgPeek(MSG_QUITWIN));
   }
}


/*------[ Toggles the yes/no status of some pull-down menu items ]------*
 | This is to show modifying and redisplaying a menu item's string. We do
 | this by getting the address of the current item's struct, then
 | modifying the string pointed to by the istr element.  The redisp flag
 | is set so that when you return to the menu, the screen will be
 | automatically updated.
 *----------------------------------------------------------------------*/

ChrT  yes[12], no[12];

LCL  VOID  CTYP  ToggleYN(NOARG)
{
   IdfP i;
   ChrP s, y;
   LCL FlgT first = YES;

   if(first)
   {  MsgSave(MSG_TOGYES, yes);
      MsgSave(MSG_TOGNO, no);
      first = NO;
   }

   i = ItmCur();
   s = ItmGet(IdfTag(i));
   y = s + _Slen(s) - 3;
   _Scpy(y, strcmp(y, yes) ? yes : no);
   ItmDsp(IdfTag(i));
}


/*------------[ Update the on-screen clock once per second ]------------*/

LCL  VOID  CTYP  UpdateClock(NOARG)
{
   LCL DwdT t;
   DwdT     x;

   if(t < (x = _Timer()))
   {  WVmessage(Whdl, SysTime(1), BRD_TOP, VidWid - 10, LGREEN);
      t = x + 18;
   }
}

/*-------------------------[ Application setup ]------------------------*/

LCL  VOID  CTYP  Initialize(NOARG)
{
   TcxlIntOff();                       /* no high-intensity attributes  */
   TcxlCurOff();                       /* don't restore cursor position */
   MsgHlpName("ALLTCXL.MSG");          /* establish message filename    */
   TcxlInit();                         /* general initialization        */

   TcxlCfg |= ENV_CUR;
   KextOff();                          /* no extended key BIOS          */
   CurPush(CUR_HID, CUR_NOR, 0, 0);    /* save the cursor state, hide   */
                                       /*    and home the cursor        */
   MouPush(MOU_FULL|MOU_HOUR);         /* turn on hourglass pointer     */

   WopenFull(LGREY|_BLUE);             /* open backdrop window          */

   HlpDef("TCXLDEMO.HLP", Key_F1,      /* initialize help system,       */
      YELLOW|_RED, YELLOW|_RED,        /*  help key = [F1]              */
      LRED|_RED, WHITE|_RED, RED|_LGREY, BOX_DBL, _VFVCP(AddShadow));
   HlpPush(HID_GLOBAL);                /* push global help catagory     */
}

/*------------------[ get-key function for entry form ]-----------------*/

KeyT  CTYP  GetKey(NOARG)
{
   KeyT  x;

   x = KeyGetc();
   if(x == Key_F9)                     /* Key_F9 in the last-key buffer */
   {  EntTrm(Key_F9);                  /* and return K_C_Ent to exit.   */
      x = Key_C_Ent;
   }
   return(x);
}

/*-------------------[ Add shadow to current window ]-------------------*/

LCL   VOID  CTYP  AddShadow(NOARG)
{
   Wshadow(LGREY|_BLACK);              /* simple, ain't it?             */
}

VOID  CTYP  SwapCurs(NOARG)
{
   LCL IntT CurTyp = 0;

   if(++CurTyp > 4)
      CurTyp = 0;
   MouPtrTyp(CurTyp << 4);
}

/*========================[ Program entry point ]=======================*/

#if (_TCXL_gui_ > 0)
int   CDC   TcxlMain(int ac, char **av)   /* for TCXL/Windows or TCXL/PM*/
#else
int   CDC   main(int ac, char **av)       /* for TCXL-DOS               */
#endif
{
   ac = ac;                            /* stop compiler complaints      */
   av = av;

   Initialize();                       /* setup                         */
   PrepItems();                        /* retrieve message data         */
   KbndSet(Key_A_C, SwapCurs, 0);
   MenuDemo();                         /* run the demo                  */
   KbndFre();
   FreeItems();                        /* free message-data memory      */

   WcloseAll();                        /* close up whatever's open      */

   return(0);                          /* bye!                          */
}

/*- end of ALLTCXL.C ---------------------------------------------------*/
