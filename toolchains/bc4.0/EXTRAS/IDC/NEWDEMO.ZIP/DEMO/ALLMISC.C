/*=====[ The TesSeRact(TM) CXL User Interface Development System ]======*
 | Copyright (c) 1987-1993, Innovative Data Concepts, Inc.
 | All Rights Reserved.
 |
 | This Library is part of IDC's TesSeRact Development Tools product
 | line. For information about other IDC products, call 1-215-443-9705.
 *-V--------------------------------------------------------------------*
 | $Header:   allmisc.c     610.5   17 Apr 1993 16:07:12  $
 |
 | $Log:   allmisc.c    $
 *-D--------------------------------------------------------------------*
 | ALLMISC.C : Misc. common code for TCXL demo programs
 *-N-----------------------[ Notes and Caveats ]------------------------*
 | 
 *======================================================================*/

#include "demo\allTCXL.h"

ChrI  ProdArr;
WrdP  PriceArr;
ChrI  ShipArr;
WrdP  ShipVal;
ChrI  DiskArr;
ChrI  PrntArr;

ORDER1   CDC   OrdFrm;

#define  DEMO_CNT 33

/*====================[ Entry form data structures ]====================*/

LCL   FbldT   CDC   DemFld[DEMO_CNT] =    /*- field-build object list --*/
{  {  NULL,  0, 12, OrdFrm.date,          /* prompt, buffer             */
       0, 18, NULL,                       /* position, format           */
      NULL, NULL, NULL,                   /* "before", "valid", "after" */
      Key_A_D,  DID_DATE, HID_DATE,       /* hotkey, item-tag, help-tag */
      FLD_DIS, 0, FLD_CND                 /* features, user, input-mode */
   },
   {  NULL,  1, 12, OrdFrm.name,  1, 18, NULL, NULL, NULL, NULL,
      Key_A_N,  DID_NAME, HID_NAME, FLD_MIX | FLD_TRM, 0, FLD_CND
   },
   {  NULL,  2,  9, OrdFrm.company,  2, 18, NULL, NULL, NULL, NULL,
      Key_A_C,  DID_COMP, HID_COMP, FLD_TRM, 0, FLD_CND
   },
   {  NULL,  3,  0, OrdFrm.saddress,  3, 18, NULL, NULL, NULL, NULL,
      Key_A_A,  DID_ADDR, HID_ADDR, FLD_MIX | FLD_TRM, 0, FLD_CND
   },
   {  NULL,  4, 12, OrdFrm.scity,  4, 18, NULL, NULL, NULL, NULL,
      Key_A_I,  DID_CITY, HID_CITY, FLD_TRM, 0, FLD_CND
   },
   {  NULL,  4, 40, OrdFrm.sstate,  4, 47, NULL, NULL, NULL, NULL,
      Key_A_T,  DID_STATE, HID_STATE, FLD_TRM, 0, FLD_CND
   },
   {  NULL,  4, 51, OrdFrm.szipcode,  4, 61, NULL, NULL, NULL, NULL,
      Key_A_Z,  DID_ZIPCODE, HID_ZIPCODE, FLD_NUL, 0, FLD_CND
   },
   {  NULL,  5,  1, OrdFrm.baddress,  5, 18, NULL, NULL, NULL, NULL,
      0,        DID_BADDR, HID_BADDR, FLD_MIX | FLD_TRM, 0, FLD_CND
   },
   {  NULL,  6, 12, OrdFrm.bcity,  6, 18, NULL, NULL, NULL, NULL,
      0,        DID_BCITY, HID_BCITY, FLD_TRM, 0, FLD_CND
   },
   {  NULL,  6, 40, OrdFrm.bstate,  6, 47, NULL, NULL, NULL, NULL,
      0,        DID_BSTATE, HID_BSTATE, FLD_TRM, 0, FLD_CND
   },
   {  NULL,  6, 51, OrdFrm.bzipcode,  6, 61, NULL, NULL, NULL, NULL,
      0,        DID_BZIPCODE, HID_BZIPCODE, FLD_NUL, 0, FLD_CND
   },
   {  NULL,  7,  5, OrdFrm.vphone,  7, 18, NULL, NULL, NULL, NULL,
      Key_A_P, DID_VPHONE, HID_VPHONE, FLD_NUL, 0, FLD_CND
   },
   {  NULL,  7, 34, OrdFrm.fphone,  7, 45, NULL, NULL, NULL, NULL,
      0,        DID_FPHONE, HID_FPHONE, FLD_NUL, 0, FLD_CND
   },
   {  NULL, 11,  3, OrdFrm.prod1,  11,  3, NULL, SelProd, NULL, NULL,
      0,        DID_PROD1, HID_PROD1, FLD_TRM, 0, FLD_CND
   },
   {  NULL, 11, 53, OrdFrm.qty1,  11,  53, NULL, NULL, CheckCount, SetPrice,
      0,        DID_QTY1, HID_QTY1, FLD_VAL | FLD_NUM | FLD_TRM, 0, FLD_CND
   },
   {  NULL, 11, 62, OrdFrm.price1,  11,  62, NULL, NULL, NULL, NULL,
      0,        DID_PRICE1, HID_PRICE1, FLD_CUR | FLD_TRM, 0, FLD_CND
   },
   {  NULL, 12,  3, OrdFrm.prod2,  12,  3, NULL, SelProd, NULL, NULL,
      0,        DID_PROD2, HID_PROD2, FLD_TRM, 0, FLD_CND
   },
   {  NULL, 12, 53, OrdFrm.qty2,  12,  53, NULL, NULL, CheckCount, SetPrice,
      0,        DID_QTY2, HID_QTY2, FLD_VAL | FLD_NUM | FLD_TRM, 0, FLD_CND
   },
   {  NULL, 12, 62, OrdFrm.price2,  12,  62, NULL, NULL, NULL, NULL,
      0,        DID_PRICE2, HID_PRICE2, FLD_CUR | FLD_TRM, 0, FLD_CND
   },
   {  NULL, 13,  3, OrdFrm.prod3,  13,  3, NULL, SelProd, NULL, NULL,
      0,        DID_PROD3, HID_PROD3, FLD_TRM, 0, FLD_CND
   },
   {  NULL, 13, 53, OrdFrm.qty3,  13,  53, NULL, NULL, CheckCount, SetPrice,
      0,        DID_QTY3, HID_QTY3, FLD_VAL | FLD_NUM | FLD_TRM, 0, FLD_CND
   },
   {  NULL, 13, 62, OrdFrm.price3,  13,  62, NULL, NULL, NULL, NULL,
      0,        DID_PRICE3, HID_PRICE3, FLD_CUR | FLD_TRM, 0, FLD_CND
   },
   {  NULL, 14,  3, OrdFrm.prod4,  14,  3, NULL, SelProd, NULL, NULL,
      0,        DID_PROD4, HID_PROD4, FLD_TRM, 0, FLD_CND
   },
   {  NULL, 14, 53, OrdFrm.qty4,  14,  53, NULL, NULL, CheckCount, SetPrice,
      0,        DID_QTY4, HID_QTY4, FLD_VAL | FLD_NUM | FLD_TRM, 0, FLD_CND
   },
   {  NULL, 14, 62, OrdFrm.price4,  14,  62, NULL, NULL, NULL, NULL,
      0,        DID_PRICE4, HID_PRICE4, FLD_CUR | FLD_TRM, 0, FLD_CND
   },
   {  NULL, 15,  3, OrdFrm.prod5,  15,  3, NULL, SelProd, NULL, NULL,
      0,        DID_PROD5, HID_PROD5, FLD_TRM, 0, FLD_CND
   },
   {  NULL, 15, 53, OrdFrm.qty5,  15,  53, NULL, NULL, CheckCount, SetPrice,
      0,        DID_QTY5, HID_QTY5, FLD_VAL | FLD_NUM | FLD_TRM, 0, FLD_CND
   },
   {  NULL, 15, 62, OrdFrm.price5,  15,  62, NULL, NULL, NULL, NULL,
      0,        DID_PRICE5, HID_PRICE5, FLD_CUR | FLD_TRM, 0, FLD_CND
   },
   {  NULL, 17,  3, OrdFrm.ship1,  17, 24, NULL, SelShip, NULL, NULL,
      0,        DID_SHIP1, HID_SHIP1, FLD_TRM | FLD_REQ, 0, FLD_CND
   },
   {  NULL, 17, 62, OrdFrm.ship2,  17,  62, NULL, NULL, NULL, NULL,
      0,        DID_SHIP2, HID_SHIP2, FLD_CUR | FLD_TRM, 0, FLD_CND
   },
   {  NULL, 19, 19, OrdFrm.size,  19, 30, NULL, SelDisk, NULL, NULL,
      0,        DID_SIZE, HID_SIZE, FLD_TRM | FLD_REQ, 0, FLD_CND
   },
   {  NULL, 19, 51, OrdFrm.total,  19,  62, NULL, SetTotal, NULL, NULL,
      0,        DID_TOTAL, HID_TOTAL, FLD_CUR | FLD_TRM, 0, FLD_CND
   },
   {  NULL, 20,  0, OrdFrm.where,  20, 40, NULL, NULL, NULL, NULL,
      Key_A_W,  DID_WHERE, HID_WHERE, FLD_TRM, 0, FLD_CND
   }
};

EbldT   CDC   DemFrm =                    /*- form-build object --------*/
{  &DemFld[0], DEMO_CNT,                  /* field-build list, count    */
   GetKey, NULL,                          /* getkey(), key-buffer       */
   0, 0,                                  /* user, options              */
   WHITE|_BLUE, LCYAN|_LGREY,             /* prompt, field attributes   */
   WHITE|_LGREY, LCYAN|_LGREY             /* highlight, disabled attrs  */
};

/*-----------------------[ Abnormal termination ]-----------------------*/

VOID  CTYP   ErrorExit(NOARG)
{
   if(Wperror(WerrMsg()))
      Werror();
   exit(1);
}

/*---------------[ Dummy function for several menu items ]--------------*/

VOID  CTYP  DoNothing(NOARG)
{
}

/*--------[ Display a quick 'n' dirty directory of current path ]-------*
 | Uses new TCXL functions that are compiler independent                |
 *----------------------------------------------------------------------*/

VOID  CTYP  ShowDir(NOARG)
{
   ChrT     fs[49], f1[49];
   IntT     i, f, l, n;
   _FfbT    fb;
   WrdT     k;
   ChrP     fmt;

   _Scpy(fs, "*.*");
   CurPush(CUR_SHO, -1, -1, -1);       /* show cursor, save state       */
   if(ERR_ARG == Wopen(4, 14, 20, 59, 0, /* open the window             */
      YELLOW|_BLUE, YELLOW|_BLUE))
      ErrorExit();                     /* windowing error!              */

   Wtitle(MsgPeek(MSG_DIRTTL), TTL_CNT, YELLOW|_BLUE);
                                       /* open form window, define form */
   if(ERR_ARG == Wopen(6, 6, 8, 49, 0, LCYAN|_RED, LCYAN|_RED))
      ErrorExit();                     /* windowing error!              */

   Wtitle(MsgPeek(MSG_FILTTL), TTL_CNT, LCYAN|_RED);
   EntDef(BLUE|_LGREY, BLUE|_LGREY, 1);
   fmt = MsgRead(MSG_DIRFMT);
   EntFld(0, 1, fs, fmt, FLD_TRM, 13, 2, NULL, HID_KEYS);
   i = EntGet(13);                     /* get user input, close window  */
   Wclose();
   if(13 == i)
   {  Wclear();                        /* clear directory window        */
      WsetTxt(LCYAN|_BLUE);            /* set text attribute            */
      l = n = 0;
      f = _FndFst(fs, &fb, 0);         /* build the directory display   */
      LOOP                             /*- endless loop ----------------*/
      {  if(f)                         /* nothing found                 */
            break;

         f1[0] = '\0';
         for(i = 0; (i < 3) && !f; i++)
         {  n++;                       /* next line                     */
            sprintf(fs, "%s%-15s", f1, _FfbNam(fb));
            _Scpy(f1, fs);
            f = _FndNxt(&fb);          /* find next file                */
         }
         strtrim(f1);
         Wputf(" %s\n", f1);
         l++;
         if(l >= 14)                   /* more files to display ...     */
         {  Wputs(MsgPeek(MSG_DIRMSG1));
            k = KeyTime(36);
            Wputf("\r");
            if(k == Key_Esc || k == Key_M_RelR)
               break;
            l = 0;
         }
      }

      Wputf(MsgPeek(MSG_DIRMSG2), n);  /* display summary               */
      KeyTime(36);
   }
   FreeN(fmt);
   CurPop();                           /* restore cursor state          */
   Wclose();                           /* close the window              */
}

VOID  CTYP  ReadValue(FlgT f, TagT tag)
{
   ChrI strs;
   WrdP vals;
   WrdT cnt, i;
   ChrP s, p;

   cnt = (WrdT)atoi(MsgPeek(tag));

   strs = AllocNT(ChrI, (cnt+1)*SIZ(ChrP));
   vals = AllocNT(WrdP, (cnt+1)*SIZ(WrdT));

   for(i = 0; i < cnt; i++)
   {  s = MsgPeek(tag + i + 1);
      p = strchr(s, ',');
      *p = EOS;
      p++;
      vals[i] = (WrdT)atoi(p);
      strs[i] = AllocNT(ChrP, (_Slen(s)+1)*SIZ(ChrT));
      _Scpy(strs[i], s);
   }
   strs[i] = NULL;
   if(f == TRUE)
   {  ProdArr = strs;
      PriceArr = vals;
   }
   else
   {  ShipArr = strs;
      ShipVal = vals;
   }
}

ChrI  CTYP  ReadArray(TagT tag)
{
   ChrI strs;
   WrdT cnt, i;
   ChrP s;

   cnt = (WrdT)atoi(MsgPeek(tag));

   strs = AllocNT(ChrI, (cnt+1)*SIZ(ChrP));

   for(i = 0; i < cnt; i++)
   {  s = MsgPeek(tag + i + 1);
      strs[i] = AllocNT(ChrP, (_Slen(s)+1)*SIZ(ChrT));
      _Scpy(strs[i], s);
   }
   strs[i] = NULL;
   return(strs);
}

VOID  CTYP  FreeArray(ChrI strs)
{
   ChrI t;

   for(t = strs; *t != NULL; t++)
      FreeN(*t);
   FreeN(strs);
}

/*======[ Parse a MMDDYY date string into separate numeric values ]=====*
 | <b> is the date string, <m>, <d>, and <y> point to integers to receive
 | the month, day and year
 *----------------------------------------------------------------------*/

VOID  CTYP  ParseDate(ChrP b, IntP m, IntP d, IntP y)
{
   ChrT  t[12];

   _Scpy(t, b);
   *y = (IntT)(1900 + atoi(t + 6));    /* year                          */
   *(t + 5) = EOS;
   *d = (IntT)atoi(t + 3);             /* day                           */
   *(t + 2) = EOS;
   *m = (IntT)atoi(t);                 /* month                         */
}

/*------[ Display the literal equivalent of the MMDDYY date field ]-----*
 | Called immediately after the user leaves the Date field.
 *----------------------------------------------------------------------*/

VOID  CTYP  DisplayDate(NOARG)
{
   FdfP  f;
   IntT  m, d, y;

   if(NULL == (f = FldLoc(DID_DATE)))  /* find address of Date field    */
      ErrorExit();

   Wgotoxy(0, 37);                     /* clear to end of line          */
   WclrEol();
   if(!strblank(FdfBfr(f)))            /* parse string date into        */
   {  ParseDate(FdfBfr(f), &m, &d, &y);   /* numeric values             */
      Wputf("%s %d, %d", MsgPeek(M_JAN + m - 1), d, y);
   }
}

/*-----------[ Print the order form to the passed file/device ]---------*/

VOID  CTYP  PrintOrder(ChrP dev)
{
   FILE  *fl;

   if(NULL == (fl = fopen(dev, "w")))
   {   Wperror("Cannot open invoice file.");
       return;
   }

   MouPush(MOU_FULL|MOU_HOUR);

   fprintf(fl, "\n%s\n", MsgPeek(MSG_ORD1));
   fprintf(fl, "%s\n", MsgPeek(MSG_ORD2));
   fprintf(fl, "%s\n", MsgPeek(MSG_ORD3));
   fprintf(fl, "%s\n\n", MsgPeek(MSG_ORD1));
   fprintf(fl, "  %s  %s\n", MsgPeek(MSG_ORD4), OrdFrm.date);
   fprintf(fl, "  %s  %s\n\n\n", MsgPeek(MSG_PMT20), OrdFrm.where);
   fprintf(fl, "  %s\n", MsgPeek(MSG_PMT3));
   fprintf(fl, "  %s\n", MsgPeek(MSG_ORD5));

   fprintf(fl, "  %s\n", OrdFrm.name);
   fprintf(fl, "  %s\n", OrdFrm.company);
   fprintf(fl, "  %s\n", OrdFrm.saddress);
   fprintf(fl, "  %s, %s  %5.5s-%s\n\n", 
         OrdFrm.scity, OrdFrm.sstate, OrdFrm.szipcode,
         &(OrdFrm.szipcode)[5]);

   if(OrdFrm.baddress[0] != EOS)
   {  fprintf(fl, "   %s\n", MsgPeek(MSG_PMT7));
      fprintf(fl, "  %s\n", MsgPeek(MSG_ORD5));
      fprintf(fl, "  %s\n", OrdFrm.name);
      fprintf(fl, "  %s\n", OrdFrm.company);
      fprintf(fl, "  %s\n", OrdFrm.baddress);
      fprintf(fl, "  %s, %s  %5.5s-%s\n\n", 
            OrdFrm.bcity, OrdFrm.bstate, OrdFrm.bzipcode,
            &(OrdFrm.bzipcode)[5]);
   }

   if(OrdFrm.vphone[0] != EOS)
      fprintf(fl, "  %s  (%3.3s) %3.3s-%4.4s\n", MsgPeek(MSG_PMTB), 
            OrdFrm.vphone, &(OrdFrm.vphone)[3], &(OrdFrm.vphone)[6]);

   if(OrdFrm.fphone[0] != EOS)
      fprintf(fl, "    %s  (%3.3s) %3.3s-%4.4s\n", MsgPeek(MSG_PMTC), 
            OrdFrm.fphone, &(OrdFrm.fphone)[3], &(OrdFrm.fphone)[6]);

   fprintf(fl, "\n\n");
   fprintf(fl, "    %-40.40s", MsgPeek(MSG_ORD7));
   fprintf(fl, " %-10.10s", MsgPeek(MSG_ORD8));
   fprintf(fl, "       %-10.10s\n", MsgPeek(MSG_ORD9));
   fprintf(fl, "    %-40.40s", MsgPeek(MSG_ORDA));
   fprintf(fl, " %-10.10s", MsgPeek(MSG_ORDB));
   fprintf(fl, "     %-11.11s\n", MsgPeek(MSG_ORDC));

   fprintf(fl, "    %-40.40s   %-6.6s       $%9.9s\n", 
         OrdFrm.prod1, OrdFrm.qty1, OrdFrm.price1);
   if(OrdFrm.prod2[0] != EOS)
      fprintf(fl, "    %-40.40s   %-6.6s       $%9.9s\n", 
            OrdFrm.prod2, OrdFrm.qty2, OrdFrm.price2);
   if(OrdFrm.prod3[0] != EOS)
      fprintf(fl, "    %-40.40s   %-6.6s       $%9.9s\n", 
            OrdFrm.prod3, OrdFrm.qty3, OrdFrm.price3);
   if(OrdFrm.prod4[0] != EOS)
      fprintf(fl, "    %-40.40s   %-6.6s       $%9.9s\n", 
            OrdFrm.prod4, OrdFrm.qty4, OrdFrm.price4);
   if(OrdFrm.prod5[0] != EOS)
      fprintf(fl, "    %-40.40s   %-6.6s       $%9.9s\n", 
            OrdFrm.prod5, OrdFrm.qty5, OrdFrm.price5);
   fprintf(fl, "    %-40.40s %-10.10s     %-11.11s\n", "", "",
         MsgPeek(MSG_ORDC));
   fprintf(fl, "    %-20.20s %-34.34s $%9.9s\n", 
         MsgPeek(MSG_PMT1C), OrdFrm.ship1, OrdFrm.ship2);

   fprintf(fl, "    %-40.40s %-10.10s     %-11.11s\n", "", "",
         MsgPeek(MSG_ORDC));
   fprintf(fl, "    %-40.40s   %-6.6s       $%9.9s\n\n", 
         MsgPeek(MSG_PMT1F), "", OrdFrm.total);

   fprintf(fl, "    %s   %s\n\n\n", MsgPeek(MSG_PMT1E), OrdFrm.size);

   fprintf(fl, "%s", MsgPeek(MSG_ORDD));
   fprintf(fl, "%s\n\n\n", MsgPeek(MSG_ORDE));
   fprintf(fl, "%s%s%c", MsgPeek(MSG_ORDF), TcxlAv0, 0x0c);

   fclose(fl);
   MouPop();
}

/*--------------------[ Alternate get key function ]--------------------*
 | Do a normal keyboard get, with the following user-defined cases:
 | 1) If the key is [F9], exit the form and pass back [F9] in the
 |    last-key buffer.
 | In order to pass back an [F9] as the last key, we call EntTrm() to
 | put Key_F9 in the buffer and preventing EntGet() from putting the
 | Key_C_Ent we return to exit the form in it.
 *----------------------------------------------------------------------*/

IntT  CTYP  CheckCount(ChrP str)
{
   IntT   val;
   FdfP   f, f1;

   f = FldCur();                       /* update entry field            */
   f1 = FldLoc((TagT)(FdfTag(f) - 1));
   val = cvtci(str);
   if(val == 0 && !strblank(FdfBfr(f1)))
   {  Wpwarning("You must enter a quantity!");
      return(1);
   }
   return(0);
}

VOID  CTYP  SetTotal(NOARG)
{
   FdfP   f, f1;
   IntT   i;
   DblT   totalv = 0.0, val;
   ChrT   fld[12];

   f = FldCur();
   for(i = 0; i < 5; i++)
   {  f1 = FldLoc((TagT)(DID_PRICE1 + (i * 3)));
      val = cvtcf(FdfBfr(f1));
      totalv += val;
   }
   f1 = FldLoc(DID_SHIP2);
   val = cvtcf(FdfBfr(f1));
   totalv += val;
   cvtfc(fld, totalv, 7, 2);
   FldUpd(FdfTag(f), fld);
   KquePut(Key_Tab);
}

VOID  CTYP  SetPrice(NOARG)
{
   FdfP   f, f1, f2;
   IntT   len, i, val;
   ChrI   s;
   ChrP   p;
   ChrT   fld[12];

   f = FldCur();                       /* update entry field            */
   f1 = FldLoc((TagT)(FdfTag(f) - 1));
   f2 = FldLoc((TagT)(FdfTag(f) + 1));

   for(i = 0, s = ProdArr; *s != NULL; s++, i++)
   {  p = *s;
      len = (IntT)_Slen(p);
      if(strncmp(p, FdfBfr(f1), len) == 0)
         break;
   }
   if(*s != NULL)
      val = PriceArr[i];
   else
      val = 0;
   i = cvtci(FdfBfr(f));
   cvtfc(fld, (DblT)(val * i), 7, 2);
   FldUpd(FdfTag(f2), fld);
   KquePut(Key_Tab);
}

/*=====================[ Create and use entry form ]====================*/

VOID  CTYP  EntryDemo(NOARG)
{
   KeyT        k = 0;
   ChrP        b;

   CurSave();                          /* save cursor state             */

   b = SysDate(5);                     /* get date as MM/DD/YY          */
   _Scpy(OrdFrm.date, b);              /* fill the field                */
   DrawEntry();
   DemFrm.etrm = &k;                   /* key-buffer                    */

   HlpPush(HID_KEYS);                  /* set help category             */
   EntBuild(&DemFrm);                  /* build the form, with prompts  */
   EntDsp();
   DisplayDate();
   WdrwBox(8,  1, 18, 72, BOX_SNG, WHITE|_BLUE);
   WdrwHor(10,  1, 72, BOX_SNG, WHITE|_BLUE);
   WdrwHor(16,  1, 72, BOX_SNG, WHITE|_BLUE);
   WdrwVer(8, 49, 9, BOX_SNG, WHITE|_BLUE);
   WdrwVer(8, 60, 11, BOX_SNG, WHITE|_BLUE);
   Wprts(9,  3, YELLOW|_BLUE, MsgPeek(MSG_ORD7));
   Wprts(9, 51, YELLOW|_BLUE, MsgPeek(MSG_ORD8));
   Wprts(9, 63, YELLOW|_BLUE, MsgPeek(MSG_ORD9));

   EntGet(DID_NAME);
   HlpDrop();                          /* clear help                    */

   StopEntry();                        /* close window                  */
   CurPop();                           /* restore original cursor state */

   if(k != Key_Esc)                    /* if we completed the form      */
      TryPrint();

}
