/*=====[ The TesSeRact(TM) CXL User Interface Development System ]======*
 | Copyright (c) 1987-1993, Innovative Data Concepts, Inc.
 | All Rights Reserved.
 |
 | This Library is part of IDC's TesSeRact Development Tools product
 | line. For information about other IDC products, call 1-215-443-9705.
 *-V--------------------------------------------------------------------*
 | $Header:   edtdemo.c     100.18   23 Aug 1993 23:02:32  $
 |
 | $Log:   edtdemo.c    $
 *-D--------------------------------------------------------------------*
 |
 *-N-----------------------[ Notes and Caveats ]------------------------*
 |
 *======================================================================*/
#if defined(TCXLW)
#  include <TCXL_win.h>
#elif defined(TCXLPM)
#  include <TCXL_pm.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <fcntl.h>
#include <sys\types.h>
#include <sys\stat.h>
#include <TCXLcur.h>
#include <TCXLmnu.h>
#include <TCXLent.h>
#include <TCXLsel.h>
#include <TCXLinp.h>
#include <TCXLhlp.h>
#include <TCXLcod.h>
#include <TCXLico.h>
#include <TCXL_edt.h>

#define  DEMO_VER    0x0102            /* demo version = 1.02           */

#if 0
#define USE_BIG_FILE                /* define to load very large file   */
#endif

ChrT  FileName[64];

VOID  CTYP  AddShadow(NOARG);
VOID  CTYP  PreMnuFil(NOARG);
VOID  CTYP  PreMnuEdt(NOARG);
VOID  CTYP  PreMnuFnd(NOARG);
VOID  CTYP  PreMnuHlp(NOARG);
VOID  CTYP  About(NOARG);
VOID  CTYP  GotoLine(NOARG);


KeyT  Ignore[] = { Key_Esc, Key_F11, Key_F12, 0 };

IntT  sr, sc, er, ec;

#define  H_NONE      0
#define  H_GLOBAL    1
#define  EDT_H_GEN   0x1001
#define  EDT_H_CMD   0x1002
#define  EDT_H_PRO   0x1003
#define  EDT_H_KEY   0x1004
#define  EDT_H_HLP   0x1005
#define  EDT_H_NDX   (TagT)0xFFFE
#define  EDT_H_LOAD  0x2000
#define  EDT_H_SVAS  0x2001
#define  EDT_H_SRCH  0x2002
#define  EDT_H_NEW   0x2003
#define  EDT_H_BLOCK 0x2004
#define  EDT_H_FIND  0x2005
#define  EDT_H_SAVE  0x2006

ChrT  FileSpec[80] = "*.C";
ChrT  SrchStr[33] = "";
ChrT  ReplStr[33] = "";
ChrT  SrchDir[2]  = "F";
ChrT  SrchCase[2] = "N";
ChrT  SrchConf[2] = "Y";
ChrT  SrchGbl[2]  = "N";

#if (_TCXL_gui_ == 0)
/* =====================================================
    Created by RIE - Rimrock Icon Editor, version 1.04
       RIE is Copyright (C) 1992 by Rimrock Software
                   All rights reserved.
   TCXL is Copyright 1987-92 by Innovative Data Concepts
                   All rights reserved.
   ===================================================== */

IcnT  iconTESS =
{  { 0x0,0x0,0x0,0x1,0x2,0x7,0xa,0x1f },
   { 0x2a,0x5f,0xaa,0x5f,0xaa,0x5f,0xaa,0xff },
   { 0xaa,0xff,0xaa,0xff,0xaa,0x7f,0x2a,0x1d },
   { 0xa,0x5,0x2,0x1,0x0,0x0,0x0,0x0 },
   { 0x0,0x0,0x0,0x0,0x80,0xc0,0xa0,0xf0 },
   { 0xa8,0xf4,0xaa,0xf4,0xaa,0xf4,0xaa,0xfe },
   { 0xaa,0xfe,0xaa,0xfe,0xaa,0xfc,0xa8,0x70 },
   { 0xa0,0x40,0x80,0x0,0x0,0x0,0x0,0x0 }
};
#endif

ChrP _AbtStr = "\x1b" "F\x0f\x1bVThe TCXL/Editor Demonstration Program\n" \
               "\x1bVEditor v%u,%02u, Demo v%u.%02u\n" \
               "\x1bVCopyright 1992\n" \
               "\x1bVInnovative Data Concepts, Inc.\n" \
               "\x1bVAll Rights Reserved\n";

ChrP _ReplStr = "\x1bVReplace?";

ChrP _OkStr[] = { "OK", NULL };

ChrP _YesNo[] = { "YES", "NO", "ALL", NULL };

LCL FbldT CDC FileFld1[] =
{  {  "Filespec:", 0, 0,
      FileSpec, 0, 9,
      "WWWWWWWWWWWWWWWWWWWWWW",
      NULL, NULL, NULL,
      0x0000, 0, EDT_H_LOAD,
      FLD_UPR|FLD_NWR|FLD_TRM, 0, FLD_CND
   }
};

LCL FbldT CDC FileFld2[] =
{  {  "Filename:", 0, 0,
      FileName, 0, 9,
      "FFFFFFFFFFFFFFFFFFFFFF",
      NULL, NULL, NULL,
      0x0000, 0, EDT_H_SVAS,
      FLD_UPR|FLD_NWR|FLD_TRM, 0, FLD_CND
   }
};

LCL EbldT CDC FileFrm =
{  &FileFld1[0], 1, NULL, NULL, 0,
   (BytT) 0, YELLOW|_RED, BLACK|_LGREY, BLACK|_LGREY,
   BLACK|_LGREY, DGREY|_BLACK
};

LCL   FbldT CDC   SrchFlds[] =
{  {  "Search for:", 0, 1,
      SrchStr, 1, 1,
      "********************************",
      NULL, NULL, NULL,
      0x0000, 0, EDT_H_SRCH,
      FLD_NWR, 0, FLD_CND
   },
   {  "Replace with:", 3, 1,
      ReplStr, 4, 1,
      "********************************",
      NULL, NULL, NULL,
      0x0000, 1, EDT_H_SRCH,
      FLD_NWR, 0, FLD_CND
   },
   {  "Direction:", 6, 2,
      SrchDir, 6, 13,
      "<FfBb>",
      NULL, NULL, NULL,
      0x0000, 2, EDT_H_SRCH,
      FLD_UPR, 0, FLD_CND
   },
   {  "Case:", 8, 6,
      SrchCase, 8, 13,
      "<YyNn>",
      NULL, NULL, NULL,
      0x0000, 0, EDT_H_SRCH,
      FLD_UPR, 0, FLD_CND
   },
   {  "Confirm:", 6, 21,
      SrchConf, 6, 30,
      "<YyNn>",
      NULL, NULL, NULL,
      0x0000, 0, EDT_H_SRCH,
      FLD_UPR, 0, FLD_CND
   },
   {  "Global:", 8, 22,
      SrchGbl, 8, 30,
      "<YyNy>",
      NULL, NULL, NULL,
      0x0000, 0, EDT_H_SRCH,
      FLD_UPR, 0, FLD_CND
   }
};

LCL   EbldT CDC   SrchFrm =
{  &SrchFlds[0], 6, NULL, NULL, 0,
   0, YELLOW|_RED, WHITE|_CYAN, WHITE|_CYAN,
   BLACK|_BLUE, 0
};

LCL   IbldT CDC   FileItms[] =
{  {  "New", 'N', ITM_BEF|ITM_ALL, 0, 0,
      10, EDT_H_NEW, 0, 0,
      NULL, _EdtNew, NULL,
      NULL, NULL
   },
   {  "Open...", 'O', ITM_BEF|ITM_ALL, 1, 0,
      11, EDT_H_LOAD, 0, 0,
      NULL, _EdtLoad, NULL,
      NULL, NULL
   },
   {  "Save", 'S', ITM_BEF|ITM_ALL, 3, 0,
      12, EDT_H_SAVE, 0, 0,
      NULL, _EdtSave, NULL,
      NULL, NULL
   },
   {  "Save as...", 'a', ITM_BEF|ITM_ALL, 4, 0,
      13, EDT_H_SVAS, 0, 0,
      NULL, _EdtSaveAs, NULL,
      NULL, NULL
   },
   {  "Print", 'P', ITM_NSL, 6, 0,
      14, 0x0000, 0, 0,
      NULL, NULL, NULL,
      NULL, NULL
   },
   {  "Exit", 'x', ITM_BEF|ITM_ALL, 8, 0,
      15, 0x0000, 0, 0,
      NULL, _EdtExit, NULL,
      NULL, NULL
   }
};

LCL   MbldT CDC   FilePD =
{ &FileItms[0],  6,  2,  1, 12, 15, MNU_PUL|MNU_SAV, BOX_SNG,
  WHITE|_BLUE, WHITE|_BLUE, WHITE|_BLUE,
  YELLOW|_BLUE, CYAN|_BLUE, BLACK|_LGREY,
  10, PreMnuFil, 0,  0,  0, 0xFF, 0xFF, 0xFF
};

LCL   IbldT CDC   EditItems[] =
{  {  "Start block", 'S', ITM_BEF|ITM_ALL, 0, 0,
      20, EDT_H_BLOCK, 0, 0,
      NULL, _EdtBlkBeg, NULL,
      NULL, NULL
   },
   {  "End block", 'E', ITM_BEF|ITM_ALL, 1, 0,
      21, EDT_H_BLOCK, 0, 0,
      NULL, _EdtBlkEnd, NULL,
      NULL, NULL
   },
   { "Mark Word", 'W', ITM_BEF|ITM_ALL, 2, 0,
      22, EDT_H_BLOCK, 0, 0,
      NULL, _EdtBlkWrd, NULL,
      NULL, NULL
   },
   { "Mark To BOL", 'B', ITM_BEF|ITM_ALL, 3, 0,
      23, EDT_H_BLOCK, 0, 0,
      NULL, _EdtBlkBol, NULL,
      NULL, NULL
   },
   { "Mark To EOL", 'O', ITM_BEF|ITM_ALL, 4, 0,
      24, EDT_H_BLOCK, 0, 0,
      NULL, _EdtBlkEol, NULL,
      NULL, NULL
   },
   { "Move block", 'M', ITM_BEF|ITM_ALL, 6, 0,
      25, EDT_H_BLOCK, 0, 0,
      NULL, _EdtBlkMov, NULL,
      NULL, NULL
   },
   {  "Copy block", 'C', ITM_BEF|ITM_ALL, 7, 0,
      26, EDT_H_BLOCK, 0, 0,
      NULL, _EdtBlkCpy, NULL,
      NULL, NULL
   },
   {  "Paste block", 'P', ITM_BEF|ITM_ALL, 8, 0,
      27, EDT_H_BLOCK, 0, 0,
      NULL, _EdtBlkPut, NULL,
      NULL, NULL
   },
   {  "Del block", 'D', ITM_BEF|ITM_ALL, 9, 0,
      28, EDT_H_BLOCK, 0, 0,
      NULL, _EdtBlkDel, NULL,
      NULL, NULL
   },
   {  "Del EOL", 'l', ITM_BEF|ITM_ALL, 11, 0,
      29, EDT_H_BLOCK, 0, 0,
      NULL, _EdtDelEOL, NULL,
      NULL, NULL
   }
};

LCL   MbldT CDC   EditPD =
{  &EditItems[0],  10,  2,  8, 15, 25, MNU_PUL|MNU_SAV, BOX_SNG,
   WHITE|_BLUE, WHITE|_BLUE, WHITE|_BLUE,
   YELLOW|_BLUE, CYAN|_BLUE, BLACK|_LGREY,
   20, PreMnuEdt, 0,  0,  0, 0xFF, 0xFF, 0xFF
};

LCL   IbldT CDC   FindItms[] =
{  {  "Find...", 'F', ITM_BEF|ITM_ALL, 0, 0,
      30, EDT_H_FIND, 0, 0,
      NULL, _EdtSrchBeg, NULL,
      NULL, NULL
   },
   {  "Replace...", 'R', ITM_BEF|ITM_ALL, 1, 0,
      31, EDT_H_FIND, 0, 0,
      NULL, _EdtSrchRpl, NULL,
      NULL, NULL
   },
   {  "Again", 'A', ITM_BEF|ITM_ALL, 2, 0,
      32, EDT_H_FIND, 0, 0,
      NULL, _EdtSrchNxt, NULL,
      NULL, NULL
   },
   {  "Goto Line...", 'G', ITM_BEF|ITM_ALL, 4, 0,
      33, EDT_H_FIND, 0, 0,
      NULL, GotoLine, NULL,
      NULL, NULL
   }
};

LCL   MbldT CDC   FindPD =
{  &FindItms[0],  4,  2, 14,  8, 28, MNU_PUL|MNU_SAV, BOX_SNG,
   WHITE|_BLUE, WHITE|_BLUE, WHITE|_BLUE,
   YELLOW|_BLUE, CYAN|_BLUE, BLACK|_LGREY,
   30, PreMnuFnd, 0,  0,  0, 0xFF, 0xFF, 0xFF
};

LCL   IbldT CDC   HelpItms[] =
{  {  "Index", 'I', ITM_BEF|ITM_ALL, 0, 0,
      40, 0x0000, 0, 0,
      NULL, _EdtHlpNdx, NULL,
      NULL, NULL
   },
   {  "Commands", 'C', ITM_BEF|ITM_ALL, 1, 0,
      41, 0x0000, 0, 0,
      NULL, _EdtHlpCmd, NULL,
      NULL, NULL
   },
   {  "Procedures", 'P', ITM_BEF|ITM_ALL, 2, 0,
      42, 0x0000, 0, 0,
      NULL, _EdtHlpPro, NULL,
      NULL, NULL
   },
   {  "Editor Keys", 'E', ITM_BEF|ITM_ALL, 3, 0,
      43, 0x0000, 0, 0,
      NULL, _EdtHlpKey, NULL,
      NULL, NULL
   },
   {  "Using Help", 'U', ITM_BEF|ITM_ALL, 4, 0,
      44, 0x0000, 0, 0,
      NULL, _EdtHlpHlp, NULL,
      NULL, NULL
   },
   {  "About EdtDemo", 'A', ITM_BEF|ITM_ALL, 6, 0,
      45, 0x0000, 0, 0,
      NULL, About, NULL,
      NULL, NULL
   }
};

LCL   MbldT CDC   HelpPD =
{  &HelpItms[0],  6,  2, 22, 10, 37, MNU_PUL|MNU_SAV, BOX_SNG,
   WHITE|_BLUE, WHITE|_BLUE, WHITE|_BLUE,
   YELLOW|_BLUE, CYAN|_BLUE, BLACK|_LGREY,
   40, PreMnuHlp, 0,  0,  0, 0xFF, 0xFF, 0xFF
};

LCL IbldT CDC MainItms[] =
{  {  "File", 'F', ITM_PUL|ITM_ALL, 0, 1,
      1, 0, Key_A_F, 0,
      NULL, NULL, NULL,
      NULL, &FilePD
   },
   {  "Edit", 'E', ITM_PUL|ITM_ALL, 0, 7,
      2, 0, Key_A_E, 0,
      NULL, NULL, NULL,
      NULL, &EditPD
   },
   {  "Search", 'S', ITM_PUL|ITM_ALL, 0, 13,
      3, 0, Key_A_S, 0,
      NULL, NULL, NULL,
      NULL, &FindPD
   },
   { "Help", 'H', ITM_PUL|ITM_ALL, 0, 21,
      4, 0, Key_A_H, 0,
      NULL, NULL, NULL,
      NULL, &HelpPD
   }
};

LCL   MbldT CDC   MainMnu =
{  &MainItms[0],  4,  0,  0,  2, 0, MNU_HOR, BOX_SNG,
   WHITE|_BLUE, WHITE|_BLUE, WHITE|_BLUE,
   YELLOW|_BLUE, CYAN|_BLUE, BLACK|_LGREY,
   1, NULL, 0,  0,  0, 0xFF, 0xFF, 0xFF
};

LCL   IbldT CDC   QuitItms[] =
{  {  "Exit w/ save?", 'E', ITM_NOR, 1, 1,
      1, 0, 0x0000, 0,
      NULL, NULL, NULL,
      NULL, NULL
   },
   {  "Quit w/o save?", 'Q', ITM_NOR, 1, 17,
      2, 0, 0x0000, 0,
      NULL, NULL, NULL,
      NULL, NULL
   },
   {  "Cancel", 'C', ITM_NOR, 1, 34,
      0, 0, 0x0000, 0,
      NULL, NULL, NULL,
      NULL, NULL
   }
};

LCL   MbldT CDC   QuitMnu =
{  &QuitItms[0],  3, 15, 18, 19, 60, MNU_HOR|MNU_USE, BOX_SNG,
   WHITE|_RED, WHITE|_RED, YELLOW|_RED,
   WHITE|_RED, LGREY|_BLACK, BLACK|_LGREY,
   1, NULL, 0,  0,  0, 0xFF, 0xFF, 0xFF
};

VOID  CTYP  AddShadow(NOARG)
{
   Wshadow(LGREY|_BLACK);
}

VOID CTYP PreMnuFil(NOARG)
{
   WdrwHor(2, 0, 13, BOX_SNG, WHITE|_BLUE);
   WdrwHor(5, 0, 13, BOX_SNG, WHITE|_BLUE);
   WdrwHor(7, 0, 13, BOX_SNG, WHITE|_BLUE);
   AddShadow();
}

VOID CTYP PreMnuEdt(NOARG)
{
   WdrwHor(5, 0, 16, BOX_SNG, WHITE|_BLUE);
   WdrwHor(10, 0, 16, BOX_SNG, WHITE|_BLUE);
   AddShadow();
}

VOID CTYP PreMnuFnd(NOARG)
{
   WdrwHor(3, 0, 13, BOX_SNG, WHITE|_BLUE);
   AddShadow();
}

VOID CTYP PreMnuHlp(NOARG)
{
   WdrwHor(5, 0, 14, BOX_SNG, WHITE|_BLUE);
   AddShadow();
}


VOID  CTYP  GotoLine(NOARG)
{
   ChrT  LineNum[6];

   WpopUp(CNT_CNT, 0, 0, 4, 19, BOX_SNG, WHITE|_RED, YELLOW|_RED);
   AddShadow();
   Wputc('\n');
   Wputs(" Goto line:");
   EntDef(BLACK|_LGREY, BLACK|_LGREY, 1);
   EntFld( 1, 12, LineNum, "#####", FLD_LJS, 0, FLD_INI, NULL, 0);
   EntGet(0);
   Wclose();
   if(LineNum[0] != EOS)
      _EdtGoto((WrdT)atoi(LineNum));
}


VOID  CTYP  About(NOARG)
{
   ChrT  buf[256];

#if (_TCXL_gui_ == 0)
   _IcnTbl[4] = &iconTESS;
#elif (_TCXL_gui_ == 1)
   _IcnTbl[4] = LoadIcon(_MswThs, "TESS");
#elif (_TCXL_gui_ == 2)
   _IcnTbl[4] = WinLoadPointer(HWND_DESKTOP, HNULL, TPM_TESS);
#endif

   sprintf(buf, _AbtStr, _EdtVer() >> 8, _EdtVer() & 0xff,
         DEMO_VER >> 8, DEMO_VER & 0xff);

   MouPush(MOU_FULL);
   MsgBox(4, 40, BLACK|_CYAN, WHITE|_CYAN, buf, 0, _OkStr);
   MouPop();
}

VOID  CTYP  OpenFile(NOARG)
{
   REG EdtP e = EdctCur;
   ChrP     pck;
   WndT     wh;
   WdfP     w;
   VposT    v1, v2;

   wh = WpopUp(CNT_CNT, 0, 0, 12, 32, BOX_SNG, WHITE|_RED, YELLOW|_RED);
   AddShadow();
   Wtitle("[ Open ]", TTL_CNT, WHITE|_RED);
   WdrwHor(1, 0, 33, BOX_SNG, WHITE|_RED);

   w = WinLoc(wh);
   VposW(v1) = WdfBegW(w);
   VposW(v2) = WdfEndW(w);
   VposR(v1) += 3;
   VposC(v1)++;
   VposDec(v2);

   FileFrm.efld = &FileFld1[0];
   EntBuild(&FileFrm);
   EntGet(0);
   pck = SelFile(VposR(v1), VposC(v1), VposR(v2), VposC(v2), BOX_SPA, 0,
      WHITE|_RED, BLACK|_LGREY, 0, FileSpec, NULL);
   if(NULL != pck)
      _Scpy(EdtNam(e), pck);
   SelFree();
   Wclose();
}


VOID  CTYP  ConfSav(NOARG)
{
   REG EdtP e = EdctCur;
   ChrT     c;

   if(NULL != (strstr(EdtNam(e), "DEMO\\EDTDEMO.C")))
   {  Wperror("Cannot Save Over Editor Demo Program!");
      return;
   }
   WpopUp(CNT_CNT, 0, 0, 4, 32, BOX_SNG, WHITE|_RED, YELLOW|_RED);
   AddShadow();
   Wtitle("[ Confirm Save ]", TTL_CNT, WHITE|_RED);
   Wputc('\n');
   WputCen("Do you really want to save? ");
   Wputc(NlsYes);
   Wputc('\b');
   c = KwGetYn(NlsYes);
   if(c == 'Y')
      EdtInt(e) |= EDT_OKS;
   Wclose();
}


VOID  CTYP  SaveAs(NOARG)
{
   REG EdtP e = EdctCur;
   ChrT     ttl[32], fn[64];

   WpopUp(CNT_CNT, 0, 0, 2, 32, BOX_SNG, WHITE|_RED, YELLOW|_RED);
   AddShadow();
   if(EdtExp(e))
      _Scpy(ttl, "[Save Block As... ]");
   else
      _Scpy(ttl, "[Save As... ]");
   Wtitle(ttl, TTL_CNT, WHITE|_RED);

   fn[0] = EOS;
   FileFld2[0].fstr = fn;
   FileFrm.efld = &FileFld2[0];
   EntBuild(&FileFrm);
   FileFld2[0].fstr = FileName;

   EntGet(0);
   _Scpy(EdtNam(e), fn);
   if(EOS != fn[0])
      EdtInt(e) |= EDT_OKS;
   Wclose();
}

VOID  CTYP  ConfRpl(NOARG)
{
   REG EdtP e = EdctCur;
   WdfP     w = _EdtWin();
   TagT     rc;
   VposT    x, o;
   WrdT     r, p, q;

   MouPush(MOU_FULL);

   x = WdfWin(w);
   o = WdfOrg(w);

   r = VposR(x) - VposR(o) + WdfMinR(w);  /* display position */
   p = (VidDep >> 1) - 5;
   q = (VidWid >> 1) - 13;

   if((VposC(x) >= q) || (VposC(x) + EdtSln(e) <= q + 13))
   {  if((r >= p) && (r < p + 10))
      {  VposR(o) += (r - p + 1);
         if(VposR(o) < WdfShaR(w) - WdfSizR(w))
            WinPositionV(w, VposW(o));
      }
   }

   rc = MsgBox(ICON_QUERY, 17, WHITE|_RED, WHITE|_RED, _ReplStr, 0, _YesNo);
   MouPop();

   switch(rc)
   {  case 1:
         EdtFlg(e) &= ~EDT_REP;
         break;
      case 2:
         EdtFlg(e) |= EDT_RPA;
      case 0:                   /* fall through!!!!!                    */
         break;
      default:
         EdtFlg(e) &= ~(EDT_REP|EDT_GBL|EDT_RPA);
         break;
   }
}

VOID  CTYP  Search(NOARG)
{
   REG EdtP e = EdctCur;
   TagT     rc;

   WpopUp(CNT_CNT, 0, 0, 10, 35, BOX_SNG, YELLOW|_RED, WHITE|_RED);
   AddShadow();
   if(EdtRep(e))
   {  Wtitle("[ Search/Replace ]", TTL_CNT, YELLOW|_RED);
      SrchFlds[1].fmsk &= ~FLD_DIS;
      SrchFlds[4].fmsk &= ~FLD_DIS;
      SrchFlds[5].fmsk &= ~FLD_DIS;
   }
   else
   {  Wtitle("[ Search ]", TTL_CNT, YELLOW|_RED);
      SrchFlds[1].fmsk |= FLD_DIS;
      SrchFlds[4].fmsk |= FLD_DIS;
      SrchFlds[5].fmsk |= FLD_DIS;
   }

   EntBuild(&SrchFrm);
   rc = EntGet(0);
   Wclose();

   if(EOS != SrchStr[0] && rc != -1)
   {  _Scpy(EdtSch(e), SrchStr);
      EdtSln(e) = (WrdT)_Slen(SrchStr);

      _Scpy(EdtRpl(e), ReplStr);

      if(*SrchDir == 'F' && EdtSup(e))
         _EdtSrchDir();
      else if(*SrchDir == 'B' && EdtSdn(e))
         _EdtSrchDir();

      if(*SrchCase == 'Y')
         EdtFlg(e) |= EDT_CAS;
      else
         EdtFlg(e) &= ~EDT_CAS;

      if(*SrchConf == 'N')
         EdtFlg(e) |= EDT_RPA;
      else
         EdtFlg(e) &= ~EDT_RPA;

      if(*SrchGbl == 'Y')
         EdtFlg(e) |= EDT_GBL;
      else
         EdtFlg(e) &= ~EDT_GBL;
   }
   else
      EdtSln(e) = 0;
}

VOID CTYP Status(NOARG)
{
   REG EdtP  e = EdctCur;
   WdfP      w = _EdtWin();
   EposP     p = &EdtCur(e);
   LCL  ChrT Fnm[15] = "";
   ChrT      tbuf[80];
   ChrP      s;

   if((s = strrchr(EdtNam(e), '\\')) == NULL)
      s = EdtNam(e);
   else
      s++;
   if(_Scmp(s, Fnm) != 0)
   {  _Scpy(Fnm, s);
      sprintf(tbuf, "[File: %s]", Fnm);
      WtitleV(w, tbuf, TTL_LFT, WHITE|_BLUE);
   }
   sprintf(tbuf, "[Ln %4d/%4ld  Col %4d  %c]", EposLin(p), EdtLus(e),
      EposCol(p), (EdtVew(e) ? 'V' : (EdtIns(e) ? 'I' : 'O')));
   WmessageV(w, tbuf, BRD_TOP, VidWid - (_Slen(tbuf) + 3), WHITE|_BLUE);
}

VOID CTYP ReadFile(NOARG)
{
   REG EdtP  e = EdctCur;
   ChrP      s = EdtIob(e);
   WrdT      l = EdtLin(e);
   LCL WndT  wh = -1;
   LCL DwdT  bt = 0;
   ChrP      p;

   if(wh == -1)
   {  MouPush(MOU_NONE);
      CurHide();
      wh = WpopUp(CNT_CNT, 0, 0, 4, 23, BOX_SNG, YELLOW|_RED, WHITE|_RED);
      AddShadow();
      if((p = strrchr(EdtNam(e), '\\')) == NULL)
         p = EdtNam(e);
      else
         p++;
      if(EdtImp(e))
         WVputf(wh, "Importing: %s\n  Line:\n Bytes:", p);
      else
         WVputf(wh, "Reading: %s\n  Line:\n Bytes:", p);
   }
   if(l == NEG1)
   {  WVclose(wh);
      wh = -1;
      bt = 0;
      CurShow();
      MouPop();
   }
   else
   {  bt += _Slen(s) + 1;
      WVprtf(wh, 1, 9, WHITE|_RED, "%8u", l);
      WVprtf(wh, 2, 9, WHITE|_RED, "%8lu", bt);
   }
}


VOID  CTYP  ConfQuit(NOARG)
{
   REG EdtP  e = EdctCur;
   TagT  t;


   CurPush(CUR_HID, 0, 0, 0);
   WpopUp(CNT_CNT, 0, 0, 4, 42, BOX_SNG, YELLOW|_RED, WHITE|_RED);
   AddShadow();
   MnuBuild(&QuitMnu);
   t = MnuGet();
   Wclose();

   switch(t)
   {  case  1:                         /* Exit w/ save               */
         EdtInt(e) |= EDT_QIT;
         break;

      case  2:                         /* Quit w/o save              */
         EdtInt(e) &= ~EDT_CHG;
         EdtInt(e) |= EDT_QIT;
         break;

      default:                         /* do nothing                 */
         break;
   }
   CurPop();
}


VOID CTYP DoEditor(ChrP f)
{
   EdhT  eh;

   MnuBuild(&MainMnu);
   MnuKeep();
   CurPush(CUR_HID, 0, 0, 0);
   MnuDsp();

   sr = 3;
   er = VidDep - 1;
   sc = 0;
   ec = VidWid - 1;

   if(f == NULL)
#ifdef USE_BIG_FILE
      _Scpy(FileName, "DOC\\TCXLDOS.TXT");
#else
      _Scpy(FileName, "DEMO\\EDTDEMO.C");
#endif
   else
      _Scpy(FileName, f);

   eh = EdtDef(sr, sc, er, ec, BOX_DBL, WHITE|_BLUE, WHITE|_BLUE,
#if 1
      BLACK|_LGREY, 128, NULL);
#else
      BLACK|_LGREY, 78, NULL);
#endif

   EdtSetMenu();

   EdtSetHlpGen(EDT_H_GEN);
   EdtSetHlpNdx(EDT_H_NDX);
   EdtSetHlpCmd(EDT_H_CMD);
   EdtSetHlpPro(EDT_H_PRO);
   EdtSetHlpKey(EDT_H_KEY);
   EdtSetHlpHlp(EDT_H_HLP);

   EdtSetSrch(Search);
   EdtSetConf(ConfRpl);
   EdtSetStat(Status);
   EdtSetRead(ReadFile);
   EdtSetOpen(OpenFile);
   EdtSetSave(ConfSav);
   EdtSetSvas(SaveAs);
   EdtSetExit(ConfQuit);

   EdtEnd(EDT_FIL|EDT_INS, 3, FileName, NULL, Ignore);
   EdtGet(eh);
   EdtFree(eh);

   CurPop();
   MnuFree();
}

#if (_TCXL_gui_ == 0)
RegT  CDC   main(RegT argc, ChrP argv[])
#else
int   CDC   TcxlMain(int argc, char *argv[])
#endif
{
   argc = argc;

#ifdef USE_BIG_FILE
   TvmPageMax = 384;
#endif
   MsgHlpName("EDTDEMO.MSG");
   TcxlInit();
   MainMnu.menc = VidWid-1;

   HlpDef("EDTDEMO.MSG", Key_F1,       /* initialize help system,       */
      YELLOW|_RED, YELLOW|_RED,        /*  help key = [F1]              */
      LRED|_RED, WHITE|_RED, RED|_LGREY, BOX_DBL, _VFVCP(AddShadow));
   HlpPush(H_GLOBAL);                  /* push global help category     */

   DoEditor(argv[1]);

   WcloseAll();
   return(0);
}
