/*============[ The TesSeRact(TM) File Management System ]==============*
 | Copyright (c) 1987-1993, Innovative Data Concepts, Inc.
 | All Rights Reserved.
 |
 | This Library is part of IDC's TesSeRact Development Tools product
 | line. For information about other IDC products, call 1-215-443-9705.
 *-V--------------------------------------------------------------------*
 | $Header:   tfildemo.c     600.15   24 Jul 1993 10:51:52  $
 |
 | $Log:   tfildemo.c    $
 *-D--------------------------------------------------------------------*
 | TfilDemo.c
 *-N-----------------------[ Notes and caveats ]------------------------*
 |
 *======================================================================*/

#include "demo\tfildemo.h"
#include <TCXLmnu.h>
#include <TCXLent.h>
#include <TCXLcod.h>
#include <TCXLico.h>

/*========================[ Function prototypes ]=======================*/

IntT  CTYP  ParseCmdLine(IntT ac, ChrP av[]);
VOID  CTYP  Initialize(NOARG);
VOID  CTYP  PrepMsgs(NOARG);
VOID  CTYP  FreeMsgs(NOARG);
VOID  CTYP  OpenBkgrnd(NOARG);
VOID  CTYP  AddShadow(NOARG);
VOID  CTYP  ErrorExit(IntT e);
FlgT  CTYP  ConfirmDelete(NOARG);
VOID  CTYP  FileDemo(NOARG);
VOID  CTYP  BuildKey(ChrP buf);
IntT  CTYP  WriteRec(HdlDbf dfd, HdlNdx ifd, RNum rec, FlgT f1, FlgT f2);


/*----------------------------[ Global data ]---------------------------*/

IntT  CDC   LeftRow, LeftCol;          /* main menu coords              */
IntT  CDC   RightRow, RightCol;

LCL   ChrP  CDC   error_text[] =       /* global error message table    */
{  NULL,                               /* errnum = 0, no error          */
   NULL,                               /* errnum = 1, windowing error   */
   NULL,                               /* errnum = 2, out of memory     */
   NULL                                /* errnum = 3, TFile error       */
};

/*==============[ Generated structures for MAIL database ]==============*/

#include "mail.inc"

/*----------[ Demo entry form-build and field-build objects ]-----------*/
#define  DEMO_CNT  7

LCL   FbldT   CDC   DemItm[DEMO_CNT] = /*- field-build object list --   */
{  {   NULL,  1,  3,                   /* prompt                        */
       MailEntBuf.Firstname,           /* buffer                        */
       1, 16, NULL,                    /* position, format              */
       NULL, NULL, NULL,               /* "before", "valid", "after"    */
       Key_A_F,  1, 0,                 /* hotkey, item-tag, help-tag    */
       FLD_NUL, 0, FLD_CND             /* features, user, input-mode    */
   },
   {   NULL,  3,  3,                   /* prompt                        */
       MailEntBuf.Lastname,            /* buffer                        */
       3, 16, NULL,                    /* position, format              */
       NULL, NULL, NULL,               /* "before", "valid", "after"    */
       Key_A_L,  2, 0,                 /* hotkey, item-tag, help-tag    */
       FLD_NUL, 0, FLD_CND             /* features, user, input-mode    */
   },
   {   NULL,  5,  3,                   /* prompt, buffer                */
       MailEntBuf.Company,             /* buffer                        */
       5, 16, NULL,
       NULL, NULL, NULL,               /* "before", "valid", "after"    */
       Key_A_O,  3, 0,                 /* hotkey, item-tag, help-tag    */
       FLD_NUL | FLD_TRM, 0, FLD_CND   /* features, user, input-mode    */
   },
   {   NULL,  7,  3,                   /* prompt                        */
       MailEntBuf.Address1,
       7, 16, NULL,
       NULL, NULL, NULL,               /* "before", "valid", "after"    */
       Key_A_A,  4, 0,                 /* hotkey, item-tag, help-tag    */
       FLD_NUL | FLD_TRM, 0, FLD_CND   /* features, user, input-mode    */
   },
   {   NULL,   9,  3,                  /* prompt                        */
       MailEntBuf.City,                /* buffer                        */
       9, 16, NULL,                    /* position, format              */
       NULL, NULL, NULL,               /* "before", "valid", "after"    */
       Key_A_C,  5, 0,                 /* hotkey, item-tag, help-tag    */
       FLD_MIX, 0, FLD_CND             /* features, user, input-mode    */
   },
   {   NULL,   9, 41,                  /* prompt, buffer                */
       MailEntBuf.State,               /* buffer                        */
       9, 41, NULL,                    /* position, format              */
       NULL, NULL, NULL,               /* "before", "valid", "after"    */
       Key_A_S,  6, 0,                 /* hotkey, item-tag, help-tag    */
       FLD_UPR, 0, FLD_CND             /* features, user, input-mode    */
   },
   {   NULL,   9, 45,                  /* prompt                        */
       MailEntBuf.Zip,                 /* buffer                        */
       9, 50, NULL,                    /* position, format              */
       NULL, NULL, NULL,               /* "before", "valid", "after"    */
       Key_A_Z,  7, 0,                 /* hotkey, item-tag, help-tag    */
       FLD_NUL, 0, FLD_CND             /* features, user, input-mode    */
   },
};

LCL   EbldT   CDC   DemFrm =              /*- form-build object --------*/
{  &DemItm[0], DEMO_CNT,                  /* field-build list, count    */
   NULL, NULL,                            /* getkey(), key-buffer       */
   0, ENT_SAV|ENT_WRP,                    /* user, options              */
   WHITE|_BLUE, BLUE|_LGREY,              /* prompt, field attributes   */
   WHITE|_LGREY, BLUE|_LGREY              /* highlight, disabled attrs  */
};

ChrP KeyOrd, RecOrd, DemoText;
ChrP FilMod[4];

TYP enum _filopts
{  Browse = 0,
   Enter  = 1,
   Edit   = 2,
   Delete = 3
}  FilOpT;

ChrT KeyBuf[100];
ChrT OldKey[100];

IntT  Index;


/*======================[ The TFile Demo Program ]======================*/

#if (_TCXL_gui_ > 0)
IntT  CDC   TcxlMain(IntT ac, ChrP av[])
#else
RegT  CDC   main(RegT ac, ChrP av[])
#endif
{
   Index = ParseCmdLine((IntT)ac, av);
   Initialize();                       /* initialize TCXL               */
   OpenBkgrnd();                       /* build screen                  */
   FileDemo();                         /* run the demo                  */
   WcloseAll();
   CurPop();                           /* restore the cursor            */
   FreeMsgs();
   return(0);                          /* _TcxlTerm() will clean up     */
}  /* main */


IntT  CTYP  ParseCmdLine(IntT ac, ChrP av[])
{
   REG IntT    i, j;
   IntT        rc = -1;
   ChrP        p;


   for(i = 1; i < ac; i++)
   {  p = av[i];
      if(*p == '-' || *p == '/')
      {  for(j = 1; *(p + j); j++)
         {  switch(NlsToLower(*(p + j)))
            {  case 'd':               /* Browse from .NDX index        */
                  rc = 0;
                  break;

               case 't':               /* Browse from .NTX index        */
                  rc = 1;
                  break;

               default:                /* unknown switch                */
                  rc =0;               /* default to .NDX               */
            }
         }
      }
      else                             /* unknown parameter             */
         rc = 0;
   }

   return(rc);
}  /* ParseCmdLine() */

/*===============[ Initialize TCXL for the demo program ]===============*/

VOID  CTYP  Initialize(NOARG)
{
   MsgHlpName("TFILDEMO.MSG");
   TcxlMouOff();                       /* turn off mouse support        */
   TcxlInit();                         /* general initialization        */
   KextOff();                          /* no extended key BIOS          */
   CurPush(CUR_HID, CUR_NOR, 0, 0);    /* save the cursor state, hide   */
                                       /*    and home the cursor        */
   LeftRow = ((VidDep - 1) / 2) - 3;   /* set up display coordinates    */
   RightRow = (IntT)(LeftRow + 5);
   LeftCol = ((VidWid - 1) / 2) - 9;
   RightCol = (IntT)(LeftCol + 19);

   PrepMsgs();
}  /* Initialize */


/*=================[ Get text from the message system ]=================*/

VOID  CTYP  PrepMsgs(NOARG)
{
   DemoText = MsgRead(TF_TEXT);
   error_text[2] = MsgRead(TF_MEMERR);
   error_text[3] = MsgRead(TF_TFERR);
   EntPrepMsg(&DemFrm, TF_MNUPMT1, TF_MNUFMT1);
   KeyOrd = MsgRead(TF_KEYORD);
   RecOrd = MsgRead(TF_RECORD);
   FilMod[0] = MsgRead(TF_BROWSE);
   FilMod[1] = MsgRead(TF_ENTER);
   FilMod[2] = MsgRead(TF_EDIT);
   FilMod[3] = MsgRead(TF_DELETE);
}

VOID  CTYP  FreeMsgs(NOARG)
{
   FreeN(DemoText);
   FreeN(error_text[2]);
   FreeN(error_text[3]);
   EntFreeMsg(&DemFrm);
   FreeN(KeyOrd);
   FreeN(RecOrd);
   FreeN(FilMod[0]);
   FreeN(FilMod[1]);
   FreeN(FilMod[2]);
   FreeN(FilMod[3]);
}


/*==[ Main background, program title and system information windows ]===*/

VOID  CTYP  OpenBkgrnd(NOARG)
{
                                       /* demo background window        */
   if(ERR_ARG == WopenFull(LGREEN|_GREEN))
      ErrorExit(1);                    /* windowing error!              */

                                       /* program title pop-up          */
   if(!WpopUp(CNT_HOR, 0, 12, 4, 67, 0, LRED|_MAGENTA, LRED|_MAGENTA))
      ErrorExit(1);                    /* windowing error!              */
   AddShadow();                        /* add a shadow, display text    */
   WprtCen(0, WHITE|_MAGENTA, MsgPeek(TF_HELLO1));
   WprtCen(2, LCYAN|_MAGENTA, MsgPeek(TF_HELLO2));
}  /* OpenBkgrnd */

/*================[ Add a shadow to the current window ]================*/

VOID CTYP AddShadow(NOARG)
{
   Wshadow(LGREY|_BLACK);              /* simple, ain't it?             */
}  /* AddShadow */

/*=======================[ Abnormal termination ]=======================*/

VOID CTYP ErrorExit(IntT e)
{
   if(e)
   {  if(!TcxlErr)
         Wperror(error_text[e]);
      else if(Wperror(WerrMsg()))
      {  if(e == 1)                    /* window-system error           */
            Werror();
         else
#if (_TCXL_gui_ > 0)
            ErrorBox("%s", error_text[e]);
#else
            printf("\n%s\n", error_text[e]);
#endif
      }
      CurPop();                        /* restore cursor                */
      exit(e);                         /* _TcxlTerm() will clean up     */
   }
}  /* ErrorExit */


/*======================[ Confirm record deletion ]=====================*/

FlgT  CTYP  ConfirmDelete(NOARG)
{
   ChrP  YesNo[3], QuitMsg;
   FlgT  f;

   QuitMsg  = MsgRead(TF_DELMSG);
   YesNo[0] = MsgRead(TF_YES);
   YesNo[1] = MsgRead(TF_NO);
   YesNo[2] = NULL;

   if(!MsgBox(ICON_EXCL, 22, WHITE|_BROWN, WHITE|_BROWN, QuitMsg,
      0, (ChrI)YesNo))
      f = TRUE;
   else
      f = FALSE;

   FreeN(YesNo[0]);
   FreeN(YesNo[1]);
   FreeN(QuitMsg);
   return(f);
}  /* ConfirmDelete() */

/*=========================[ Interactive demo ]=========================*/

VOID  CTYP  FileDemo(NOARG)
{
   KeyT     k = 0;
   HdlDbf   dfd;
   HdlNdx   ifd[2];
   IntT     Ord = 0;
   FilOpT   Op = Browse;
   RNum     record, nxt, count, new;
   ChrT     RecNo[30], OpMsg[11];
   ChrP     p;

   CurSave();                          /* save cursor state             */

   if(!WpopUp(CNT_CNT, 0, 0, 17, 60, BOX_DBL, LCYAN|_BLUE, LCYAN|_BLUE))
      ErrorExit(1);
   Wtitle(MsgPeek(TF_TITLE), TTL_CNT, LCYAN|_BLUE);
   AddShadow();

   Wputsw(DemoText);
   WputCen(MsgPeek(TF_PRESS));
   KeyGetc();

   Wclose();

   DemFrm.etrm = &k;                   /* key-buffer                    */

   if(TF_ERROR == (dfd = TfdOpen("mail")))
      ErrorExit(3);
   count = TfdSize(dfd);

   TfAutoFlush = TRUE;
   if(0 == Index)
   {  TfIndexType = NDX_NDX;
      ifd[0] = TfiOpen("mail");
      TfIndexType = NDX_NTX;
      ifd[1] = TfiOpen("mail");
   }
   else
   {  TfIndexType = NDX_NTX;
      ifd[0] = TfiOpen("mail");
      TfIndexType = NDX_NDX;
      ifd[1] = TfiOpen("mail");
   }
   if(TF_ERROR == ifd[0] || TF_ERROR == ifd[1])
      ErrorExit(3);

   nxt = record = TfiGetFst(ifd[0], KeyBuf);

   if(!WpopUp(CNT_HOR, VidDep - 4, 0, VidDep - 1, VidWid-1, 1, LCYAN|_RED, LCYAN|_RED))
      ErrorExit(1);                    /* windowing error!              */

   WputCen(MsgPeek(TF_HELP1));
   WputCen(MsgPeek(TF_HELP2));

   if(!WpopUp(CNT_HOR, (WrdT)(LeftRow-2), 8, (WrdT)(LeftRow+10),
         70, 1, LCYAN|_BLUE, LCYAN|_BLUE))
      ErrorExit(1);                    /* windowing error!              */

   AddShadow();                        /* add shadow, title, notes      */
   Wmessage(MsgPeek(TF_TITLE), BRD_TOP, 2, LCYAN|_BLUE);

   EntBuild(&DemFrm);                  /* build the form, with prompts  */
   EntSav();                           /* ??? save it for later         */

   p = MsgRead(TF_RECMSG);
   while(k != Key_Esc)
   {  strcpy(OpMsg, FilMod[Op]);
      Wmessage(OpMsg, BRD_TOP, 51, LCYAN|_BLUE);

      switch(Op)
      {  case  Browse:
            if(TfdRead(dfd, record, (ChrP) &MailRecBuf) == INACTIVE)
            {  switch(k)
               {  case Key_Up:
                  case Key_Lft:
                  case Key_Rgt:
                  case Key_Dwn:
                     KquePut(k);
                     break;
                  default:
                     if(record == count)
                        KquePut(Key_Up);
                     else
                        KquePut(Key_Dwn);
                     break;
               }
               break;
            }
            TfdBuf2Ent(dfd, (ChrP)&MailEntBuf, (ChrP)&MailRecBuf,
               SIZ(MailEntBuf));
            sprintf(RecNo, p, record, count);
            Wmessage(RecNo, BRD_BOT, 3, LCYAN|_BLUE);
            Wmessage((Ord ? RecOrd : KeyOrd), BRD_BOT, 45, LCYAN|_BLUE);
            EntDsp();
            break;

         case  Enter:
            Wmessage(NULL, BRD_BOT,  3, LCYAN|BLUE);
            memset(&MailEntBuf, 0, SIZ(MailEntBuf));
            if(EntGet(DemItm[0].ftag) > 0 && k != Key_Esc)
            {  new = TfdNewRec(dfd);
               if(WriteRec(dfd, ifd[0], new, FALSE, TRUE) != TF_OKAY)
               {  Wperror(MsgPeek(TF_NEWERR));
                  goto Leave;
               }
               if(WriteRec(dfd, ifd[1], new, FALSE, FALSE) != TF_OKAY)
               {  Wperror(MsgPeek(TF_NEWERR));
                  goto Leave;
               }
               count = TfdSize(dfd);
               nxt = record = TfiGetKey(ifd[0], KeyBuf);
               Op = Browse;
               continue;
            }
            break;

         case Edit:
            WsetEsc(TRUE);
            BuildKey(OldKey);
            if(EntGet(DemItm[0].ftag) > 0)
            {  if(k != Key_Esc)
               {  if(WriteRec(dfd, ifd[0], record, TRUE, TRUE) != TF_OKAY)
                  {  Wperror(MsgPeek(TF_EDITERR));
                     goto Leave;
                  }
                  if(WriteRec(dfd, ifd[1], record, TRUE, FALSE) != TF_OKAY)
                  {  Wperror(MsgPeek(TF_EDITERR));
                     goto Leave;
                  }
                  count = TfdSize(dfd);
                  nxt = record = TfiGetKey(ifd[0], KeyBuf);
               }
               Op = Browse;
               continue;
            }
            break;

         case Delete:
            if(ConfirmDelete())
            {  if(TfdDelete(dfd, record) != TF_OKAY)
               {  Wperror(MsgPeek(TF_DELDAT));
                  goto Leave;
               }
               BuildKey(KeyBuf);
               if(TfiDelKey(ifd[0], KeyBuf, record) != TF_OKAY)
               {  Wperror(MsgPeek(TF_DELNDX));
                  goto Leave;
               }
               BuildKey(KeyBuf);
               if(TfiDelKey(ifd[1], KeyBuf, record) != TF_OKAY)
               {  Wperror(MsgPeek(TF_DELNDX));
                  goto Leave;
               }
               count = TfdSize(dfd);
               record = TfiGetNxt(ifd[0], KeyBuf);
               if(record == 0L)
                  nxt = record = TfiGetPrv(ifd[0], KeyBuf);
               else
                  nxt = record;
            }
            Op = Browse;
            continue;
      }       

      if(Op == Browse)
      {  k = KeyGetc();
         switch(k)
         {  case  Key_F10:
               Ord ^= 1;
               if(Ord == 0)
                  record = nxt = TfiGetFst(ifd[0], KeyBuf);
               continue;

            case  Key_F9:
               if(Ord)
                  Wperror(MsgPeek(TF_BROREQ));
               else
                  Op = Edit;
               continue;

            case  Key_Ins:
               if(Ord)
                  Wperror(MsgPeek(TF_BROREQ));
               else
                  Op = Enter;
               continue;

            case  Key_Del:
               if(Ord)
                  Wperror(MsgPeek(TF_BROREQ));
               else
                  Op = Delete;
               continue;

            case  Key_Up:
            case  Key_Lft:
            case  Key_PgUp:
               if(Ord == 0)
                  nxt = TfiGetPrv(ifd[0], KeyBuf);
               else
                  nxt--;
               break;

            case  Key_Dwn:
            case  Key_Rgt:
            case  Key_PgDn:
               if(Ord == 0)
                  nxt = TfiGetNxt(ifd[0], KeyBuf);
               else
                  nxt++;
               break;

            case  Key_Home:
               if(Ord == 0)
                  nxt = TfiGetFst(ifd[0], KeyBuf);
               else
                  nxt = 1L;
               break;

            case  Key_End:
               if(Ord == 0)
                  nxt = TfiGetLst(ifd[0], KeyBuf);
               else
                  nxt = count;
               break;

            case  Key_Esc:
            default:
               continue;
         }

         if((nxt == 0L) || (nxt > count))
         {  if(!WpopUp(CNT_CNT, 9, 20, 12, 64, 0, WHITE|_RED, WHITE|_RED))
               ErrorExit(1);           /* windowing error!              */
            Beep();
            if((k == Key_Up) || (k == Key_Lft) || (k == Key_PgUp))
               WputCen(MsgPeek(TF_ALRFST));
            else
               WputCen(MsgPeek(TF_ALRLST));
            Wputc('\n');

            if(Ord == 0)
            {  if(k == Key_Up)
                  nxt = TfiGetNxt(ifd[0], KeyBuf);
               else
                  nxt = TfiGetPrv(ifd[0], KeyBuf);
            }
            else
            {  if(record == count)
                  k = Key_End;
               else if(record == 1)
                  k = Key_Home;
               nxt = record;
            }
            WputCen(MsgPeek(TF_PRESS));
            KeyGetc();
            Wclose();
         }
         record = nxt;
      }
   }

Leave:
   TfdClose(dfd);                      /* close the data file           */
   TfiClose(ifd[0]);                   /* close the index file          */
   TfiClose(ifd[1]);                   /* close the index file          */
   EntFree();                          /* free the form                 */
   Wclose();                           /* close window                  */
   Wclose();                           /* close window                  */
   CurPop();                           /* restore original cursor state */
   return;
}  /* FileDemo */


/*===================[ Build a key in the key buffer ]===================*/

VOID CTYP BuildKey(ChrP buf)
{
   IntT len = (IntT)strlen(MailEntBuf.Lastname);

   strcpy(buf, MailEntBuf.Lastname);
   memset(buf + len, ' ', 16 - len);
   buf[15] = EOS;
}  /* BuildKey */

/*=================[ Write a record into the database ]=================*/

IntT CTYP WriteRec(HdlDbf dfd, HdlNdx ifd, RNum rec, FlgT f1, FlgT f2)
{
   BuildKey(KeyBuf);

   if(f1)
   {  if(TfiChgKey(ifd, OldKey, KeyBuf, rec) == TF_ERROR)
         return TfErr;
   }
   else
   {  if(TfiPutKey(ifd, KeyBuf, rec) == TF_ERROR)
         return TfErr;
   }

   if(f2)
   {  TfdEnt2Buf(dfd, (ChrP)&MailRecBuf, (ChrP)&MailEntBuf);
      if(TfdWrite(dfd, rec, (ChrP)&MailRecBuf) == TF_ERROR)
         return TfErr;
   }

   return TF_OKAY;
}  /* NewEntry */


/*========================[ End of TfilDemo.c ]=========================*/
