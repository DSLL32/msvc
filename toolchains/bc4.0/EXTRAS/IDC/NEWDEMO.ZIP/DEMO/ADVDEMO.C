/*=====[ The TesSeRact(TM) CXL User Interface Development System ]======*
 | Copyright (c) 1987-1993, Innovative Data Concepts, Inc.
 | All Rights Reserved.
 |
 | This Library is part of IDC's TesSeRact Development Tools product
 | line. For information about other IDC products, call 1-215-443-9705.
 *-V--------------------------------------------------------------------*
 | $Header:   advdemo.c     200.10   24 Jul 1993 10:35:48  $
 |
 | $Log:   advdemo.c    $
 *-D--------------------------------------------------------------------*
 |
 *-N-----------------------[ Notes and Caveats ]------------------------*
 |
 *======================================================================*/
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <process.h>
#include <TCXLhlp.h>
#include <TCXLcur.h>
#include <TCXL_os.h>
#include <TCXLinp.h>
#include <TCXLadv.h>
#include <TCXLcod.h>
#include <TCXLnls.h>
#include <TCXLico.h>
#include "demo\AdvDemo.h"

LCL   ChrT  ChkDsk[255], MapMem[255];
LCL   BytT  InfoItm[25], ExitItm[25];
LCL   WndT  BotHdl;

/*===============[ Initialize TCXL for the demo program ]===============*/

VOID  CTYP  Initialize1(NOARG)
{
   MsgHlpName("ADVDEMO.MSG");
   TcxlInit();                         /* general initialization        */
   KextOff();                          /* no extended key BIOS          */
   CurPush(CUR_HID, CUR_NOR, 0, 0);    /* save the cursor state, hide   */
                                       /*    and home the cursor        */
   WsaveFull();

   MsgSave(H_INFOITM, InfoItm);
   MsgSave(H_EXITITM, ExitItm);
}  /* Initialize() */


VOID  CTYP  NormalExit(NOARG)
{
   KbndFre();
   WcloseAll();
   MouPop();                           /* restore the mouse             */
   CurPop();                           /* restore the cursor            */
   exit(0);                            /* _TcxlTerm() will clean up     */
}  /* NormalExit() */

/*======================[ Scroll the bottom window ]====================*/

VOID  CTYP  MoveBottom(NOARG)
{
   LCL BytT  di = DIR_LFT;
   LCL DwdT  t = 0;
   LCL WdfP  w = NULL;
   DwdT      x;
   VcelT     q;
   WdfP      p;

   if(w == NULL)
      w = WinLoc(BotHdl);

   if(t < (x = _Timer()))
   {  p = WctlCur;
      WctlCur = w;
      _Winp_(0L, &q, 1);
      WVscrWin(BotHdl, 1, di);
      WVprtc(BotHdl, 0, WdfShaC(w), VcelA(q), VcelC(q));
      t = x + 1;
      WctlCur = p;
   }
}

/*==[ Main background, program title and system information windows ]===*/

VOID  CTYP  OpenBkgrnd(NOARG)
{
   ChrP   p;

   if(0 > Wopen(0, 0, VidDep - 2, VidWid - 1, 5, 0, LGREEN|_GREEN))
      ErrorExit(1);                    /* windowing error!              */

   WsetFil('\xB0');                    /* bottom status bar, fancy fill */
   if(0 > (BotHdl = WVopen(VidDep - 1, 0, VidDep - 1, VidWid - 1, 1, 195, 0,
         5, 0, LGREY|_RED)))
      ErrorExit(1);                    /* windowing error!              */

   p = MsgPeek(H_F1MSG);
   Wprts(0,   1, LGREY|_RED, p);
   Wprts(0,  66, LGREY|_RED, p);
   Wprts(0, 131, LGREY|_RED, p);
   p = MsgPeek(H_SELMSG);
   Wprts(0,  35, LGREY|_RED, p);
   Wprts(0, 100, LGREY|_RED, p);
   Wprts(0, 165, LGREY|_RED, p);

   WsetFil(' ');                       /* blank fill again              */
                                       /* program title pop-up          */
   if(0 > WpopUp(CNT_HOR, 0, 12, 4, 67, 0, LRED|_MAGENTA, LRED|_MAGENTA))
      ErrorExit(1);                    /* windowing error!              */

   WprtCen(0, WHITE|_MAGENTA, MsgPeek(H_WELCOME));
   WprtCen(2, LCYAN|_MAGENTA, MsgPeek(H_CPYRGT));

   KbndIdle(MoveBottom);              /* start clock display           */
   KbndSet(Key_A_X, ConfirmQuit, 0);   /* bind [Alt-X] to ConfirmQuit() */

}  /* OpenBkgrnd() */

LCL VOID ShowText(WrdT TextNum)
{
   ChrP p;

   if(!WpopUp(CNT_CNT, 0, 0, 12, 60, BOX_DBL, LCYAN|_BLUE, LCYAN|_BLUE))
      ErrorExit(1);

   WdfLMar(WctlAct) += 1;
   Wputc('\n');

   p = MsgRead(TextNum);
   Wputsw(p);
   FreeN(p);

   Wputc('\n');
   Wputc('\n');
   WputCen(MsgPeek(ADVDEMO_0019));
   KeyGetc();

   Wclose();
}

VOID  CTYP  TSpawnDemo(FlgT f)
{
   WrdT Ret;
   ChrP s1, s2, s3, s4, s5, swap;

   if(f == TRUE)
      ShowText(ADVDEMO_0000);
   else
      ShowText(ADVDEMO_0011);

   KbndIdle(NULL);                     /* kill the clock                */

   MouPush(MOU_NONE);
   CurPush(CUR_SHO, -1, -1, -1);       /* show cursor, save state       */
   if(f == TRUE)
   {  if(!Wopen(5, 1, VidDep - 3, VidWid-3, 1, LCYAN|_BLUE, LCYAN|_BLUE))
         ErrorExit(1);
      Wtitle(MsgPeek(ADVDEMO_0020), TTL_RGT, LCYAN|_BLUE);
      TRedir(ON);
   }
   else
   {  WsaveFull();
      Vclear(LGREY|_BLACK);
      puts(MsgPeek(ADVDEMO_0021));
   }

   s1 = MsgRead(ADVDEMO_0022);
   s2 = MsgRead(ADVDEMO_0023);
   s3 = MsgRead(ADVDEMO_0024);
   s4 = MsgRead(ADVDEMO_0025);
   s5 = MsgRead(ADVDEMO_0026);
   swap = MsgRead(ADVDEMO_0027);

   _EvtSave();

   printf(s1, ChkDsk);
   spawnl(P_WAIT, ChkDsk, ChkDsk, NULL);
   putchar('\n');
   if(MapMem[0] != '\0')
   {  printf(s2, MapMem);
      spawnl(P_WAIT, MapMem, MapMem, NULL);
   }
   puts(s5);
   while(_KeyHit())
      _KeyGet();
   _KeyGet();

   putchar('\n');
   printf(s3, ChkDsk);
   TSpawn(ChkDsk, "", &Ret, "POWERPAK.SW1", TS_AUTO);
   putchar('\n');
   if(MapMem[0] != '\0')
   {  printf(s4, MapMem);
      TSpawn(MapMem, "", &Ret, "POWERPAK.SW1", TS_AUTO);
   }
   puts(s5);
   while(_KeyHit())
      _KeyGet();
   _KeyGet();

   _EvtRestore();

   FreeN(swap);
   FreeN(s5);
   FreeN(s4);
   FreeN(s3);
   FreeN(s2);
   FreeN(s1);


   if(f == TRUE)
      TRedir(OFF);

   KbndIdle(MoveBottom);              /* start clock display           */

   Wclose();
   CurPop();
   MouPop();
}

RegT  CDC   main(RegT argc, ChrP argv[])
{
   IntT  rc;
   
   TcxlMemOff();
   Initialize1();                       /* initialize TCXL               */
   rc = ParseCmdLine(argc, argv);       /* parse any options             */
   if(rc == 2)
      ErrorExit(2);

   OpenBkgrnd();                       /* build screen                  */

   if(_FilFnd(MsgPeek(ADVDEMO_0033), ChkDsk))
      _FilFnd(MsgPeek(ADVDEMO_0034), ChkDsk);

   if(_FilFnd(MsgPeek(ADVDEMO_0035), MapMem))
      if(_FilFnd(MsgPeek(ADVDEMO_0036), MapMem))
         if(_FilFnd(MsgPeek(ADVDEMO_0037), MapMem))
            if(_FilFnd(MsgPeek(ADVDEMO_0038), MapMem))
               MapMem[0] = '\0';

   TSpawnDemo(FALSE);
   TSpawnDemo(TRUE);
   ShowText(ADVDEMO_0012);
   NormalExit();                       /* we're done                    */
   return(0);                          /* *** never executed ***        */
}
