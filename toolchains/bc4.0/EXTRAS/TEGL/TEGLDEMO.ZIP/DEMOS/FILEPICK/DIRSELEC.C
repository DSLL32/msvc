/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
#include <teglsys.h>
#include <io.h> 		/* open */
#include <string.h>		/* strlen */
#include <stdio.h>		/* sprintf */
#include <fcntl.h>		/* O_RDONLY */

#ifdef TURBOC
#include <dir.h>		/* maxpath */
#else
#include <stdlib.h>		/* maxpath */
#endif

extern	unsigned _stklen=12000;

char *selectedfilename = "NO FILE SELECTED";

unsigned exitoption(imagestkptr fs,msclickptr ms)
{
    abortexit(selectedfilename);
    return 0;
}


unsigned char _fexists(char *filename)
{
    int retc;

    if ((retc = open(filename,O_RDONLY|O_BINARY))!=-1)
       close(retc);

    return ((retc != -1) && (strlen(filename)!= 0));
}


unsigned dirselect(imagestkptr ifs,msclickptr ms)
{
    char dr[MAXDRIVE];
    char d[MAXDIR];
    char n[MAXFILE];
    char e[MAXEXT];
    char s1[50];

    selectedfilename = getselectedfilename(ifs);

    if (!_fexists(selectedfilename)) {
	fnsplit(selectedfilename,dr,d,n,e);
	ifs = openerrorframe(300,150,"Open File");
	sprintf(s1,"Cannot find file %s%s\r\r",n,e);
	writefs(ifs,s1);
	writefs(ifs,"Check to ensure the path and filename are correct.");
    } else {
	dropstackimage(ifs);
	resetframeactive(stackptr,TRUE);

	fnsplit(selectedfilename,dr,d,n,e);
	ifs = openerrorframe(300,150,"Select a File");
	sprintf(s1,"Thank you for selecting %s%s\r\r",n,e);
	writefs(ifs,s1);
	writefs(ifs,"Do you wish to delete the file?");
    }
    return 0;
}


unsigned openfileselect(imagestkptr ifs,msclickptr ms)
{
    openfileselection(".","Open File",dirselect,(callproc)NULL);
    return 0;
}


void createmenubarevents(void)
{
    optionmptr om1;

    setproportional(TRUE);
    om1 = createoptionmenu((fontptr)roman25);
    defineoptions(om1,"~O~pen",TRUE,openfileselect);
    defineoptions(om1,"--",FALSE,NULL);
    defineoptions(om1,"~Q~uit",TRUE,exitoption);

    setteglfont((fontptr)roman25);
    createbarmenu(0,0,getmaxx());
    outbaroption(" ~F~ile  ",om1);
}


void main(void)
{
    easytegl();
    easyout();

    setkeyboardmouse(FALSE);
    init_criterr();
    createmenubarevents();

    teglsupervisor();

}
