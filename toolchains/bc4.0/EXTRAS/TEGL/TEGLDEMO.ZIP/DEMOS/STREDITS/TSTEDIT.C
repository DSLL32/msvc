/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
/* a basic example for using the line editor */

#include "teglsys.h"
#include "string.h"

/*
#include <teglcond.h>
#include <dos.h>
#include <string.h>
#include <stdlib.h>
#include <tgraph.h>
#include <iconsys.h>
#include <fastgrph.h>
#include <teglintr.h>
#include <fontsys.h>
#include <virtmem.h>
#include <ipstacks.h>
#include <teglunit.h>
#include <teglmain.h>
#include <errorlog.h>
#include <tegledit.h>
*/

char mystr1[255];
char mystr2[255];

imagestkptr mystrfs;
msclickptr mystr1ms;
msclickptr mystr2ms;

unsigned exitoption(imagestkptr fs, msclickptr ms)
   {
      logmessage(mystr1);
      abortexit(mystr2);
      return 1;
   }

unsigned mydoneevent(imagestkptr fs, msclickptr ms)
   {
      if (visualbuttonpress(fs,ms))
	 dropstackimage(fs);

      return 1;
   }

unsigned char strpackformat(char * txtstr)
   {   unsigned char pack;
       char tmpstr[255];
       char *wh;

       pack = 0;
       while ((wh=strchr(txtstr,' '))!=NULL) {
	  strcpy(tmpstr,wh+1);
	  strcpy(wh,tmpstr);
	  pack = 1;
       }
      return pack;
   }

void createeditbox(void)
{   unsigned x, y, x1, y1;
    imagestkptr  fs;

    x = 100;
    y = 100;
    x1 = x+300;
    y1 = y+100;

    strcpy(mystr1,"This is an initialized String from mystr1");
    strcpy(mystr2,"This is an initialized String from mystr2");

    pushimage(x,y,x1,y1);
    fs = stackptr;
    mystrfs = stackptr;

    setfillpattern((char _TGFAR_ *)gridfill,DARKGRAY);
    setfillstyle(SOLID_FILL,DARKGRAY);
    bevelbox(x,y,x1,y1,WHITE,LIGHTGRAY,RED,5);

    setkeyboardmouse(FALSE);
    definestreditevent(fs,10,10,290,30,254,WHITE,(fontptr)font14,TRUE,mystr1,
			 allchars,strpackformat,strpackformat,NULL);
    mystr1ms = fs->msptr;
    definestreditevent(fs,10,35,290,55,254,WHITE,(fontptr)cour25,TRUE,mystr2,
			 numbersonly,strnoformat,strredisplay,NULL);
    mystr2ms = fs->msptr;

    prepareforupdate(fs);
    putpict(x1-60,y1-25,(iconptr)imageOK,BLACK);
    definemouseclickarea(fs,(x1-x)-60,(y1-y)-25,(x1-x)-60+37,(y1-y)-25+14,TRUE,mydoneevent,MSCLICK);
    commitupdate();

    addcapturekey(0x001C,FALSE,crclickpress);
    addcapturekey(0x009C,TRUE,crclickrelease);
}

void main()
{
   easytegl();
   easyout();

   setautorotate(TRUE);

   defineglobalkeyclickarea(NULL,NULL,0x082d,FALSE,exitoption);

   createeditbox();
   setstredit(mystrfs,mystr2ms,1);

   teglsupervisor();
}
