/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
/* a basic example for using the line editor */

#include "teglsys.h"
#include "string.h"

char mystr[10][255];

void createeditbox(void)
{   unsigned x, y, x1, y1, tm, i;
    imagestkptr  fs;

    setteglfont((fontptr)font14);

    x = 100;
    y = 100;
    x1 = x+300;
    y1 = y+(10*teglcharheight())+20;

    for (i=0; i<10; i++)
       mystr[i][0] = '\0';

    pushimage(x,y,x1,y1);
    fs = stackptr;

    setfillpattern(gridfill,(int)DARKGRAY);
    bevelbox(x,y,x1,y1,WHITE,LIGHTGRAY,RED,5);

    setkeyboardmouse(FALSE);

    for (i=0; i<10; i++) {
       tm = 10+i*teglcharheight();
       definestreditevent(fs,10,tm,290,tm+teglcharheight(),254,WHITE,(fontptr)font14,
			   TRUE,mystr[i],allchars,strnoformat,strnoformat,NULL);
    }
}

void main()
{
   easytegl();
   easyout();

   setautorotate(TRUE);
   createeditbox();

   teglsupervisor();
}
