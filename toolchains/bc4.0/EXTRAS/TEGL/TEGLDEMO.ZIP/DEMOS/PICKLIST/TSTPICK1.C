/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
/* shows the use of drop down pick list. */

#include "teglsys.h"

char pickeditem[255];

unsigned exitoption(imagestkptr fs,msclickptr ms)
{
    abortexit(pickeditem);
    return 1;
}

unsigned droppicklist(imagestkptr fs,unsigned userkey,void *dataarea)
{
    optionmptr picklist = (optionmptr) dataarea;

    dropoptionmenu(picklist);
    return 0;
}

unsigned gotitem(imagestkptr fs,msclickptr ms)
{
    beep(500,4,50);
    return 1;
}


void createtestpicklist(void)
{
    unsigned x,y,x1,y1;
    unsigned ax,ay,ax1,ay1;
    optionmptr picklist;
    imagestkptr ifs;
    unsigned margins;
    unsigned maxwidth;

    x = 100;
    y = 100;
    x1 = x+200;
    y1 = y+200;
    margins = 2;
    maxwidth = 150;

    pushimage(x,y,x1,y1);
    shadowbox(x,y,x1,y1);

    /*---------------------------------------------------------------------*/
    /* Create an edit event to allow the user to edit the selected item    */
    /*---------------------------------------------------------------------*/
    ax = 10+2+margins;	    /* <-- pick list adds 2 pixel before the text */
    ay = 10+2;
    ax1 = ax+maxwidth;
    ay1 = ay+14;	      /* <-- Font height */

    setkeyboardmouse(FALSE);
    ifs = stackptr;
    definestreditevent(ifs,ax,ay,ax1,ay1,40,BLUE,(fontptr)font14,TRUE,
			pickeditem,allchars,strredisplay,strredisplay,NULL);
    addmouseclickmask(getlastmsptr(ifs),(maskptr)maskcursor,2,6);


    /*---------------------------------------------------------------------*/
    /* Create drop down pick list event 				   */
    /*---------------------------------------------------------------------*/
    picklist = createpicklist((fontptr)font14);
    setpicklistmargin(picklist,margins);
    setpicklistwidth(picklist,maxwidth);
    definepickitem(picklist,"item one on list",gotitem,pickeditem);
    definepickitem(picklist,"item two on list",gotitem,pickeditem);
    definepickitem(picklist,"item three on list",gotitem,pickeditem);
    definepickitem(picklist,"item four on list",gotitem,pickeditem);
    definepickitem(picklist,"item five on list",gotitem,pickeditem);
    definepickitem(picklist,"item three on list",gotitem,pickeditem);
    definepickitem(picklist,"item six on list",gotitem,pickeditem);
    definepickitem(picklist,"item seven on list",gotitem,pickeditem);

    definepicklistarea(ifs,10,10,3,1,picklist);

    /*---------------------------------------------------------------------*/
    /* define a user data area for the picklist with an arbitrary	   */
    /* key of 222.							   */
    /*---------------------------------------------------------------------*/
    setuserdataarea(ifs,222,picklist,droppicklist);
}

void main()
{
    easytegl();
    easyout();

    setautorotate(TRUE);
    createtestpicklist();

    teglsupervisor();
}
