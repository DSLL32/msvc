/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
#include "teglsys.h"
#include <tablinks.h>
#include <stdlib.h>

char pickeditem[40];


unsigned droppicklist(imagestkptr fs,unsigned userkey,void *dataarea)
{
    optionmptr picklist = (optionmptr)dataarea;

    dropoptionmenu(picklist);
    return 0;
}


unsigned dropitems(imagestkptr fs,msclickptr ms)
{
    optionmptr picklist;

    getuserdataarea(fs,222,&picklist);
    detachpicklist(picklist);
    deletepickitem(picklist,random(picklist->numofentries)+1);
    deletepickitem(picklist,random(picklist->numofentries)+1);
    deletepickitem(picklist,random(picklist->numofentries)+1);
    deletepickitem(picklist,random(picklist->numofentries)+1);
    attachpicklist(picklist,picklist->selectedoenum);

    getuserdataarea(fs,223,&picklist);
    detachpicklist(picklist);
    deletepickitem(picklist,random(picklist->numofentries)+1);
    deletepickitem(picklist,random(picklist->numofentries)+1);
    attachpicklist(picklist,picklist->selectedoenum);

    beep(500,4,50);
    return 1;
}


unsigned additems(imagestkptr fs,msclickptr ms)
{
    optionmptr picklist;

    getuserdataarea(fs,222,&picklist);
    detachpicklist(picklist);
    insertpickitem(picklist,random(picklist->numofentries)+1,"Add some items",additems,pickeditem);
    insertpickitem(picklist,random(picklist->numofentries)+1,"Drop some items",dropitems,pickeditem);
    insertpickitem(picklist,random(picklist->numofentries)+1,"Add some items",additems,pickeditem);
    insertpickitem(picklist,random(picklist->numofentries)+1,"Drop some items",dropitems,pickeditem);
    insertpickitem(picklist,random(picklist->numofentries)+1,"Add some items",additems,pickeditem);
    insertpickitem(picklist,random(picklist->numofentries)+1,"Drop some items",dropitems,pickeditem);
    insertpickitem(picklist,random(picklist->numofentries)+1,"Add some items",additems,pickeditem);
    attachpicklist(picklist,picklist->selectedoenum);

    getuserdataarea(fs,223,&picklist);
    detachpicklist(picklist);
    insertpickitem(picklist,random(picklist->numofentries)+1,"Add some items",additems,pickeditem);
    insertpickitem(picklist,random(picklist->numofentries)+1,"Drop some items",dropitems,pickeditem);
    insertpickitem(picklist,random(picklist->numofentries)+1,"Add some items",additems,pickeditem);
    insertpickitem(picklist,random(picklist->numofentries)+1,"Drop some items",dropitems,pickeditem);
    insertpickitem(picklist,random(picklist->numofentries)+1,"Add some items",additems,pickeditem);
    insertpickitem(picklist,random(picklist->numofentries)+1,"Drop some items",dropitems,pickeditem);
    attachpicklist(picklist,picklist->selectedoenum);

    beep(500,4,50);
    return 1;
}


void clickcheckboxon(imagestkptr ifs, msclickptr ms)
{
    unsigned x,y,x1,y1,cx,cy,xr,yr;

    x = ifs->x+ms->ms.x;
    y = ifs->y+ms->ms.y;
    x1 = ifs->x+ms->ms.x1;
    y1 = ifs->y+ms->ms.y1;

    xr = (x1 - x+1) / 2;
    yr = (y1 - y+1) / 2;
    cx = x+xr;
    cy = y+yr;

    setcolor(BLACK);
    setfillstyle(SOLID_FILL,GREEN);
    prepareforpartialupdate(ifs,x,y,x1,y1);
    fillellipse(cx,cy,xr,yr);
    commitupdate();
}


void clickcheckboxoff(imagestkptr ifs, msclickptr ms)
{
    unsigned x,y,x1,y1,cx,cy,xr,yr;

    x = ifs->x+ms->ms.x;
    y = ifs->y+ms->ms.y;
    x1 = ifs->x+ms->ms.x1;
    y1 = ifs->y+ms->ms.y1;

    xr = (x1 - x+1) / 2;
    yr = (y1 - y+1) / 2;
    cx = x+xr;
    cy = y+yr;

    setcolor(BLACK);
    setfillstyle(SOLID_FILL,RED);
    prepareforpartialupdate(ifs,x,y,x1,y1);
    fillellipse(cx,cy,xr,yr);
    commitupdate();
}


unsigned char pick1flag = TRUE;
unsigned char pick2flag = TRUE;


unsigned clickpicklist1(imagestkptr ifs, msclickptr ms)
{
    settablink(ifs,3);
    if (pick1flag)
	clickcheckboxoff(ifs,ms);
    else
	clickcheckboxon(ifs,ms);

    pick1flag = !pick1flag;
    toggletablink(ifs,1,pick1flag);
    while (!userrelease());
    return 0;
}


unsigned clickpicklist2(imagestkptr ifs, msclickptr ms)
{
    settablink(ifs,4);
    if (pick2flag)
	clickcheckboxoff(ifs,ms);
    else
	clickcheckboxon(ifs,ms);

    pick2flag = !pick2flag;
    toggletablink(ifs,2,pick2flag);
    while (!userrelease());
    return 0;
}


unsigned pick1on(imagestkptr fs, msclickptr ms)
{
    optionmptr picklist;

    getuserdataarea(fs,222,&picklist);
    togglepicklistactive(picklist,TRUE);
    return 0;
}


unsigned pick1off(imagestkptr fs, msclickptr ms)
{
    optionmptr picklist;

    getuserdataarea(fs,222,&picklist);
    togglepicklistactive(picklist,FALSE);
    return 0;
}


unsigned pick2on(imagestkptr fs, msclickptr ms)
{
    optionmptr picklist;

    getuserdataarea(fs,223,&picklist);
    togglepicklistactive(picklist,TRUE);
    return 0;
}


unsigned pick2off(imagestkptr fs, msclickptr ms)
{
    optionmptr picklist;

    getuserdataarea(fs,223,&picklist);
    togglepicklistactive(picklist,FALSE);
    return 0;
}


unsigned actpick1(imagestkptr fs, msclickptr ms)
{
    optionmptr picklist;

    getuserdataarea(fs,222,&picklist);
    activatepicklist(picklist);
    return 0;
}


unsigned deactpick1(imagestkptr fs, msclickptr ms)
{
    optionmptr picklist;

    getuserdataarea(fs,222,&picklist);
    deactivatepicklist(picklist);
    return 0;
}


unsigned actpick2(imagestkptr fs, msclickptr ms)
{
    optionmptr picklist;

    getuserdataarea(fs,223,&picklist);
    activatepicklist(picklist);
    return 0;
}


unsigned deactpick2(imagestkptr fs, msclickptr ms)
{
    optionmptr picklist;

    getuserdataarea(fs,223,&picklist);
    deactivatepicklist(picklist);
    return 0;
}


unsigned pick1(imagestkptr fs, msclickptr ms)
{
    if (pick1flag)
	settablink(fs,1);
    return 1;
}


unsigned pick2(imagestkptr fs, msclickptr ms)
{
    if (pick2flag)
	settablink(fs,2);
    return 2;
}


unsigned processpicklist(imagestkptr fs, msclickptr ms)
{
    optionmptr picklist;
    unsigned ct;

    ct = (int) getactivetabnum(fs);
    picklist = NULL;
    switch (ct) {

    case 1:
	getuserdataarea(fs,222,&picklist);
	break;

    case 2:
	getuserdataarea(fs,223,&picklist);
	break;
    }
    if (picklist != NULL)
	processselecteditem(picklist);
    return 1;
}



void testpicklist(void)
{
    unsigned x,y,x1,y1;
    optionmptr picklist1;
    optionmptr picklist2;

    x = 100;
    y = 100;
    x1 = x+200;
    y1 = y+200;

    pushimage(x,y,x1,y1);
    shadowbox(x,y,x1,y1);

    picklist1 = createpicklist(font14);
    definepickitem(picklist1,"Add items Event",additems,pickeditem);
    definepickitem(picklist1,"Add items Event",additems,pickeditem);

    setuserdataarea(stackptr,222,picklist1,droppicklist);
    definepicklistarea(stackptr,10,10,3,5,picklist1);
    defineactivationproc(picklist1,pick1);

    picklist2 = createpicklist(roman25);
    definepickitem(picklist2,"Add items event",additems,pickeditem);
    definepickitem(picklist2,"Add items event",additems,pickeditem);

    setuserdataarea(stackptr,223,picklist2,droppicklist);
    definepicklistarea(stackptr,10,picklist1->y1+10,3,1,picklist2);
    defineactivationproc(picklist2,pick2);

    addtablinks(stackptr,NULL,actpick1,deactpick1,processpicklist,pick1on,pick1off,TRUE);
    addtablinks(stackptr,NULL,actpick2,deactpick2,processpicklist,pick2on,pick2off,TRUE);

    definemouseclickarea(stackptr,180,10,192,21,TRUE,clickpicklist1,MSCLICK);
    clickcheckboxon(stackptr,stackptr->msptr);
    addtablinkssquarebuttons(stackptr,stackptr->msptr,clickpicklist1);

    definemouseclickarea(stackptr,180,picklist1->y1+10,192,picklist1->y1+10+11,TRUE,clickpicklist2,MSCLICK);
    clickcheckboxon(stackptr,stackptr->msptr);
    addtablinkssquarebuttons(stackptr,stackptr->msptr,clickpicklist2);

    activatetablinks(stackptr,1);
}


void main(int argc,char **argv)
{
    easytegl();
    easyout();

    testpicklist();
    teglsupervisor();
}
