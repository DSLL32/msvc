/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
/* shows a simple pick list that can have items added to it */

#include "teglsys.h"
#include "stdlib.h"

char pickeditem[255];

unsigned exitoption(imagestkptr fs, msclickptr ms)
{
    abortexit(pickeditem);
    return 1;
}

unsigned droppicklist(imagestkptr fs, unsigned userkey, void * dataarea)
{
    optionmptr picklist = (optionmptr) dataarea;

    dropoptionmenu(picklist);
    return 0;
}


unsigned randomnum(unsigned n)
{
   if (n) n=rand()%n;

   return n;
}

unsigned dropitems(imagestkptr fs, msclickptr ms)
{
    optionmptr	 picklist;

    getuserdataarea(fs,222,&picklist);
    detachpicklist(picklist);
    deletepickitem(picklist,randomnum(picklist->numofentries)+1);
    deletepickitem(picklist,randomnum(picklist->numofentries)+1);
    deletepickitem(picklist,randomnum(picklist->numofentries)+1);
    deletepickitem(picklist,randomnum(picklist->numofentries)+1);
    attachpicklist(picklist,randomnum(picklist->numofentries)+1);

    beep(500,4,50);
    return 1;
}


unsigned additems(imagestkptr fs, msclickptr ms)
{
    optionmptr picklist;

    getuserdataarea(fs,222,&picklist);
    detachpicklist(picklist);
    insertpickitem(picklist,randomnum(picklist->numofentries)+1,"item one on list",additems,pickeditem);
    insertpickitem(picklist,randomnum(picklist->numofentries)+1,"item two on list",dropitems,pickeditem);
    insertpickitem(picklist,randomnum(picklist->numofentries)+1,"item three on list",additems,pickeditem);
    insertpickitem(picklist,randomnum(picklist->numofentries)+1,"item four on list",dropitems,pickeditem);
    insertpickitem(picklist,randomnum(picklist->numofentries)+1,"item five on list",additems,pickeditem);
    insertpickitem(picklist,randomnum(picklist->numofentries)+1,"item six on list",dropitems,pickeditem);
    insertpickitem(picklist,randomnum(picklist->numofentries)+1,"item seven on list",additems,pickeditem);
    attachpicklist(picklist,randomnum(picklist->numofentries)+1);

    beep(500,4,50);
    return 1;
}


void testpicklist(void)
{
    unsigned x, y, x1, y1;
    optionmptr	 picklist;

    x = 100;
    y = 100;
    x1 = x + 200;
    y1 = y + 200;

    pushimage(x,y,x1,y1);
    shadowbox(x,y,x1,y1);

    picklist = createpicklist((fontptr)font14);
    definepickitem(picklist,"item one on list",additems,pickeditem);
    definepickitem(picklist,"item two on list",dropitems,pickeditem);

    setuserdataarea(stackptr,222,picklist,droppicklist);
    definepicklistarea(stackptr,10,10,3,5,picklist);
}


void main()
{
   easytegl();
   easyout();

   testpicklist();

   teglsupervisor();
}
