/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990,TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
#include "teglcond.h"
#include "tgraph.h"
#include "fastgrph.h"
#include "iconsys.h"
#include "fontsys.h"
#include "teglspec.h"
#include "teglunit.h"
#include "teglmain.h"

char gridf[8] = {0xFF,0x88,0x88,0x88,0xFF,0x88,0x88,0x88};

void griderase(int x1,int y1,int x2,int y2)
{
    fillpatternbar(x1,y1,x2,y2,LIGHTGRAY,BLUE,gridf);
}

unsigned beepme(imagestkptr ifs,msclickptr ms)
{
    beep(1000,1,50);
    return 0;
}

unsigned dropallmsg(imagestkptr ifs,msclickptr ms)
{
    broadcast(MSG_CLOSEFRAME);
    return 0;
}

unsigned iconframeactive(imagestkptr ifs,msclickptr ms)
{
    unsigned msg;

    msg = getmessage();

    /* for icon frames,we let redrawiconframe to redraw the active icon */
    /*
     * DO NOT call redrawiconframe() when rotatingtop,otherwise the icon
     * frame will be redrawn twice
     */
    switch (msg) {

    case MSG_CLOSEFRAME:
	dropstackimage(ifs);
	break;

    case MSG_ROTATINGTOP:
	ifs->iconcolor = YELLOW;
	break;

    case MSG_ROTATINGDOWN:{
	    ifs->iconcolor = BLACK;
	    redrawiconframe(ifs,ms);
	}
	break;
    }
    return 0;
}

unsigned boxactive(imagestkptr ifs,msclickptr ms)
{
    unsigned msg;
    unsigned interiorc,activec,activeb;

    msg = getmessage();

    /* for redraw frames,we let frameredraw to redraw the active window */
    /*
     * DO NOT call refreshframeredraw() to handle the redraw,otherwise the
     * frame will be redrawn twice
     */

    switch (msg) {

    case MSG_CLOSEFRAME:
	dropstackimage(ifs);
	break;

    case MSG_ROTATINGDOWN:{
	    interiorc = RED;
	    activec = WHITE;
	    activeb = LIGHTGRAY;

	    prepareforupdate(ifs);
	    bevelbox(ifs->x,ifs->y,ifs->x1,ifs->y1,activec,activeb,interiorc,5);
	    commitupdate();
	}
	break;
    }
    return 0;
}


unsigned frameredraw(imagestkptr ifs,msclickptr ms)
{
    unsigned interiorc,activec,activeb;

    interiorc = RED;
    activec = WHITE;
    activeb = LIGHTGRAY;
    if (ifs == stackptr) {
	activec = YELLOW;
	activeb = YELLOW;
    }
    prepareforupdate(ifs);
    bevelbox(ifs->x,ifs->y,ifs->x1,ifs->y1,activec,activeb,interiorc,5);
    setteglfont(font14);
    setcolor(BLACK);
    if (ifs == stackptr)
	outtextxy(ifs->x + 15,ifs->y + 30,"ACTIVE");
    commitupdate();
    return 0;
}

/*
 * The icon redraw function is only used to display the icon active message.
 * If you don't use setframeredraw(),redrawiconframe is automatically
 * attached.
 */

unsigned iconredraw(imagestkptr ifs,msclickptr ms)
{
    redrawiconframe(ifs,ms);
    prepareforupdate(ifs);
    setteglfont(font07);
    setcolor(YELLOW);
    if (ifs == stackptr)
	outtextxy(ifs->x + 6,ifs->y + 10,"ACTIVE");
    commitupdate();
    return 0;
}

void main(int argc,char **argv)
{
    easytegl();

    setautorotate(TRUE);
    griderase(0,0,getmaxx(),getmaxy());
    eraseframe = griderase;
    easyout();
    setframeautorotate(stackptr,FALSE);
    setalttabrotate(TRUE);

    pushimage(getmaxx()-275,getmaxy()-25,getmaxx()-150,getmaxy());
    definesquarebuttontext(stackptr,0,0,124,24,5,2,"Drop All",dropallmsg);
    setframeautorotate(stackptr,FALSE);

    pushimage(50,50,150,150);
    setmessagecallproc(stackptr,boxactive);
    setframeredraw(stackptr,frameredraw);

    defineiconframe(400,20,imageMONITOR,BLACK,TRUE,beepme,MSCLICK);
    setmessagecallproc(stackptr,iconframeactive);
    setframeredraw(stackptr,iconredraw);

    pushemptyimage(100,100,200,200);
    setmessagecallproc(stackptr,boxactive);
    setframeredraw(stackptr,frameredraw);

    pushemptyimage(150,150,250,250);
    setmessagecallproc(stackptr,boxactive);
    setframeredraw(stackptr,frameredraw);

    /*
     * each time an emptyimage is created,the messagecallproc will cause the
     * last empty frame to be redrawn.
     */
    refreshredrawframe(stackptr,stackptr);
    teglsupervisor();
}
