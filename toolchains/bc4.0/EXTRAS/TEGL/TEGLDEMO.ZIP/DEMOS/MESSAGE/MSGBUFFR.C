/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990,TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
#include "teglcond.h"
#include "tgraph.h"
#include "fastgrph.h"
#include "iconsys.h"
#include "fontsys.h"
#include "teglspec.h"
#include "teglunit.h"
#include "teglmain.h"


unsigned beepme(imagestkptr ifs,msclickptr ms)
{
    beep(1000,1,50);
    return 0;
}

unsigned dropallmsg(imagestkptr ifs,msclickptr ms)
{
    broadcast(MSG_CLOSEFRAME);
    return 0;
}

void framedraw(imagestkptr ifs,unsigned char active)
{
    unsigned interiorc,activec,activeb;

    interiorc = RED;
    activec = WHITE;
    activeb = LIGHTGRAY;
    if (active) {
	activec = YELLOW;
	activeb = YELLOW;
    }
    prepareforupdate(ifs);
    bevelbox(ifs->x,ifs->y,ifs->x1,ifs->y1,activec,activeb,interiorc,5);
    setteglfont(font14);
    setcolor(BLACK);
    if (active)
	outtextxy(ifs->x + 15,ifs->y + 30,"ACTIVE");
    commitupdate();
}


unsigned boxactive(imagestkptr ifs,msclickptr ms)
{
    unsigned msg;

    /*
     * see demo program msgempty to see differences when handling rotation
     * messages. With buffered images,the frame is redrawn here to indicate
     * activity. Whereas,empty frames are redrawn on rotate,thereby
     * redrawing is only necessary when a frame is rotated downwards.
     */

    msg = getmessage();
    switch (msg) {

    case MSG_CLOSEFRAME:
	dropstackimage(ifs);
	break;

    case MSG_ROTATINGDOWN:
	framedraw(ifs,FALSE);
	break;

    case MSG_ROTATINGTOP:
	framedraw(ifs,TRUE);
	break;
    }
    return 0;
}

unsigned iconframeactive(imagestkptr ifs,msclickptr ms)
{
    unsigned msg;

    msg = getmessage();

    /* for icon frames,we let REDrawiconframe to REDraw the active icon */
    /*
     * DO NOT call REDrawiconframe() when rotatingtop,otherwise the icon
     * frame will be REDrawn twice
     */
    switch (msg) {

    case MSG_CLOSEFRAME:
	dropstackimage(ifs);
	break;

    case MSG_ROTATINGTOP:
	ifs->iconcolor = YELLOW;
	break;

    case MSG_ROTATINGDOWN:{
	    ifs->iconcolor = LIGHTGRAY;
	    redrawiconframe(ifs,ms);
	}
	break;
    }
    return 0;
}

/*
 * The icon redraw function is only used to display the icon active message.
 * If you don't use setframeREDraw(),REDrawiconframe is automatically
 * attached.
 */

unsigned iconredraw(imagestkptr ifs,msclickptr ms)
{
    redrawiconframe(ifs,ms);
    prepareforupdate(ifs);
    setteglfont(font07);
    setcolor(YELLOW);
    if (ifs == stackptr)
	outtextxy(ifs->x + 6,ifs->y + 10,"ACTIVE");
    commitupdate();
    return 0;
}


void main(int argc,char **argv)
{
    setteglfillstyle(EMPTY_FILL);
    easytegl();

    setautorotate(TRUE);
    easyout();
    setframeautorotate(stackptr,FALSE);
    setalttabrotate(TRUE);

    pushimage(getmaxx() - 275,getmaxy() - 25,getmaxx() - 150,getmaxy());
    definesquarebuttontext(stackptr,0,0,124,24,5,2,"Drop All",dropallmsg);
    setframeautorotate(stackptr,FALSE);

    pushimage(50,50,150,150);
    setmessagecallproc(stackptr,boxactive);
    framedraw(stackptr,TRUE);

    defineiconframe(400,20,imageMONITOR,LIGHTGRAY,TRUE,beepme,MSCLICK);
    setmessagecallproc(stackptr,iconframeactive);
    setframeredraw(stackptr,iconredraw);

    pushimage(100,100,200,200);
    setmessagecallproc(stackptr,boxactive);
    framedraw(stackptr,TRUE);

    pushimage(150,150,250,250);
    setmessagecallproc(stackptr,boxactive);
    framedraw(stackptr,TRUE);

    teglsupervisor();
}
