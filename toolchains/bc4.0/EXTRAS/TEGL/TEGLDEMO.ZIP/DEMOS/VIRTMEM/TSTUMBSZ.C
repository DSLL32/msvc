/*---------------------------------------------------------------------------*
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/

#include <teglcond.h>
#include <stdio.h>
#include "vmxms.h"

unsigned long umbsize;
int rc;

void main(void)
{
    if (xmminstalled())
       {
	  rc = uppermemorybytesavailable(&umbsize);
	  printf("RC[%d] size available: %ld\n",rc,umbsize);
       }
    else
       printf("XMS Driver not found\n");

}
