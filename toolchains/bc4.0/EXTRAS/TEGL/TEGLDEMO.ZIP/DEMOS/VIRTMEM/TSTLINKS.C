/*---------------------------------------------------------------------------*
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/

#include <teglcond.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "vmerror.h"
#include "vmvirt.h"
#include "errorlog.h"


typedef struct personrec {
    unsigned _TGLONG_ nxtrec;
    unsigned _TGLONG_ custnum;
    char name[81];
    char company[81];
    unsigned age;
    char address[81];
    char city[81];
    char prov[81];
    char postal[21];
    char telephone[21];
    char filler[5];		/* make record even */
} personrec;


personrec customer;
unsigned _TGLONG_ customerdb;
unsigned i;
unsigned _TGLONG_ rsz;
unsigned _TGLONG_ custanchor;


unsigned virterror(unsigned _TGLONG_ code)
{
    printf("Error - %s\n", xlaterrormsg((int)code));
    exit(0);
    return 0;
}


void main(int argc, char **argv)
{
    printf("TSTLINKS - A program for creating a virtual link list\n");
    printf("\n");

    setvirtualerrorproc(virterror);
    setxmsmaxsize(200000L);
    setemsmaxsize(200000L);

    customer.custnum = 0L;
    strcpy(customer.name, "Richard Tom");
    strcpy(customer.company, "TEGL Systems Corporation");
    customer.age = 0;
    strcpy(customer.address, "P.O. Box 580, Stn. A");
    strcpy(customer.city, "Vancouver");
    strcpy(customer.prov, "British Columbia");
    strcpy(customer.postal, "V6C 2N2");
    strcpy(customer.telephone, "(604) 669-2577");

    rsz = (unsigned _TGLONG_) sizeof(personrec);
    custanchor = 0L;


    for (i = 0; i <= 1999; i++) {
	customer.custnum = (unsigned _TGLONG_) i;
	customer.age = i;

	customerdb = (unsigned _TGLONG_) virtualgetmem(rsz);
	customer.nxtrec = custanchor;
	custanchor = customerdb;

	virtualwrite((char _TGFAR_ *)&customer, customerdb,(unsigned _TGLONG_)0L, rsz);
	printf("Writing Customer %d at %ld\n", i, customerdb);
    }

    customerdb = custanchor;
    while (customerdb != 0L) {
	virtualread((char _TGFAR_ *)&customer, customerdb,(unsigned _TGLONG_)0L, rsz);
	printf("Custnum %ld from %ld\n", customer.custnum, customerdb);
	customerdb = customer.nxtrec;
    }

}
