/*---------------------------------------------------------------------------*
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/

#include <teglcond.h>
#include "chkmem.h"
#include "vmerror.h"
#include "vmdrive.h"
#include "vmvheap.h"
#include "vheapshw.h"
#include "errorlog.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "dosfuncs.h"

#define TSTENTRIES 30

unsigned tstvdskerror(unsigned _TGLONG_ code)
{
    printf("Error - %s\n", xlaterrormsg((int)code));
    exit(0);
    return 0;
}

void main(int argc, char **argv)
{
    _TGLONG_ blocks[TSTENTRIES];
    _TGLONG_ bsizes[TSTENTRIES];
    unsigned _TGLONG_ w;
    unsigned i, j;
    void *p;
    vdrvfile workdisk;
    vheapfile heapdisk;
    unsigned ftype;
    char pstr[80];

    if (argc < 2) {
	printf("TSTHEAP2 [parm] - A program for testing the virtual heap\n");
	printf("                  Random allocation/deallocation in varying sizes\n");
	printf("   EMS - test EMS Disk drive \n");
	printf("   XMS - test XMS Disk drive \n");
	printf("   DSK - test Disk drive \n");
	exit(0);
    } else {
	strcpy(pstr,argv[1]);
	strupr(pstr);
	if (strcmp(pstr,"EMS") == 0)
	    ftype = EMSTYPE;
	else if (strcmp(pstr,"XMS") == 0)
	    ftype = XMSTYPE;
	else if (strcmp(pstr,"DSK") == 0)
	    ftype = DSKTYPE;
	else
	    ftype = EMSTYPE;
    }

    randomize();
    setvheaperrorproc(tstvdskerror);

    p = farmalloc(0x20000L);
    fillmem(p,(unsigned _TGLONG_)0x20000L,(char)0xFE);

    workdisk = vdrvopen(ftype,(unsigned _TGLONG_)500000L,(unsigned _TGLONG_)0x0fffffffL);
    if (vmmstatus)
       tstvdskerror(vmmstatus);

    heapdisk = vheapinitialize(workdisk);

    for (i = 0; i < TSTENTRIES; i++) {
	fillmem(p,(unsigned _TGLONG_)0x20000L,(char)(0xFE - i));
	bsizes[i] = (((unsigned _TGLONG_) (random(1024)) * 124L) + 0xfffL) & 0xfffffffEL;
	blocks[i] = vheapgetmem(heapdisk,(unsigned _TGLONG_)bsizes[i]);

	printf("Allocating & Writing Block %d, size[%ld]\n", i,bsizes[i]);
	vheapwritedata(heapdisk, p,(unsigned _TGLONG_)blocks[i]);
    }
    vheapshowfreelist(heapdisk);

    for (i = 0; i < TSTENTRIES; i++) {
	j = random(TSTENTRIES);
	printf("Randomly Releasing Block %d\n", j);
	if (blocks[j] != -1L)
	    vheapfreemem(heapdisk,(unsigned _TGLONG_)blocks[j]);
	blocks[j] = -1L;
    }
    vheapshowfreelist(heapdisk);

    for (i = 0; i < 40; i++) {
	j = random(TSTENTRIES);
	if (blocks[j] != -1L)
	    vheapfreemem(heapdisk,(unsigned _TGLONG_)blocks[j]);

	fillmem(p,(unsigned _TGLONG_)0x20000L,(char)(0xFE - j));
	bsizes[j] = (((unsigned _TGLONG_) (random(1024)) * 124L) + 0xfffL) & 0xfffffffEL;
	blocks[j] = vheapgetmem(heapdisk,(unsigned _TGLONG_)bsizes[j]);

	printf("Freeing and Re-allocating Block%d, newsize[%ld]\n", j,bsizes[j]);
	vheapwritedata(heapdisk, p,(unsigned _TGLONG_)blocks[j]);
    }
    vheapshowfreelist(heapdisk);

    for (i = 0; i < TSTENTRIES; i++) {
	printf("Reading & comparing Block%10ld%10ld\n", blocks[i], bsizes[i]);
	if (blocks[i] != -1L) {
	    vheapreaddata(heapdisk, p,(unsigned _TGLONG_)blocks[i]);
	    w = checkmem(p,(unsigned _TGLONG_)bsizes[i],(char)(0xFE - i));
	    if (w) {
		printf("Error in comparison %ld\n", w);
		exit(0);
	    }
	}
    }

    for (i = 0; i < TSTENTRIES; i++) {
	printf("Freeing Block%d\n", i);
	if (blocks[i] != -1L)
	    vheapfreemem(heapdisk,(unsigned _TGLONG_)blocks[i]);
    }

    vheapshowfreelist(heapdisk);
    vheapclosefile(heapdisk);
}
