/*---------------------------------------------------------------------------*
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/

#include <teglcond.h>
#include <stdio.h>
#include "chkmem.h"
#include "vmxms.h"
#include "errorlog.h"
#include "dosfuncs.h"

    char	  xmmversion[16];
    unsigned	  rc;
    unsigned long totalbytes;
    unsigned long bytesavail;
    unsigned	  tsthandle;
    extmemmovestruct extmemmove;
    char *	  tmpptr;
    char *	  umbptr;
    unsigned	  umbseg;
    unsigned long umbrealsize;
    unsigned long umbsize;


void main(void)
{
    if (xmminstalled())
       {
	  rc = getxmsversionnumber((char *)&xmmversion);
	  if (rc) abortpgm(rc);
	  printf("XMS Driver Version : %s\n",&xmmversion[1]);

	  rc = xmsbytesavailable(&totalbytes,&bytesavail);
	  if (rc) abortpgm(rc);
	  printf("Bytes Total        : %ld\n",totalbytes);
	  printf("Bytes Available    : %ld\n",bytesavail);

	  rc = allocateextendedmemorybytes(bytesavail,&tsthandle);
	  if (rc) abortpgm(rc);
	  printf("Allocated handle   : %d\n",tsthandle);
	  printf("Allocated bytes    : %ld\n",bytesavail);

	  tmpptr = (char *)malloc(0x4000);

	  fillmem(tmpptr,0x4000,0);
	  extmemmove.length	  = 0x4000;
	  extmemmove.sourcehandle = 0;
	  extmemmove.sourceoffset = (unsigned long)tmpptr;
	  extmemmove.desthandle   = tsthandle;
	  extmemmove.destoffset   = 0;

	  rc = moveextmemblockxms(&extmemmove);
	  if (rc) abortpgm(rc);

	  fillmem(tmpptr,0x4000,1);
	  extmemmove.length	  = 0x4000;
	  extmemmove.sourcehandle = 0;
	  extmemmove.sourceoffset = (unsigned long)tmpptr;
	  extmemmove.desthandle   = tsthandle;
	  extmemmove.destoffset   = 0x4000;

	  rc = moveextmemblockxms(&extmemmove);
	  if (rc) abortpgm(rc);

	  extmemmove.length	  = 0x4000;
	  extmemmove.sourcehandle = tsthandle;
	  extmemmove.sourceoffset = 0;
	  extmemmove.desthandle   = 0;
	  extmemmove.destoffset   = (unsigned long)tmpptr;

	  rc = moveextmemblockxms(&extmemmove);
	  if (rc) abortpgm(rc);

	  if (checkmem(tmpptr,0x4000,0))
	     abortexit("Bad bytes in XMS memory block 0");

	  extmemmove.length	  = 0x4000;
	  extmemmove.sourcehandle = tsthandle;
	  extmemmove.sourceoffset = 0x4000;
	  extmemmove.desthandle   = 0;
	  extmemmove.destoffset   = (unsigned long)tmpptr;

	  rc = moveextmemblockxms(&extmemmove);
	  if (rc) abortpgm(rc);

	  if (checkmem(tmpptr,0x4000,1))
	     abortexit("Bad bytes in XMS memory block 1");

	  printf("XMS Memory test    : OK\n");
	  rc = deallocateextendedmemorybytes(tsthandle);
	  if (rc) abortpgm(rc);
	  printf("Bytes Deallocated  : OK\n");
	  printf("\n");


	  rc = uppermemorybytesavailable(&umbsize);
	  if (rc) abortpgm(rc);
	  printf("UMB bytes avail    : %ld\n",umbsize);

	  if (umbsize == 0L)
	     printf("UMB test           : skipped\n");
	  else
	     {
		rc = allocateuppermemoryblocks(umbsize,&umbseg,&umbrealsize);
		if (rc) abortpgm(rc);
		printf("UMBs allocated     : OK\n");
		printf("UMBs size requested: %ld\n",umbsize);
		printf("Allocated umbs seg : %4.4X\n",umbseg);
		printf("Allocated umb size : %ld\n",umbrealsize);
		umbptr = TGMK_FP(umbseg,0);

		fillmem(umbptr,umbrealsize,44L);
		if (checkmem(umbptr,umbrealsize,44L))
		   abortexit("Bad bytes in umbs");

		rc = deallocateuppermemoryblocks(umbseg);
		if (rc) abortpgm(rc);
		printf("UMBs deallocated   : OK\n");
		printf("\n");
	     }


	  rc = xmsbytesavailable(&totalbytes,&bytesavail);
	  if (rc) abortpgm(rc);
	  printf("Bytes Total        : %ld\n",totalbytes);
	  printf("Bytes Available    : %ld\n",bytesavail);

	  rc = uppermemorybytesavailable(&umbsize);
	  if (rc) abortpgm(rc);
	  printf("UMB bytes avail    : %ld\n",umbsize);
       }
    else
       printf("XMS Driver not found\n");

}
