/*---------------------------------------------------------------------------*
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/

#include <teglcond.h>
#include "vmerror.h"
#include "virtmem.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "errorlog.h"


typedef struct personrec *personptr;
typedef struct personrec {
    unsigned _TGLONG_ custnum;
    char name[81];
    char company[81];
    unsigned age;
    char address[81];
    char city[81];
    char prov[81];
    char postal[21];
    char telephone[21];
    char filler[5];		/* make record even */
} personrec;



unsigned virterror(unsigned _TGLONG_ code)
{
    printf("Error - %s\n", xlaterrormsg((int)code));
    exit(0);
    return 0;
}


void main(int argc, char **argv)
{
    personptr customer;
    virtualptr customerdb;
    unsigned i;
    unsigned _TGLONG_ rsz;

    printf("TSTVPARR - A program to demonstrate a large array using VIRTMEM\n");
    printf("\n");

    setvirtualerrorproc(virterror);

    rsz = (unsigned _TGLONG_) sizeof(personrec);

    vpgethugemem(&customerdb, 2000 * rsz, rsz);
    vpaccess(customerdb,(void **)&customer);

    for (i = 0; i <= 1999; i++) {
	vphugeposition(customerdb, i * rsz, rsz);

	customer->custnum = (unsigned _TGLONG_) i;
	strcpy(customer->name, "Richard Tom");
	strcpy(customer->company, "TEGL Systems Corporation");
	customer->age = i;
	strcpy(customer->address, "P.O. Box 580, Stn. A");
	strcpy(customer->city, "Vancouver");
	strcpy(customer->prov, "British Columbia");
	strcpy(customer->postal, "V6C 2N2");
	strcpy(customer->telephone, "(604) 669-2577");

	printf("Updated Customer Index %d\n", i);
    }

    for (i = 0; i <= 1999; i++) {
	vphugeposition(customerdb, i * rsz, rsz);
	printf("Custnum %ld current:%d\n", customer->custnum, i);
    }

    vpfreemem(customerdb);
}
