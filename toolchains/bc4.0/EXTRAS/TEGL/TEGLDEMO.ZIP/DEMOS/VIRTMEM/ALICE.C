/*---------------------------------------------------------------------------*
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/

#include <teglcond.h>
#include <string.h>
#include "chkmem.h"
#include "vmerror.h"
#include "vmdrive.h"
#include "errorlog.h"
#include "dosfuncs.h"

#include <fcntl.h>		/* open    */
#include <sys\types.h>
#include <sys\stat.h>		/* O_Creat */
#include <dos.h>		/* errno   */
#include <io.h>
#include <stdio.h>
#include <stdlib.h>

#define bufsize 0x2000
char *p;
unsigned _TGLONG_ currofs;
unsigned _TGLONG_ currpos;
unsigned char eovdrvf;
unsigned _TGLONG_ booksize;

void abortme(char *msg, unsigned _TGLONG_ retcode)
{
    printf("%s %d\n", msg, retcode);
    exit(0);
}

unsigned _TGLONG_ copybooktovdrv(char *filename, vdrvfile vdrvbook)
{
    int book;
    char *buffer;
    unsigned bytesread;

    buffer = farmalloc(0x8000L);
    book = open(filename,O_BINARY | O_RDWR,S_IREAD);

    do {
	bytesread = read(book,buffer,0x8000);
	vdrvblockwrite(vdrvbook, buffer, bytesread);
	if (vmmstatus)
	   abortme("VMM Drive Error",vmmstatus);
    } while (bytesread);

    close(book);

    farfree(buffer);
    return vdrvposition(vdrvbook);
}


char *readvdrvline(vdrvfile vdrvbook)
{
    static char txtline[255];
    char *txtptr;
    char *ch;
    int wd;
    int done;

    done = FALSE;
    txtptr = txtline;
    *txtptr = 0;
    ch = (char *) &p[(unsigned)currofs];

    do {
	 if (*ch == 0x0a)
	    done = TRUE;
	 else
	 if (*ch>=' ') {
	    *txtptr = *ch;
	    txtptr++;
	    *txtptr = 0;
	 } else
	 if (*ch == 9) {
	     wd = 8-(strlen(txtline) % 8);
	     strncpy(txtptr,"         ",(unsigned)wd);
	     txtptr += wd;
	     *txtptr = 0;
	 }

	ch++;
	currofs++;
	currpos++;
	if (currofs == bufsize) {
	    currofs = 0;
	    vdrvblockread(vdrvbook, p, bufsize);
	    if (vmmstatus)
	       abortme("VMM Drive Error",vmmstatus);
	    ch = p;
	}

	if (currpos>=booksize) {
	   done = TRUE;
	   eovdrvf = TRUE;
	}

    } while (!done);

    return txtline;
}


void main(int argc, char **argv)
{

     vdrvfile vdrvbook;
     unsigned ftype;
     char pstr[80];


    if (argc < 2) {
	printf("ALICE - A test program to copy the ALICE.TXT to VDISK and reads it\n");
	printf("        back while displaying it to StdIO.\n");
	printf("   EMS - test EMS Disk drive \n");
	printf("   XMS - test XMS Disk drive \n");
	printf("   DSK - test Disk drive \n");
	exit(0);
    } else {
	strcpy(pstr,argv[1]);
	strupr(pstr);
	if (strcmp(pstr,"EMS") == 0)
	    ftype = EMSTYPE;
	else if (strcmp(pstr,"XMS") == 0)
	    ftype = XMSTYPE;
	else if (strcmp(pstr,"DSK") == 0)
	    ftype = DSKTYPE;
	else
	    ftype = EMSTYPE;
    }

    vdrvbook = vdrvopen(ftype, (unsigned _TGLONG_)65536L,(unsigned _TGLONG_)8000000L);
    if (vmmstatus)
	abortme("VDRV Open Error - ", vmmstatus);

    booksize = copybooktovdrv("alice.txt", vdrvbook);

    eovdrvf = FALSE;
    currpos = 0L;
    currofs = 0;
    p = farmalloc(bufsize);

    vdrvseek(vdrvbook, 0);
    vdrvblockread(vdrvbook, p, bufsize);

    while (!eovdrvf)
	printf("%s\n", readvdrvline(vdrvbook));

    vdrvclose(vdrvbook);

}
