/*---------------------------------------------------------------------------*
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/

#include <teglcond.h>
#include <stdio.h>	/* printf */
#include <string.h>	/* strcpy */
#include <stdlib.h>	/* exit */
#include "chkmem.h"
#include "vmerror.h"
#include "vmdrive.h"
#include "errorlog.h"
#include "dosfuncs.h"

vdrvfile myfile;

void abortme(char *msg, unsigned _TGLONG_ retcode)
{
    printf("%s %ld\n", msg, retcode);
    exit(0);
}


void main(int argc, char **argv)
{
    void *p;
    unsigned ftype;
    char pstr[80];
    unsigned _TGLONG_ w;

    if (argc < 2) {
	printf("TSTDRIVE [parm] - A test program to write and read from VDISK\n\n");
	printf("   EMS - test EMS Disk drive \n");
	printf("   XMS - test XMS Disk drive \n");
	printf("   DSK - test Disk drive \n");
	exit(0);
    } else {
	strcpy(pstr,argv[1]);
	strupr(pstr);
	if (strcmp(pstr,"EMS") == 0)
	    ftype = EMSTYPE;
	else if (strcmp(pstr,"XMS") == 0)
	    ftype = XMSTYPE;
	else if (strcmp(pstr,"DSK") == 0)
	    ftype = DSKTYPE;
	else
	    ftype = EMSTYPE;
    }

    p = farmalloc(0x20000L);
    fillmem(p,(unsigned _TGLONG_)0x20000L, (char)0xF2);

    printf("Comparing Buffer for valid pattern\n");
    if ((w=checkmem(p,(unsigned _TGLONG_)0x20000L,(char)0xF2))!=0) {
	printf("Error in comparison %ld\n", w);
	exit(0);
    }
    printf("Opening DSK File\n");
    myfile = vdrvopen(ftype,(unsigned _TGLONG_)65536L,(unsigned _TGLONG_)8000000L);
    if (vmmstatus)
	abortme("DSK Open Error - ", vmmstatus);

    printf("Writing DSK File\n");
    vdrvblockwrite(myfile, p,(unsigned _TGLONG_) 0x20000L);
    if (vmmstatus)
	abortme("DSK Write Error - ", vmmstatus);

    printf("Clearing Memory\n");
    fillmem(p,(unsigned _TGLONG_) 0x20000L,(char) 0x11);


    vdrvseek(myfile, 0);
    if (vmmstatus)
	abortme("Reset to File Start - ", vmmstatus);

    printf("Reading DSK File\n");
    vdrvblockread(myfile, p,(unsigned _TGLONG_)0x20000L);
    if (vmmstatus)
	abortme("DSK Read Error - ", vmmstatus);

    printf("Closing DSK File\n");
    vdrvclose(myfile);

    printf("Comparing Buffer for valid pattern\n");
    w = (unsigned _TGLONG_) checkmem(p, (unsigned _TGLONG_)0x20000L, (char)0xF2);
    if (w != 0) {
	printf("Error in comparison %ld\n", w);
	exit(0);
    }
    printf("Comparison OK\n");
}
