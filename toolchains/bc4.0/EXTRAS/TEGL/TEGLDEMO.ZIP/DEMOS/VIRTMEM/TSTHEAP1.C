/*---------------------------------------------------------------------------*
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/

#include <teglcond.h>
#include "chkmem.h"
#include "vmerror.h"
#include "vmdrive.h"
#include "vmvheap.h"
#include "vheapshw.h"
#include "errorlog.h"
#include "dosfuncs.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

unsigned tstvdskerror(unsigned _TGLONG_ code)
{
    printf("Error - %s\n", xlaterrormsg((int)code));
    exit(0);
    return 0;
}

void main(int argc, char **argv)
{
    unsigned i;
    unsigned _TGLONG_ blocks[10],w;
    char pstr[80];
    vdrvfile workdisk;
    vheapfile heapdisk;
    unsigned ftype;
    void *p;

    if (argc < 2) {
	printf("TSTHEAP1 [parm] - A program for testing the virtual heap\n");
	printf("                  Fixed blocks and adjacent block merge\n");
	printf("   EMS - test EMS Disk drive \n");
	printf("   XMS - test XMS Disk drive \n");
	printf("   DSK - test Disk drive \n");
	exit(0);
    } else {
	strcpy(pstr,argv[1]);
	strupr(pstr);
	if (strcmp(pstr,"EMS") == 0)
	    ftype = EMSTYPE;
	else if (strcmp(pstr,"XMS") == 0)
	    ftype = XMSTYPE;
	else if (strcmp(pstr,"DSK") == 0)
	    ftype = DSKTYPE;
	else
	    ftype = EMSTYPE;
    }

    setvheaperrorproc(tstvdskerror);
    p = farmalloc(0x20000L);

    workdisk = vdrvopen(ftype,(unsigned _TGLONG_) 500000L,(unsigned _TGLONG_) 0x0fffffffL);
    if (vmmstatus)
       tstvdskerror(vmmstatus);

    heapdisk = vheapinitialize(workdisk);

    vheapshowfreelist(heapdisk);
    for (i = 0; i < 10; i++) {
	blocks[i] = vheapgetmem(heapdisk,(unsigned _TGLONG_) 0x20000L);
	printf("Allocating & Writing Block %d [%ld]\n", i, blocks[i]);

	fillmem(p, (unsigned _TGLONG_)0x20000L, (char)(0xFE - i));
	vheapwritedata(heapdisk, p, blocks[i]);
    }
    vheapshowfreelist(heapdisk);

    for (i = 0; i < 10; i++) {
	printf("Reading & comparing Block %d [%ld]\n", i, blocks[i]);
	vheapreaddata(heapdisk, p, blocks[i]);

	w = checkmem(p,(unsigned _TGLONG_)0x20000L,(char)(0xFE-i));
	if (w) {
	    printf("Error in comparison %ld\n", w);
	    exit(0);
	}
    }


    printf("Freeing Block 0\n");
    vheapfreemem(heapdisk, blocks[0]);
    vheapshowfreelist(heapdisk);

    printf("Freeing Block 1\n");
    vheapfreemem(heapdisk, blocks[1]);
    vheapshowfreelist(heapdisk);

    printf("Freeing Block 3\n");
    vheapfreemem(heapdisk, blocks[3]);
    vheapshowfreelist(heapdisk);

    printf("Freeing Block 2\n");
    vheapfreemem(heapdisk, blocks[2]);
    vheapshowfreelist(heapdisk);

    printf("Freeing Block 9\n");
    vheapfreemem(heapdisk, blocks[9]);
    vheapshowfreelist(heapdisk);

    printf("Freeing Block 7\n");
    vheapfreemem(heapdisk, blocks[7]);
    vheapshowfreelist(heapdisk);

    printf("Freeing Block 5\n");
    vheapfreemem(heapdisk, blocks[5]);
    vheapshowfreelist(heapdisk);

    printf("Freeing Block 8\n");
    vheapfreemem(heapdisk, blocks[8]);
    vheapshowfreelist(heapdisk);

    printf("Freeing Block 4\n");
    vheapfreemem(heapdisk, blocks[4]);
    vheapshowfreelist(heapdisk);

    printf("Freeing Block 6\n");
    vheapfreemem(heapdisk, blocks[6]);
    vheapshowfreelist(heapdisk);

    vheapclosefile(heapdisk);
}
