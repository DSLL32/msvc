/*---------------------------------------------------------------------------*
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/

#include <teglcond.h>
#include <stdio.h>
#include "chkmem.h"
#include "vmems.h"
#include "errorlog.h"


    char	 emmversion[16];
    unsigned	 totalems;
    unsigned	 pagesavail;
    unsigned	 handlesavail;
    unsigned	 frameaddress;
    unsigned	 tsthandle;
    unsigned	 pagesowned;
    void *	 emsptr;
    int  rc;


void main(void)
{

    if (emminstalled())
       {
	  rc = (int) getemsversionnumber((char *)&emmversion);
	  if (rc) abortpgm(rc);
	  printf("EMS Driver Version : %s\n",&emmversion[1]);

	  rc = (int) emspagesavailable(&totalems,&pagesavail);
	  if (rc) abortpgm(rc);
	  printf("Pages Total        : %d\n",totalems);
	  printf("Pages Available    : %d\n",pagesavail);

	  rc = (int) gethandlecountused(&handlesavail);
	  if (rc) abortpgm(rc);
	  printf("Handles Available  : %d\n",handlesavail);

	  rc = (int) getpageframebaseaddress(&frameaddress);
	  if (rc) abortpgm(rc);
	  printf("Base Frame Address : %4.4X\n",frameaddress);
	  emsptr = TGMK_FP(frameaddress,0);

	  rc = (int) allocateexpandedmemorypages(pagesavail,&tsthandle);
	  if (rc) abortpgm(rc);
	  printf("Allocated handle   : %d\n",tsthandle);
	  printf("Allocated Pages    : %d\n",pagesavail);

	  rc = (int) mapexpandedmemorypages(tsthandle,0,0);
	  if (rc) abortpgm(rc);
	  fillmem(emsptr,0x4000,0);
	  rc = (int) mapexpandedmemorypages(tsthandle,1,0);
	  if (rc) abortpgm(rc);
	  fillmem(emsptr,0x4000,1);

	  rc = (int) mapexpandedmemorypages(tsthandle,0,0);
	  if (rc) abortpgm(rc);
	  if (checkmem(emsptr,0x4000,0))
	     abortexit("Bad unsigned chars in Mapped logical Page 0");

	  rc = (int) mapexpandedmemorypages(tsthandle,1,0);
	  if (rc) abortpgm(rc);
	  if (checkmem(emsptr,0x4000,1))
	     abortexit("Bad unsigned chars in Mapped logical Page 1");

	  printf("Mapping test       : OK\n");

	  rc = (int) getpagesownedbyhandle(tsthandle,&pagesowned);
	  if (rc) abortpgm(rc);
	  printf("Pages owned        : %d\n",pagesowned);

	  rc = (int) deallocateexpandedmemorypages(tsthandle);
	  if (rc) abortpgm(rc);
	  printf("Pages Deallocated  : OK\n");
	  printf("\n");

	  rc = (int) emspagesavailable(&totalems,&pagesavail);
	  if (rc) abortpgm(rc);
	  printf("Pages Total        : %d\n",totalems);
	  printf("Pages Available    : %d\n",pagesavail);
       }
    else
       printf("EMS Driver not found\n");

}



