/*---------------------------------------------------------------------------*
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/

#include <teglcond.h>
#include "chkmem.h"
#include "vmerror.h"
#include "vmvirt.h"
#include "errorlog.h"
#include "dosfuncs.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

unsigned virterror(unsigned _TGLONG_ code)
{
    printf("Error - %s\n", xlaterrormsg((int)code));
    exit(0);
    return 0;
}

void main(int argc, char **argv)
{
   unsigned _TGLONG_ blocks[100];
   unsigned i;
   unsigned _TGLONG_ w;
   void *p;

    printf("TSTVIRT - A program for testing moveto/from virtual\n");
    printf("\n");

    randomize();
    setvirtualerrorproc(virterror);

    p = farmalloc(0x20000L);
    /* usexmsvirt(FALSE); */
    /* useemsvirt(TRUE);  */
    /* usedskvirt(FALSE); */
    setxmsmaxsize(500000L);
    setemsmaxsize(500000L);

    for (i = 0; i < 20; i++) {
	fillmem(p, (unsigned _TGLONG_)0x20000L,(char)(0xFE - i));
	blocks[i] = movetovirtual(p,(unsigned _TGLONG_)0x20000L);
	printf("Block moved to Virtual %d [%ld]\n", i, blocks[i]);
    }

    for (i = 0; i < 20; i++) {
	movefromvirtual(p, blocks[i]);
	printf("Block moved from Virtual, comparing Block %d [%ld]\n", i, blocks[i]);

	w = checkmem(p,(unsigned _TGLONG_) 0x20000L, (char)(0xFE - i));
	if (w) {
	    printf("Error in comparison %ld\n", w);
	    exit(0);
	}
    }

    for (i = 0; i < 20; i++) {
	freevirtual(blocks[i]);
	printf("Block Free from Virtual %d [%ld]\n", i, blocks[i]);
    }


}
