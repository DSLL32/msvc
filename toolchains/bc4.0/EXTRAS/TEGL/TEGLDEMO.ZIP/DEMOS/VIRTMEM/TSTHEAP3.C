/*---------------------------------------------------------------------------*
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/

#include <teglcond.h>
#include "chkmem.h"
#include "vmerror.h"
#include "vmdrive.h"
#include "vmvheap.h"
#include "vheapshw.h"
#include "errorlog.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "dosfuncs.h"

#define TSTENTRIES 30

unsigned tstvdskerror(unsigned _TGLONG_ code)
{
    printf("Error - %s\n", xlaterrormsg((int)code));
    exit(0);
    return 0;
}

void main(int argc, char **argv)
{
    _TGLONG_ blocks[30];
    _TGLONG_ bsizes[30];
    unsigned i, j;
    unsigned _TGLONG_ w;
    vdrvfile workdisk;
    vheapfile heapdisk;
    void *p;

    printf("TSTHEAP3 - A program for testing the permanent virtual heap on disk\n");
    printf("           Random allocation/deallocation in varying sizes\n");

    randomize();
    setvheaperrorproc(tstvdskerror);

    p = farmalloc(0x20000L);
    fillmem(p,(unsigned _TGLONG_)0x20000L,(char)0xFF);

    setvirtfilename("VIRTMEM.$$$", DSKREADWRITE);

/*  workdisk = vdrvopen(DSKTYPE, 500000L, 0x0fffffffL); */
    workdisk = vdrvopen(DSKTYPE,(unsigned _TGLONG_)500000L,(unsigned _TGLONG_)0x00400000L);
    if (vmmstatus)
       tstvdskerror(vmmstatus);

    heapdisk = vheapinitialize(workdisk);

    for (i = 0; i < TSTENTRIES; i++) {
	fillmem(p,(unsigned _TGLONG_)0x20000L,(char)(0xFE - i));
	bsizes[i] = (((unsigned _TGLONG_) (random(1024)) * 124L) + 0xfffL) & 0xfffffffEL;
	blocks[i] = vheapgetmem(heapdisk,(unsigned _TGLONG_)bsizes[i]);
	printf("[%d][%d] Allocated %dk(s)\n",i,blocks[i],bsizes[i]);
	vheapwritedata(heapdisk, p,(unsigned _TGLONG_)blocks[i]);
    }
    vheapshowfreelist(heapdisk);

    for (i = 1; i <= 30; i++) {
	j = random(TSTENTRIES);
	printf("Randomly Releasing Block %d\n", j);
	if (blocks[j] != -1L) {
	    printf("[%d][%d] released %uk(s)\n",j,blocks[j],bsizes[j]);
	    vheapfreemem(heapdisk,(unsigned _TGLONG_)blocks[j]);
	}
	blocks[j] = -1L;
    }
    vheapshowfreelist(heapdisk);

    for (i = 1; i <= 40; i++) {
	j = random(TSTENTRIES);
	if (blocks[j] != -1L) {
	    printf("[%d][%d] Released %uk(s)\n",j,blocks[j],bsizes[j]);
	    vheapfreemem(heapdisk,(unsigned _TGLONG_)blocks[j]);
	}

	fillmem(p,(unsigned _TGLONG_)0x20000L,(char)(0xFE - j));
	bsizes[j] = (((unsigned _TGLONG_) (random(1024)) * 124L) + 0xfffL) & 0xfffffffEL;
	printf("--- Allocating %uk(s)\n",bsizes[j]);
	blocks[j] = (unsigned _TGLONG_) vheapgetmem(heapdisk,(unsigned _TGLONG_)bsizes[j]);
	printf("[%d][%d] Allocated %uk(s)\n",j,blocks[j],bsizes[j]);
	vheapwritedata(heapdisk, p,(unsigned _TGLONG_)blocks[j]);
    }
    vheapshowfreelist(heapdisk);

    printf("-----closing VIRTMEM.$$$ -----\n");
    vheapclosefile(heapdisk);

    printf("-----opening VIRTMEM.$$$ --------\n");
    workdisk = vdrvopen(DSKTYPE,(unsigned _TGLONG_)500000L,(unsigned _TGLONG_)0x0fffffffL);
    heapdisk = vheapinitialize(workdisk);

    for (i = 0; i < TSTENTRIES; i++) {
	printf("Reading & comparing Block%10ld%10ld\n", blocks[i - 1], bsizes[i - 1]);
	if (blocks[i] != -1L) {
	    vheapreaddata(heapdisk, p,(unsigned _TGLONG_)blocks[i]);
	    w = checkmem(p,(unsigned _TGLONG_)bsizes[i],(char)(0xFE-i));
	    if (w) {
		printf("Error in comparison %ld\n", w);
		exit(0);
	    }
	}
    }

    for (i = 0; i < TSTENTRIES; i++) {
	printf("Freeing Block%d\n", i);
	if (blocks[i] != -1L)
	    vheapfreemem(heapdisk,(unsigned _TGLONG_)blocks[i]);
    }

    vheapshowfreelist(heapdisk);
    vheapclosefile(heapdisk);
}

