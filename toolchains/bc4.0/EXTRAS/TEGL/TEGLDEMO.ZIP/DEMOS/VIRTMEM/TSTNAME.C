
#include <teglcond.h>
#include "dosfuncs.h"
#include <stdio.h>
#include <string.h>

void main(int argc, char **argv)
{
	char tmppath[80] = "";

	if (argc > 1)
	   strcpy(tmppath,argv[1]);

	printf("Generated Temp Filename : %s\n",dos_gentmpfilename(tmppath,(unsigned _TGLONG_)500000l));
}
