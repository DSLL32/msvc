/*---------------------------------------------------------------------------*
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/

#include <teglcond.h>
#include "pointers.h"
#include "chkmem.h"
#include <string.h>

#ifndef _PHAPIDOSX386_
#ifndef _PHAPIDOSX286_
unsigned char comparebytesok(char _TGFAR_ * buffer, char bytecompare, unsigned bytestocompare, unsigned *errorpos)
{
	unsigned   i;
	char _TGFAR_ * bufforg = buffer;

	*errorpos = 0;
	for (i = 0; i < bytestocompare; i++)
	   if ((char) *(buffer++) != bytecompare) {
	      *errorpos = (unsigned)(LINEAR_FP(buffer)-LINEAR_FP(bufforg));
	      return FALSE;
	   }

	return TRUE;
}
#endif
#endif

unsigned _TGLONG_ checkmem(char _TGFAR_ * q, unsigned _TGLONG_ sz, char bt)
{
#ifndef _PHAPIDOSX386_
#ifndef _PHAPIDOSX286_
	unsigned wravail;
	unsigned where;
	unsigned _TGLONG_ ct;

	ct = 0;
	while (sz > 0)
	   {
	     if (sz<0x8000)
		wravail = (unsigned)sz;
	     else
		wravail = 0x8000;

	     if (comparebytesok(q,bt,wravail,&where)) {
		q = (char _TGFAR_ *) (POINTER_FP(LINEAR_FP(q) + (unsigned _TGLONG_)wravail));
		sz -= (unsigned _TGLONG_)wravail;
		ct++;
	     } else
	       return ((ct*0x8000)+(unsigned _TGLONG_)where);
	   }
#else
	unsigned _TGLONG_ i;
	char huge * p = (char huge *)q;

	for (i=0; i<sz; i++,p++)
	   if (*p!=bt)
	      return i;
#endif
#else
	unsigned _TGLONG_ i;

	for (i=0; i<sz; i++,q++)
	   if (*q!=bt)
	      return i;
#endif
	return 0;
}


void fillmem(char _TGFAR_ * q, unsigned _TGLONG_ sz, char bt)
{
#ifndef _PHAPIDOSX386_
#ifndef _PHAPIDOSX286_
	unsigned wravail;

	while (sz > 0) {
	   if (sz<0x8000)
	      wravail = (unsigned)sz;
	   else
	      wravail = 0x8000;

	   memset(q,bt,wravail);
	   q = (char _TGFAR_ *) (POINTER_FP(LINEAR_FP(q) + (unsigned _TGLONG_)wravail));
	   sz -= (unsigned _TGLONG_)wravail;
	}
#else
	unsigned _TGLONG_ i;
	char huge * p = (char huge *)q;

	for (i=0; i<sz; i++,p++)
	   *p = bt;
#endif
#else
	unsigned _TGLONG_ i;

	for (i=0; i<sz; i++,q++)
	   *q = bt;
#endif
}

