/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
#include "teglsys.h"

  optionmptr   om1, om2;

unsigned getsenseevent(imagestkptr  fs, msclickptr   ms)
  {
    setmousesense(fs->x,fs->y);
    return 1;
  }

unsigned infooption(imagestkptr  fs, msclickptr   ms)
   {
      unsigned	       x, y, x1, y1;
      imagestkptr  ifs;
      unsigned	       ax, ay, ax1, ay1;

      hidemouse();

      x = 200;
      y = 120;
      x1 = x + 340;
      y1 = y + 100;

      ax = ms->ms.x + fs->x;
      ay = ms->ms.y + fs->y;
      ax1 = ms->ms.x1 + fs->x;
      ay1 = ms->ms.y1 + fs->y;

	/* -- push image creates the frame and saves the background image  */

      pushimage(x,y,x1,y1);
      ifs = stackptr;	/* -- stackptr has the most recent frame  */

	/* -- ziptobox creates a xor box that moves from one location to  */
	/* -- another and changes size. The msclickptr passed to the event  */
	/* -- has the coordinates of the mouse click area that has activated  */
	/* -- this event.  */

      ziptobox(ax,ay,ax1,ay1,x,y,x1,y1);

      setcolor(WHITE);
      shadowbox(x,y,x1,y1);

      setcolor(BLACK);
      setteglfont((fontptr)font14);
      outtegltextxy(x + 5,y + 5,"TEGL Windows Toolkit II");
      outtegltextxy(x + 5,y + 5 + teglcharheight(),"Jan. 1, 1990, Program Written by Richard Tom");

	/* -- next put up an ok button and associated a mouse click with  */
	/* -- it. No real event is called we just want to detect the mouse  */
	/* -- click to know when to close the window.  */

      putpict(x + 280,y + 75,(iconptr)imageOK,BLACK);
      definemouseclickarea(ifs,280,75,280 + 35,75 + 12,TRUE,nilunitproc,MSCLICK);
      setmouseposition(x + 290,y + 85);
      showmouse();

	/* -- wait until mouse action on this frame  */
      while (checkformouseselect(ifs) == NULL) ;
	/* -- then dispose of the frame and zip back to the orginal postion  */
	/* -- on the screen.  */

      hidemouse();
      dropstackimage(ifs);
      zipfrombox(ax,ay,ax1,ay1,ifs->x,ifs->y,ifs->x1,ifs->y1);
      showmouse();

      return 1;
   }




void main(void)
{



   easytegl();


   om1 = createoptionmenu((fontptr)font14);
   defineoptions(om1," ~O~pen ",TRUE,nilunitproc);
   defineoptions(om1," ~I~nfo...",TRUE,infooption);
   defineoptions(om1,"-",FALSE,nilunitproc);
   defineoptions(om1," ~Q~uit ",TRUE,quit);

   om2 = createoptionmenu((fontptr)font14);
   defineoptions(om2," ~M~emory ",TRUE,nilunitproc /*showcoordinates*/);
   defineoptions(om2," ~M~ouse Sensitivity ",TRUE,getsenseevent);

   createbarmenu(0,0,getmaxx());
   outbaroption(" ~F~ile ",om1);
   outbaroption(" ~U~tility ",om2);

     /*  -- control is then passed to the supervisor  */

   teglsupervisor();
}
