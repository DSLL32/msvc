/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
#include "teglsys.h"
/*
#include <teglcond.h>
#include <dos.h>
#include <stdlib.h>
#include <tgraph.h>
#include <fastgrph.h>
#include <teglintr.h>
#include <fontsys.h>
#include <virtmem.h>
#include <ipstacks.h>
#include <teglunit.h>
#include <teglmain.h>
#include <errorlog.h>
#include <teglmenu.h>
*/

unsigned beeptimes = 3;
unsigned dropclick = 0;
unsigned char booleanclick1 = TRUE;
unsigned char booleanclick2 = FALSE;
unsigned char booleanclick3 = FALSE;

unsigned exitoption(imagestkptr fs,msclickptr ms)
{
    abortexit("Menu keys test");
    return 1;
}

/*
 * This event is only added by the AddEntry event. When clicked on, this
 * event drops its own option menu entry from the menu.
 */

unsigned deleteentry(imagestkptr fs,msclickptr ms)
{
    optionmptr om;

    /* returns the related Option Menu chain */
    om = getfsom(fs);

    /*
     * Drops the current option entry, using the ms^.clicknumber as the entry
     * number
     */
    dropoptionentry(om,ms->clicknumber);

    return 1;
}

/*
 * AddEntries demonstrates how you can retrieve the current Option Menu and
 * its related Option entry and insert another option entry into the current
 * option menu.
 */

unsigned addentries(imagestkptr fs,msclickptr ms)
{
    optionmptr om;

    /* returns the related Option Menu chain */
    om = getfsom(fs);

    /*
     * sets the Option entry position in preparation of inserting another
     * entry. If the option entry number is 0, DefineOptions will create an
     * entry at the beginning of the chain.
     */
    setcurrentoepos(om,ms->clicknumber - 1);

    /*
     * use the standard DefineOptions() DefineOptionsRadio()
     * DefineOptionsCheck() or DefineOptionsSub() to create a new entry
     */

    defineoptions(om,"~D~elete Entry ",TRUE,deleteentry);
    return 1;
}


/*
 * You can change the action of the menu bar to drop down menus in which the
 * menu drops with a passing of the mouse. "dropclick" is an automatic
 * variable which is by the menu routines before calling this event. The
 * value in the "dropclick" is either 0 or 1 as passed by the
 * DefineOptionsRadio() below.
 */


unsigned dropclicktoggle(imagestkptr fs,msclickptr ms)
{
    /*
     * resets the complete mouseclick chain stored in a FS to MSClick or
     * MSSense. MSClick is a boolean value of 0, and MSSense is 1.
     */
    resetmsclicksense(fs->relatedstack,(unsigned char)dropclick);

    return 1;
}


/*
 * Acknowledge is a simple event that aknowledges that it has been called by
 * beeping. The number of beeps is controlled by the variable Beeptimes;
 * which is an automatic variable updated by the menu routines. For more info
 * on automatic variables, look at the menu defines for DefineOptionsRadio().
 */

unsigned acknowledge(imagestkptr fs,msclickptr ms)
{
    unsigned i;

    /*
     * Use WaitforUserRelease to wait for the user to release either the key
     * or mouse button before proceeding. Waiting for the user to release the
     * mouse button is not necessary in a menu since the menu waits for you
     * to release before calling the event. However if you use the same event
     * for icons or other defined mouse click areas, this event may be called
     * several times before the button is release.
     */

    waitforuserrelease();

    for (i = 1; i <= beeptimes; i++) {
	beep(1000,1,150);
	beep(500,1,50);
    }
    return 1;
}


/*
 * Defining the option menus may be defined within a procedure or at the MAIN
 * part of the program.
 */


void createmenubarevents(void)
{
    optionmptr om1,om2,om3,om4,om5;

    /*
     * StandardFont is set with the initialization of TEGL in Fastgrph. When
     * creating Option menus, the proportional flag is saved with each option
     * menu, therefore if you wish to have non-proportional menus, you must
     * set the proportional flag off before creating the option menu.
     */

    setproportional(TRUE);

    /*
     * OM1 is a standard menu with each entry attached to the Acknowledge
     * event. The dashed line is used to indicate a line separator between
     * topics.
     */

    standardfont = (fontptr)roman25;

    om1 = createoptionmenu(standardfont);
    defineoptions(om1,"DeskTop Info...",TRUE,acknowledge);
    defineoptions(om1,"--",FALSE,NULL);
    defineoptions(om1,"Calculator",TRUE,acknowledge);
    defineoptions(om1,"Clock",TRUE,acknowledge);
    defineoptions(om1,"Snapshot",TRUE,acknowledge);


    /*
     * OM2 uses a combination of several features offered in TEGLMENU. The
     * first is the ">" symbol in Open. This symbol tells the option menu
     * (when listing) to right justify the remaining portion of the text.
     *
     * The curly brackets around F1^ will display F1^ in tiny font.
     *
     * The tilde ~ character indicates the underscoring of the enclosed
     * characters, of which the first character becomes the default keyboard
     * activator.
     *
     * Global key clicks like Alt-x and ctrl-F1 must be defined using the
     * definelocal and defineglobal key clicks. The menu routine only
     * recognizes alphabets and numeric characters when attaching local key
     * clicks.
     */

    om2 = createoptionmenu(standardfont);
    defineoptions(om2,"Open >{ctrl-F1}",TRUE,acknowledge);
    defineoptions(om2,"Show ~I~nfo...",FALSE,acknowledge);
    defineoptions(om2,"--",FALSE,NULL);
    defineoptions(om2,"~N~ew Folder...",FALSE,acknowledge);
    defineoptions(om2,"~C~lose",FALSE,acknowledge);
    defineoptions(om2,"Close ~W~indow",FALSE,acknowledge);
    defineoptions(om2,"--",FALSE,NULL);
    defineoptions(om2,"~F~ormat...",TRUE,acknowledge);
    defineoptions(om2,"To ~O~utput",TRUE,acknowledge);
    defineoptions(om2,"{ALT-X}~Q~uit",TRUE,exitoption);
    defineglobalkeyclickarea(NULL,NULL,0x082d,FALSE,exitoption);
    defineglobalkeyclickarea(NULL,NULL,0x003b,FALSE,acknowledge);

    /*
     * DefineOptionsRadio provides a method of toggling between options or
     * group of options. The controlling variable is updated automatically by
     * the menu handler before the your event is called. You can use
     * "NULL" if you don't need any other activity after the user has
     * toggle the appropriate menu choices.
     *
     * The parameters 1,2,3,4 in DefineOptionsRadio is the value that is used to
     * compare against the variable BeepTimes in determing whether or not the
     * entry is prefixed with a check mark. When defining radio entries, be
     * sure to set the menu margins to 10 or more pixels to allow room for
     * the check mark symbol.
     */

    setmenumargin(10);
    om3 = createoptionmenu(standardfont);
    defineoptionsradio(om3,"~C~lick Menus",TRUE,dropclicktoggle,0,&dropclick);
    defineoptionsradio(om3,"~D~rop Menus",TRUE,dropclicktoggle,1,&dropclick);
    defineoptions(om3,"-",FALSE,NULL);

    defineoptionscheck(om3,"~A~-Check Menus",TRUE,acknowledge,&booleanclick1);
    defineoptionscheck(om3,"~B~-Check Menus",TRUE,acknowledge,&booleanclick2);
    defineoptionscheck(om3,"~C~-Check Menus",TRUE,acknowledge,&booleanclick3);

    defineoptions(om3,"-",FALSE,NULL);
    defineoptionscheck(om3,"~S~ound On",TRUE,acknowledge,&beepstatus);

    defineoptions(om3,"-",FALSE,NULL);
    defineoptionsradio(om3,"Beep ~1~ time ",TRUE,acknowledge,1,&beeptimes);
    defineoptionsradio(om3,"Beep ~2~ times",TRUE,acknowledge,2,&beeptimes);
    defineoptionsradio(om3,"Beep ~3~ times",FALSE,acknowledge,3,&beeptimes);
    defineoptionsradio(om3,"Beep ~4~ times",TRUE,acknowledge,4,&beeptimes);


    /*
     * Two other unique features of TEGLMENU is used in this option menu. The
     * Addentries event is added as a menu entry, which when activated,
     * inserts another option entry above the current entry. The inserted
     * entry is a delete option entry, which when activated, will delete
     * itself from the option menu. Refer to the events above to see how this
     * is done... The Delete entry at the bottom of the menu demonstrates
     * that even the last entry can be deleted.
     *
     * The defineoptionsSub() is introduced here, allowing the linking of
     * several option menus including itself for a recursive chaining of
     * menus. Again watch for the menumargins. A margin must be provided on
     * the right side for displaying the submenu symbol (). In the example
     * below, the largest entry is longer than the defineoptionsSub entry,
     * thereby allowing us to use a menu margin of 5 without the submenu
     * symbol overlapping with our option entry text.
     */

    setmenumargin(5);
    om4 = createoptionmenu(standardfont);
    defineoptions(om4,"~A~dd More Entries ",TRUE,addentries);
    defineoptions(om4,"Chance ~I~nfo...",TRUE,acknowledge);
    defineoptions(om4,"~F~rame Test Write...",TRUE,acknowledge);
    defineoptions(om4,"~C~redit Option.",TRUE,acknowledge);
    defineoptions(om4,"~D~os Shell...",TRUE,acknowledge);
    defineoptionssub(om4,"~S~ort Options",TRUE,om3);
    defineoptionssub(om4,"More ~O~ptions",TRUE,om2);
    defineoptionssub(om4,"~R~ecursive",TRUE,om4);
    defineoptions(om4,"--",FALSE,NULL);
    defineoptions(om4,"Select Nothing...",TRUE,acknowledge);
    defineoptions(om4,"Show Memory...",TRUE,acknowledge);
    defineoptions(om4,"Show ~B~utton Status",TRUE,acknowledge);
    defineoptions(om4,"Set ~M~ouse Sensivity",TRUE,acknowledge);
    defineoptions(om4,"--",FALSE,NULL);
    defineoptions(om4,"~A~dd More Entries ",TRUE,addentries);
    defineoptions(om4,"Delete ~E~ntry ",TRUE,deleteentry);

    /*
     * TEGL automatically converts menus to menus with sliders when the
     * number of entries displayed is greater than the screen size. You can
     * adjust the display number to a smaller size
     */

    setomdisplaynum(om4,15);

    /*
     * The last option menu demonstrates the ability to create long menu
     * entries. The current maximum is set to 40 characters per menu entry.
     * You can change this by changing the constant MaxTextStringSize which
     * is defined at the top of the TEGLMENU module.
     *
     * Notice the use of the | character in |Types |Variables |Attributes and
     * |Objects.  This is the tab expansion character allowing simple
     * formating on the menu.
     */


    om5 = createoptionmenu(standardfont);
    defineoptions(om5,"~S~tandard Unit Dependencies",TRUE,acknowledge);
    defineoptions(om5,"The System Unit",TRUE,acknowledge);
    defineoptions(om5,"The Printer Unit",TRUE,acknowledge);
    defineoptions(om5,"--",FALSE,NULL);
    defineoptions(om5,"The Dos Unit",TRUE,acknowledge);
    defineoptions(om5,"Constants |Types |Variables",TRUE,acknowledge);
    defineoptions(om5,"Methods |Attributes |Objects",TRUE,acknowledge);
    defineoptions(om5,"File |Streams |TEGL",TRUE,acknowledge);
    defineoptions(om5,"~A~dd More Entries ",TRUE,addentries);
    defineoptions(om5,"--",FALSE,NULL);
    defineoptions(om5,"Interrupt Support Procedures",TRUE,acknowledge);
    defineoptions(om5,"Disk Status Functions",TRUE,acknowledge);
    defineoptions(om5,"File-Handling Procedures and functions",TRUE,acknowledge);

    setteglfont(standardfont);
    createbarmenu(0,0,getmaxx());
    setbarmenumargin(24);
    outbaroption(" ~D~esk  ",om1);
    setmousebutton(stackptr->msptr,2);
    outbaroption(" ~F~ile  ",om2);
    outbaroption(" ~V~iew  ",om3);
    outbaroption(" A ~S~econd Chance ",om4);
    outbaroption(" Standard ~U~nits ",om5);
    outbarevent(" ~B~eep ",acknowledge);
    resetmsclicksense(stackptr,(unsigned char)dropclick);


    /* Define the ESC key to simulate a function key for escaping from menus */
    defineglobalkeyclickarea(stackptr,NULL,0x0001,FALSE,NULL);

    /* If you don't need it later, you can use the following to drop the ESC */
    /* DropKeyClick(NIL,$0001,NULL);			      */
}



void main()
{
/*  Easier Startup */
    easytegl();

/*  Optional Startup. Forcing a Video Mode */
/*  Note: Use either easytegl() or teglinit(). NOT both */
/*
    registertgidriver(GRVGA256_driver);
    setstandardheapsize(20000l);
    teglinit("SVGA1024x768x256",12288l);
    clearteglscreen();
*/
    seteasyfont((fontptr)font14);
    easyout();

    setrgbpalette(240,0,0,0);
    setrgbpalette(255,63,63,63);

    /*
     * There are a number of variables that are used to control the visual
     * aspects of the menus. The MC table stores the setup values for the
     * menu in which you can create a similar table with your default values
     * and simply assign the whole table to MC.
     *
     * As an example, a HERC_MC table has been created for your in TEGLMENU.  If
     * you are using a Hercules monitor you can use the following statement
     * to set your menu defaults immediately.
     *
     * IF Getmaxcolor < 2 then	(* set B/W parms *) MC := HERC_MC;
     *
     * If you only need to set a few default parameters, here is a quick summary
     * of the functions that are available that you may use to control your
     * menu displays....
     *
     * SetOptionMenuColors(activecolor,inactivecolor:unsigned); ... Sets the
     * active and inactive text entry colors within the menu. The default
     * colors is set to Black and lightgray respectively.
     *
     * SetOptionMenuBorderColor(Color:unsigned); ... Sets the Border color
     * around the menu. The default border color is black.
     *
     * SetBarTextColor(Color:unsigned); ... Sets the text color on the bar menu.
     * Default is Black.
     *
     * SetBarMenuMargin(margin:unsigned); ... Sets the left margin on the Bar
     * menu. Useful if you wish to display an icon at the upper left corner
     * of the bar menu. The default is an indentation of 16 pixels from the
     * left part of the bar menu.
     *
     * SetBarMenuColor(Color:unsigned); ... Sets the Bar menu Color. Default is
     * white.
     *
     * SetBarBorderOff; ... Sets the Border off. Default is on.
     *
     * SetBarBorderColor(Color:unsigned); ... Sets the Bar Border color and
     * turns the border on. Default is black.
     *
     * SetHideSubMenu(on_off:Boolean); ... You can choose whether to hide the
     * option menu after the user makes a selection. The default is the menu
     * remains shown until the event completes its task and returns.
     *
     * SetMenuMargin(pixsize:unsigned); ... Sets the option menu margin. The
     * default is 10 pixels before the option entry text. A minimum of 10
     * pixels is needed for check mark option entries.
     *
     * SetMenuTabsize(charnum:unsigned); ... Sets the number of characters for
     * tab expansion. A tab is represented by the | character. The default is
     * 8 characters.
     *
     * SetSeparatorLine(mask:unsigned); ... Sets the mask for the line
     * separator. A dotted line is $EE and a solidline is $FF. The default is
     * a solidline.
     *
     * SetInactiveJaggies(on_off:Boolean); ... Inactive option entries may be
     * displayed with jagged characters. The default is off.
     *
     * SetOMSliderSize(width,height:unsigned); ... Sets the width and height of
     * the slider buttons. Minimum button size is 9x9
     */


    setomslidersize(15,12);
    sethidesubmenu(FALSE);
    setmenutabsize(12);
    /* SetSeparatorLine($EE); *//* creates dashed separator lines */
    createmenubarevents();

    /* Sets the ctrlbreak key to the exit event */
    setctrlbreakfs(exitoption);

    teglsupervisor();
}
