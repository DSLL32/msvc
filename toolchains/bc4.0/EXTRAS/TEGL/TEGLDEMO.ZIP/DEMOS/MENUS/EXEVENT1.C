/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
#include "teglsys.h"

  optionmptr   om1, om2;

  /* -- This event will open up a frame and display a message. Then  */
  /* -- it returns leaving the frame displayed. Since no event has  */
  /* -- been defined to close this frame then it will stay up, there  */
  /* -- is no way to get rid of it.  */


unsigned  infooption(imagestkptr  fs, msclickptr   ms)
   {
      unsigned	     x, y, x1, y1;

      hidemouse();

      x = 200;
      y = 120;
      x1 = x + 340;
      y1 = y + 100;

      pushimage(x,y,x1,y1);
      setcolor(WHITE);
      shadowbox(x,y,x1,y1);
      setcolor(BLACK);
      outtegltextxy(x + 5,y + 5,"TEGL Windows Toolkit II");
      outtegltextxy(x + 5,y + 5 + teglcharheight(),"Jan 1,1990, Program Written by Richard Tom");

      showmouse();

      return 1;
   }




void main(void)
{

   easytegl();


   om1 = createoptionmenu((fontptr)font14);
   defineoptions(om1," ~O~pen ",TRUE,nilunitproc);
   defineoptions(om1," ~I~nfo...",TRUE,infooption);
   defineoptions(om1,"-",FALSE,nilunitproc);
   defineoptions(om1," ~Q~uit ",TRUE,quit);

   om2 = createoptionmenu((fontptr)font14);
   defineoptions(om2," ~M~emory ",TRUE,nilunitproc /*showcoordinates*/);
   defineoptions(om2," ~M~ouse Sensitivity ",TRUE,nilunitproc/*getmssense()*/);

   createbarmenu(0,0,getmaxx());
   outbaroption(" ~F~ile ",om1);
   outbaroption(" ~U~tility ",om2);

     /*  -- control is then passed to the supervisor  */

   teglsupervisor();
}
