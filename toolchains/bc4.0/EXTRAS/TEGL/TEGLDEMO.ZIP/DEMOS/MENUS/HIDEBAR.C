  /* -- hidebar.c  */
  /* -- shows how to hide a bar menu then redisplay it after some action.  */
  /* -- This is a simple example to show the technique. Some applications  */
  /* -- may want to create a variety of bar menus that could then be  */
  /* -- selectivly displayed depending on the state of the program.  */
  /* -- Note that the program has to keep track of which menu is currently  */
  /* -- displayed.  */

#include "teglsys.h"

  imagestkptr  mainbar;   /* -- save the bar menu, just a frame  */
  unsigned char      mainbarshown;   /* -- flag to track it.  */



void         hidemainmenu(imagestkptr  ifs, msclickptr   ms)
  {
    if (mainbarshown)
      {
          /* -- import trick here to make things work smoothly!!!  */
          /* -- toggleoptionbar undoes the highlight on the option  */
          /* -- click area that is set when the mouse passed over  */
          /* -- it. We use the related ifs & ms because the function  */
          /* -- is passed the option menu frame when we want the  */
          /* -- bar menu frame, this is what is in the related fields.  */
          /* -- if we didn't do this then when the bar menu was  */
          /* -- later turned back on. The menu selection would appear  */
          /* -- inverted.  */
        toggleoptionbar(ifs->relatedstack,ifs->relatedmsclick,NULL);
          /* -- just hide the bar menu frame, just like any other frame.  */
        hideimage(mainbar);
        mainbarshown = FALSE;
      }
      /*  else called in the wrong sequence.  */
  }


void         showmainmenu(void)
  {
    if (!mainbarshown)
      {
        showimage(mainbar,0,0);
        mainbarshown = TRUE;
      }
      /*  else called in the wrong sequence.  */
  }

  /* -- drops the frame then shows the bar menu again.  */


unsigned         dropdoit(imagestkptr  ifs, msclickptr   ms)
  {
    dropstackimage(ifs);
    showmainmenu();
    return 0;
  }

  /* -- hide the bar menu and create a frame with a single button  */
  /* -- that calls dropdoit which will then show the bar menu  */
  /* -- again.  */


unsigned         doit(imagestkptr  ifs, msclickptr   ms)
  { imagestkptr  locifs;

    hidemainmenu(ifs,ms);

    pushimage(0,getmaxy() - 30, getmaxx(), getmaxy());
    locifs = stackptr;
    prepareforupdate(locifs);
    bevelbox(locifs->x,locifs->y,locifs->x1,locifs->y1,
                   LIGHTGRAY,DARKGRAY,WHITE,4);
    commitupdate();

    definesquarebuttontext(locifs,
                           (getmaxx() / 2) - 20,7,(getmaxx() / 2) + 20,23,
                           10,5,"OK",dropdoit);

    return 0;
  }



void         createmenus(void)
  { optionmptr   om1, om2;

    om1 = createoptionmenu(f8x8bold);
    defineoptions(om1," ~Q~uit ",TRUE,quit);
    om2 = createoptionmenu(f8x8bold);
    defineoptions(om2," ~D~oit ",TRUE,doit);

    setteglfont(f8x8bold);
    createbarmenu(0,0,getmaxx());
    mainbar = stackptr;
    outbaroption(" ~S~ystem ",om1);
    outbaroption(" ~T~hing ",om2);
    mainbarshown = TRUE;
  }


void main(void)
{


  easytegl();
  easyout();
    /* -- hide the submenu as soon as a selection is made.  */
  sethidesubmenu(TRUE);
  createmenus();
  teglsupervisor();
}



