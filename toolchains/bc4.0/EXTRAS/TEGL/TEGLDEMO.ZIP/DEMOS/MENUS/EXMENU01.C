/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
#include "teglsys.h"

optionmptr  om1, om2;

void main()
  {
    easytegl();     /* simplified startup */
    easyout();	    /* exit button */

    om1 = createoptionmenu((fontptr)font14);
    defineoptions(om1," ~I~nfo... ", TRUE, nilunitproc);
    defineoptions(om1,"-",     FALSE, nilunitproc);
    defineoptions(om1," ~Q~uit ", TRUE, quit);

    om2 = createoptionmenu((fontptr)font14);
    defineoptions(om2," ~M~emory ",TRUE,nilunitproc/*showcoordinates*/);
    defineoptions(om2," ~M~ouse sensitivity ",TRUE,nilunitproc /*getmssense*/);

    createbarmenu(0,0,getmaxx());
    outbaroption(" ~F~ile ",om1);
    outbaroption(" ~U~tility ",om2);

    teglsupervisor();
  }
