/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
#include "teglsys.h"

void simplewindow(void)
  {
    winframeptr wf;

    twinit(&wf,10,10,300,120);
    twsetheader(wf,"A Simple window");
    twdrawwindowframe(wf);
  }

void startup(void)
  {

/*  Optional Startup. Forcing a Video Mode		   */
/*  Note: Use either tweasystart() or teglinit(). NOT both */
/*							   */

/*  registertgidriver((void (*)(void))GRCGABW_driver); */
    registertgidriver((void (*)(void))GRVGA256_driver);
    registertgidriver((void (*)(void))GREVGA16_driver);
    setstandardheapsize(20000l); /* Reserve about 20k for Video Drivers */
    twcommoninit();
    /* just use one of the following lines */

    teglinit(videoautodetect(),12288l);
    /*	teglinit("CGA640x200x2", 12288l); */
    /*	teglinit("EGA640x350x16",12288l); */
    /*	teglinit("VGA640x480x16",12288l); */
    /*	teglinit("VGA320x200x256",12288l); */
    /*	teglinit("SVGA800x600x16",12288l);    */
    /* teglinit("SVGA800x600x256",12288l); */
    /****************************************/
    clearteglscreen();
    seteasyfont((fontptr)font14);
    easyout();
}
void main(void)
    {
    /*tweasystart*/
    showmousecursor = TRUE;
    startup(); /* see above */

    setrgbpalette(240,0,0,0);
    setrgbpalette(255,63,63,63);


    setautorotate(TRUE);
    setkeyboardmouse(FALSE);

    simplewindow();
    teglsupervisor();

  }

