/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
#include "teglsys.h"

unsigned redrawit(imagestkptr ifs, msclickptr ms)
  {

    winframeptr wf;
    wf = findwinframe(ifs);
    twselect(wf);
    settextstyle(TRIPLEX_FONT, HORIZ_DIR, 1);
    setfillstyle(HATCH_FILL, BLUE);
    setcolor(BLUE);
    outtextxy(200,90,"XY");
    setteglfont((fontptr)f8x8bold);
    outtextxy(100,90,"TEGL FONT");
    settextstyle(SMALL_FONT, HORIZ_DIR, 4);
    outtextxy(50,50,"Simple font");
    line(200,90,240,90);
    return 0;
  }

  /* -- this is the start up code for the system. A sample only. Your  */
  /* -- application should do its own start up.  */

void	     startup(void)
  {
      /* -- link in the video drivers. Only link in the necessary ones!  */
      /* -- each driver adds about 6-7K of code size.  */
      /* -- Optionally no drivers can be linked in an the appropriate one  */
      /* -- will be loaded from the disk drive onto the heap. The driver  */
      /* -- must be in the path.  */

/*  registertgidriver((void (*)(void))GREVGA16_driver);
    registertgidriver((void (*)(void))GRCGABW_driver);
    registertgidriver((void (*)(void))GRHERCBW_driver); */
    registertgidriver((void (*)(void))GRVGA256_driver);

      /* -- set the amount of memory to be left over to the standard heap.  */
      /* -- It is always a good idea to monitor the memory usage during  */
      /* -- program development. See the memory monitor in this example.  */

    setstandardheapsize(16000);   /* -- thats how much memory we leave the heap  */

      /* -- Some standard heap is used for a scan buffer (8K default).	*/
      /* -- You can set this to a lower value if you don't do a lot of  */
      /* -- poly fills. NOTE! Flood fill uses the stack, if you use flood fill	*/
      /* -- be sure there is adequate stack space.  */

    allocatescanbuffer(40000);

      /* -- this call is not specifically necessary, but it initializes the  */
      /* -- virtual memory manager and consequently we can determine what  */
      /* -- the page area is and set an appropriate value for maxwindowsize.  */

    initteglheap();

      /* -- MaxWindowsize is the size of the bit-image buffers that make up  */
      /* -- a frame buffer. A frame can be broken into many pieces. It is,  */
      /* -- however, necessary to have sufficient memory on the virtual page  */
      /* -- area to store at least two buffers. Here we set MaxWindowSize  */
      /* -- to the size of VirtualPageArea DIVIDED by 3. Reasonably safe.  */
      /* -- The larger MaxWindowSize is the faster the window updates will  */
      /* -- be. If not set it defaults to 32K which gives a moderate speed  */
      /* -- but requires relatively little memory.  */

    maxwindowsize = cmaxavail() / 3;

      /* -- VideoAutoDetect returns a string that has the highest detectable  */
      /* -- resolution for the graphics hardware. SUPER VGA is NEVER enabled.  */
      /* -- This will return at most VGA 640 x 480 x 16 colors. Other modes  */
      /* -- must be set explicitly.  */

      /* -- TeglInit does all sorts of stuff, saves the interrupt vectors  */
      /* -- sets important exit routines. The second parameter to TEGLInit  */
      /* -- is no longer used. It is just there for compatability with	*/
      /* -- previous versions.	*/

/*  teglinit(videoautodetect(),12000);*/ /* -- initialize graphics system  */
    teglinit("SVGA640x480x256",12000);   /* -- initialize graphics system  */
    twcommoninit();	 /* for tw & to windows */
    clearteglscreen();	 /* -- clear screen  */
    emergencyexit();   /* -- provide abort mechanism  */
  }

void main(void)
  {
    winframeptr wf;

    /* -- simple start up, minimal normal heap, TWCOMMON  */
    /* tweasystart(); */

    /* -- use more specific startup, see function above */
    startup();

    twinit(&wf, 10, 320, 450, 500);
      twsetheader(wf,"Text test");
      twsetredraw(wf,redrawit);
    twdrawwindowframe(wf);

    teglsupervisor();
  }
