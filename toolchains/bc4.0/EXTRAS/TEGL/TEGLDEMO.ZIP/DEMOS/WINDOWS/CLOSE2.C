/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
#include "teglsys.h"

  imagestkptr  secondwind;

unsigned myclose(imagestkptr  ifs, msclickptr	ms)
  {
    if (visualbuttonpress(ifs,ms)) {
       twclose(findwinframe(ifs));
       twclose(findwinframe(secondwind));
    }
    return 0;
  }

unsigned myredraw(imagestkptr  ifs, msclickptr	 ms)
  {
    setviewport(0,0,getmaxx(),getmaxy(),FALSE);
    definebuttonclick(ifs,ifs->x+150,ifs->y+150,(iconptr)imageOK,myclose);
    return 0;
  }

unsigned opentest(imagestkptr  ifs, msclickptr	 ms)
  { winframeptr  wf;

    twinit(&wf,50,50,250,250);
    twdrawwindowframe(wf);
    secondwind = wf->ifs;

    twinit(&wf,100,100,300,300);
    twsetredraw(wf,myredraw);
    twdrawwindowframe(wf);

    return 0;
  }

void main(void)
{
  optionmptr   fileom;
  optionmptr   devicesom;

    /* -- simple start up, minimal normal heap, TWCOMMON  */
  tweasystart();

  fileom = createoptionmenu((fontptr)f8x12bol);
    defineoptions(fileom,"-",FALSE,nilunitproc);
    defineoptions(fileom," E~x~it ",TRUE,twexitoption);
  devicesom = createoptionmenu((fontptr)f8x12bol);
    defineoptions(devicesom,"~T~est",TRUE,opentest);

  setteglfont((fontptr)f8x12bol);   /* -- bar menu uses the current font  */
  createbarmenu(0,0,getmaxx());
    outbaroption(" ~F~ile ",fileom);
    outbaroption(" ~D~evices ",devicesom);

  setautorotate(TRUE);	 /* -- windows rotate to the top automatically	*/
  teglsupervisor();   /* -- do not adjust your set, the supervisor  */
				/* -- is in control!  */
}
