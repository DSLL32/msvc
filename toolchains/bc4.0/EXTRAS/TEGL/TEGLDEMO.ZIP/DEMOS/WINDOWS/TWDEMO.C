/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
#include "teglsys.h"
#include "vmvirt.h"
#ifndef __WATCOMC__
#include "math.h"
#endif
#include "dos.h"

  /* -- Global variables  */

  int TECHNA_FONT;
  int TALL_FONT;

  imagestkptr  mainmenu;   /* -- the main bar menu is only an ordinary frame */
			     /* -- with option menu click areas placed on it.  */
  fontptr      menufont;   /* -- the font to use with all menus. Set once so  */
			     /* -- we can make the program look better on  */
			     /* -- a variety of video displays.  */
  optionmptr   fileom;
  optionmptr   devicesom;
  optionmptr   dialogom;
  optionmptr   worldom;


unsigned  memorymonitor(imagestkptr  ifs, msclickptr   ms)
  {
     installmemorymonitor(!twnobuffers);
     return 0;
  }

unsigned dosshell(imagestkptr  ifs, msclickptr	 ms)
  {
    hidemouse();
    pushimage(0,0,getmaxx(),getmaxy());
    swapteglintroff();
    restorecrtmode();

    if (dos_exec("","",1,0xFFFF,FALSE) == 0) ;

    restorevemsmappedpages();
    if (initvideomode() == 0) ;
    swapteglintron();
    popimage();
    showmouse();

    return 0;
  }





  /* --------------------------------------------------------- */
  /* -- These are some global variable for our dialog window to access	*/


	winframeptr  wf 	   = NULL;
	char	     strtd[21]	   = "This is a string";
	unsigned char  chkbox	     = TRUE;
	int	     radio	   = 2;

  /* -- Note that closing a dialog calls twdClose not twClose, it must */
  /* -- first dispose of the list of dialog entries before the window  */


unsigned dialogclose(imagestkptr  ifs, msclickptr   ms)
  {
    wf = NULL;
    return twdlgclose(ifs,ms);

  }

  /* -- Opens up a simple dialog window.  */


unsigned opendialogdemo(imagestkptr  ifs, msclickptr   ms)
  {
    dlgctrlptr dlg;

    if (wf != NULL)   /* -- only one allowed.  */
      {
	dlgsay("ERROR","The dialog demo is already running.",1);
	return 0;
      }
    dlg = twdlginit(&wf,100,100,400,300);
      twsetheader(wf,"Simple Dialogue");
      dlgaddlabel(dlg,10,10,"Labels go anywhere");
	/* -- input lines are string items, the last parameter is the  */
	/* -- length of the string.  */
      dlgaddinputline(dlg,10,30,"Edit this ",strtd,20);
	/* -- check boxes are boolean values  */
      dlgaddcheckbox(dlg,10,50,"a check box",&chkbox);
	/* -- radio buttons all access the same integer value. Their  */
	/* -- order is important. The first one will be one the  */
	/* -- second two, etc. Groups of radio buttons must be seperated  */
	/* -- by either some other dialog item or a label, if nothing is  */
	/* -- required use an empty label.  */
      dlgaddradiobutton(dlg,10,70,"a radio button (1)",&radio);
      dlgaddradiobutton(dlg,10,90,"a radio button (2)",&radio);
      dlgaddradiobutton(dlg,10,110,"a radio button (3)",&radio);
	/* -- Buttons are associated with events, here the OK button does  */
	/* -- nothing, but the cancel button closes the dialog.  */
      dlgaddbutton(dlg,50,140,"OK",nilunitproc);
	dlgsetenteritem(dlg,dlggetcurrent(dlg));
      dlgaddbutton(dlg,180,140,"CANCEL",dialogclose);
	dlgsetescapeitem(dlg,dlggetcurrent(dlg));
      twsetcloseevent(wf,dialogclose);	 /* -- the space bar menu  */

      /* -- Note that the window is only drawn AFTER ALL THE DIALOG ITEMS  */
      /* -- HAVE BEEN SET.  */
    twdlgdraw(wf);
    return 0;
  }

  /* -- The key to using scaled text is by setting the usercharsize  */
  /* -- with the ratio of the working area to the screen size  */


unsigned worldtextredraw(imagestkptr  ifs, msclickptr	ms)
  { winframeptr  wf;

    wf = findwinframe(ifs);
    twselect(wf);
    twwdefineworld(wf,0,0,1000,1000);
    prepareforupdate(ifs);
    setcolor(BLACK);
    settextjustify(LEFT_TEXT,TOP_TEXT);
    settextstyle(TECHNA_FONT,HORIZ_DIR,3);
    setusercharsize(wf->wx2 - wf->wx1,getmaxx() / 2,wf->wy2 - wf->wy1,getmaxy() / 2);
    twwouttextxy(wf,10,10,"Scaled text");
    settextstyle(TALL_FONT,HORIZ_DIR,5);
    setusercharsize(wf->wx2 - wf->wx1,getmaxx() / 2,wf->wy2 - wf->wy1,getmaxy() / 2);
    twwouttextxy(wf,10,500,"Using Techna & Tall Font");
    commitupdate();
    return 0;
  }


unsigned openworldtextdemo(imagestkptr	ifs, msclickptr   ms)
  { winframeptr  wf;

    twinit(&wf,100,100,300,250);
      twsetheader(wf,"Scaling text");
      twsetredraw(wf,worldtextredraw);
    twdrawwindowframe(wf);
    return 0;
  }


  /* --------------------------------------------------------- */
  /* -- Bar graph demo illustrates how to use the world coordinates  */
  /* -- to fit data into any sized window.  */
  /* --------------------------------------------------------- */

#define maxbars 10
typedef struct bardef { int   x1, y1, x2, y2, color; } bardef;
bardef	     bars[maxbars]

  = {{-99,80,-81,0,BLUE},
    {-80,70,-61,0,BLUE},
    {-60,20,-41,0,BLUE},
    {-40,0,-21,-40,RED},
    {-20,0,-1,-99,RED},
    {1,0,20,-67,RED},
    {21,8,40,0,GREEN},
    {41,20,60,0,YELLOW},
    {61,75,80,0,MAGENTA},
    {81,50,99,0,BLUE}};





unsigned worldbarredraw(imagestkptr ifs, msclickptr ms)
  { winframeptr  wf;
      int      i;

    wf = findwinframe(ifs);
    twwdefineworld(wf,-100,100,100,-100);
    twwline(wf,-100,0,100,0);
    for (i = 1; i <= maxbars; i++)
      { bardef *     with1 = &bars[i-1];

	  setfillstyle(SOLID_FILL,with1->color);
	  twwbar(wf,with1->x1,with1->y1,with1->x2,with1->y2);
	  setcolor(BLACK);
	  twwrectangle(wf,with1->x1,with1->y1,with1->x2,with1->y2);

	   }

    setcolor(BLACK);
    return 0;
  }


unsigned worldsinredraw(imagestkptr  ifs, msclickptr   ms)
  { winframeptr  wf;
    float	  t;

    float	  counter	= 0.05;
    float	  range 	= 8.0;

    wf = findwinframe(ifs);
    twwdefineworld(wf,-(range * 1.2),(range * 1.2),(range * 1.2),-(range * 1.2));
    twwline(wf,-range,0.0,range,0.0);
    twwline(wf,0,-range,0.0,range);
    twwline(wf,-range,range,-range,-range);
    twwline(wf,-range,-range,range,-range);
    setcolor(RED);
    t = -range;
    while (t <= range)
      {
	  /*  twwputpixel(wf,t,range * sin(t),red);  */

	twwline(wf,t,range * sin(t),t + counter,range * sin(t + counter));
	t = t + counter;
      }

    setcolor(BLACK);
    return 0;
  }


unsigned openworldbardemo(imagestkptr  ifs, msclickptr	 ms)
  { winframeptr  wf;

    twinit(&wf,100,100,400,400);
      twsetthickness(wf,4);
      twsetwinframecolors(wf,LIGHTGRAY,DARKGRAY);
      twsetheader(wf,"Bar Graph (-100,100,100,-100)");
      twsetredraw(wf,worldbarredraw);
      twsetwindowstyle(wf,stdbox);
      twsetfillcolor(wf, 0x0b0f);
    twdrawwindowframe(wf);
    return 0;
  }



unsigned openworldsindemo(imagestkptr  ifs, msclickptr	 ms)
  { winframeptr  wf;

    twinit(&wf,200,200,400,400);
      twsetthickness(wf,4);
      twsetwinframecolors(wf,LIGHTBLUE,BLUE);
      twsetheader(wf,"Sine Wave");
      twsetredraw(wf,worldsinredraw);
      twsetwindowstyle(wf,bevbox);
      twsetfillcolor(wf,0x010f);
    twdrawwindowframe(wf);
    return 0;
  }


#ifdef WCFLOATLINT

unsigned worldredraw(imagestkptr  ifs, msclickptr   ms)
  { winframeptr  wf;

    twwdefineworld(wf,-10000,10000,10000,-10000);
    twwline(wf,-10000,10000,10000,-10000);
    twwline(wf,10000,10000,-10000,-10000);
    twwrectangle(wf,-5000,-5000,5000,5000);

    setfillstyle(SOLID_FILL,BLUE);
    twwbar(wf,-9000,9000,-5000,5000);
    twwarc(wf,0,0,180,360,5000);
    twwellipse(wf,0,0,180,360,6000,6000);
    setcolor(RED);
    twwcircle(wf,0,0,6000);
  }


#else


unsigned worldredraw(imagestkptr  ifs, msclickptr   ms)
  { winframeptr  wf;

      /* -- the redrawing event should alway find the window then  */
      /* -- select it. Selecting does a fix up in case the window has  */
      /* -- been move and sets the view port to the working area of the  */
      /* -- window.  */
    wf = findwinframe(ifs);
    twselect(wf);
      /* -- twwDefineWorld sets the coordinate system, this must be set  */
      /* -- after the window has been drawn (i.e. not before twDrawWindowFrame	*/
    twwdefineworld(wf,-10.0,10.0,10.0,-10.0);
      /* -- the world coordinate call all mimic the standard graphics calls  */
      /* -- execpt they start with tww, have a winframeptr as the first parameter */
      /* -- and the arguments are real. Graphics functions that do not have   */
      /* -- coordinates have no equivalent. Just use the normal graphics call.	*/
    setcolor(BLACK);
    twwline(wf,-10.0,10.0,10.0,-10.0);
    twwline(wf,10.0,10.0,-10.0,-10.0);
    twwrectangle(wf,-5,-5,5,5);
    setfillstyle(SOLID_FILL,BLUE);
    twwbar(wf,-9,9,-5,5);
      /* -- arcs may not work the way you expect, ellipse is better  */
    setcolor(RED);
    twwarc(wf,0,0,360,180,5.0);
    twwellipse(wf,0,0,180,360,4.0,4.0);
    setfillstyle(SOLID_FILL,RED);
    twwfillellipse(wf,0,0,3.0,3.0);

      /* -- here we draw an ellipse then a circle with the same center point  */
      /* -- and radius, as you resize the window you can see the effect on the	*/
      /* -- aspect ratio.  */
    twwellipse(wf,0,0,1,360,6.0,6.0);
    setcolor(RED);
    twwcircle(wf,0,0,6.0);
    return 0;
  }

#endif


unsigned openworlddemo(imagestkptr  ifs, msclickptr   ms)
{ winframeptr  wf;


    /* --------- */
  twinit(&wf,100,100,400,300);
    twsetthickness(wf,6);
    twsetwinframecolors(wf,LIGHTGRAY,DARKGRAY);
    twsetheader(wf,"World coordinates");
    twsetredraw(wf,worldredraw);
    twsetwindowstyle(wf,stdbox);
  twdrawwindowframe(wf);
  return 0;
}

  /* --------------------------------------------------------- */
  /* -- Local menus in high level windows.  */
  /* -- This just draws the menus, no events are attached.  */


unsigned openmenudemo(imagestkptr  ifs, msclickptr   ms)
  { winframeptr  wf;

    twinit(&wf,50,50,250,250);
    twsetdisplayfont(wf,(fontptr)f8x8bold);
    twsetheader(wf,"LOCAL MENU Demo");
      /* -- note that certain letters are surrounded by tildes, these  */
      /* -- will be underlined when display and the appropriate key will  */
      /* -- be captured.  */
    twmenuitem(wf," ~F~ile",TRUE);
      twsubmenuitem(wf,"~O~pen",TRUE,nilunitproc);
      twsubmenuitem(wf,"~S~ave",TRUE,nilunitproc);
      twsubmenuitem(wf,"Save ~a~s...",TRUE,nilunitproc);
      twsubmenuitem(wf,"-",FALSE,nilunitproc);

      twsubmenuitem(wf,"E~x~it",TRUE,twmenucloseevent);
    twmenuitem(wf," ~E~dit ",TRUE);
      twsubmenuitem(wf,"~U~ndo",TRUE,nilunitproc);
      twsubmenuitem(wf,"~S~elect",TRUE,nilunitproc);
    twmenuitem(wf," ~W~indow",TRUE);
      twsubmenuitem(wf,"~T~ile",TRUE,nilunitproc);
      twsubmenuitem(wf,"~S~elect",TRUE,nilunitproc);
    twmenuitem(wf," ~H~elp",TRUE);
      twsubmenuitem(wf,"~C~ontents",TRUE,nilunitproc);
      twsubmenuitem(wf,"~I~ndex",TRUE,nilunitproc);
    twsetfillcolor(wf,0x0103);
    twdrawwindowframe(wf);
  return 0;
  }


  /* --------------------------------------------------------- */
  /* -- Slider action in high level windows. The Window Frame  */
  /* -- maintains variables that are updated after a slider is */
  /* -- moved or a slider end button is pressed. This is	   */
  /* -- looked after by some events in TWKERNEL. The user must */
  /* -- still create an event for each slider that will then   */
  /* -- interrogate these variables and take the appropriate   */
  /* -- action.  */



  /* -- this is the up down slider event that is called by the	*/
  /* -- kernel after the slider is moved.  */


unsigned showupdownaction(imagestkptr  ifs, msclickptr	 ms)
  { winframeptr  wf;

    wf = findwinframe(ifs);
    prepareforupdate(ifs);
    twcrtassign(wf);
    twclear(wf);
    twgotoxy(wf,1,2);
    twprintf(" Up Down Action\n");
    twgotoxy(wf,1,3);
    twprintf(" Slider percent: %i\n",wf->updnslideper);
    twgotoxy(wf,1,4);
    twprintf(" button up     : %i\n",wf->upbuttonpress);
    twgotoxy(wf,1,5);
    twprintf(" button down   : %i\n",wf->dnbuttonpress);
    twgotoxy(wf,1,6);
    twprintf(" Slider Range  : %i\n",wf->updownrange);
    commitupdate();
    return 0;
  }

  /* -- this is the left right slider event that is called by the  */
  /* -- kernel after the slider is moved or the  */


unsigned showleftrightaction(imagestkptr  ifs, msclickptr   ms)
  { winframeptr  wf;

    wf = findwinframe(ifs);
    prepareforupdate(ifs);
    twcrtassign(wf);
    twclear(wf);
    twgotoxy(wf,1,2);
    twprintf(" Left Right Action\n");
    twgotoxy(wf,1,3);
    twprintf(" Slider percent: %i\n",wf->lfrtslideper);
    twgotoxy(wf,1,4);
    twprintf(" button left   : %i\n",wf->lfbuttonpress);
    twgotoxy(wf,1,5);
    twprintf(" button right  : %i\n",wf->rtbuttonpress);
    twgotoxy(wf,1,6);
    twprintf(" Slider Range  : %i\n",wf->leftrightrange);
    commitupdate();
    return 0;
  }

  /* -- this event is called from a menu selection or a mouse click.  */
  /* -- It ignores the parameters and simply opens up a demo window  */
  /* -- for sliders. The WinFramePtr can be a local variable because  */
  /* -- it can be located in events that are attached to it (sliders  */
  /* -- here) by using findwinframe and the passed imagestkptr.  */


unsigned opensliderdemo(imagestkptr  ifs, msclickptr   ms)
  { winframeptr  wf;

    twinit(&wf,100,100,450,300);   /* -- allocates memory and set size	*/
      twsetupdownrange(wf,2000,100);
      twsetleftrightrange(wf,2000,100);
      twsetfont(wf,(fontptr)font14);	 /* -- the font to use	*/
      twsetheader(wf,"A slider action example.");   /* -- header on  */
      twsetupdownslider(wf,TRUE);   /* -- up down slider on  */
      twsetleftrightslider(wf,TRUE);   /* -- left right slider on  */
      twsetupdownevent(wf,showupdownaction);   /* -- attach above event  */
      twsetleftrightevent(wf,showleftrightaction);   /* -- ditto	*/
      twsetfillcolor(wf,0x0302);
    twdrawwindowframe(wf);   /* -- finally draw it.  */
    return 0;
  }


  /* -- this is the start up code for the system. A sample only. Your  */
  /* -- application should do its own start up.  */


void	     startup(void)
  {
      /* -- link in the video drivers. Only link in the necessary ones!  */
      /* -- each driver adds about 6-7K of code size.  */
      /* -- Optionally no drivers can be linked in an the appropriate one  */
      /* -- will be loaded from the disk drive onto the heap. The driver  */
      /* -- must be in the path.  */
      fglinktgi();   /* links in CGA, HERC and 16 color EGA/VGA/SVGA */
/*    fglinksvga(); */	/* links in 256 color driver */

      /* -- Some standard heap is used for a scan buffer (8K default).	*/
      /* -- You can set this to a lower value if you don't do a lot of  */
      /* -- poly fills. NOTE! Flood fill uses the stack, if you use flood fill	*/
      /* -- be sure there is adequate stack space.  */

    allocatescanbuffer(2048);

    /* starting with release 3.0 windows can be unbuffered */
    twsetglobalbuffers(FALSE);

    /* restrict the windows from moving over the bar menu */
    /* bar menus are only buffered for now. */
    if (! twbuffered)
      twsetglobalrestrictions(0,17,1000,1000);

     /* virtual heap is used to look after graphics buffers */
     /* if you use unbuffered windows then you can set this to a */
     /* low value like here. If you use buffered windows then */
     /* set it to a higher value. */
     /* If ems or umb's are available then the virtual heap (page area) */
     /* won't even reside in normal memory! */
     /* Default virtual heap is 96K. If we are not buffering the */
     /* the windows then we reduce it here to 48K (which will fit it the */
     /* EMS page frame. */
     if (!twbuffered)
       setvirtualheapsize(48000L);
     /* set virtual memory resources */
     usedskvirt(TRUE);	/* DISK default TRUE */
     useemsvirt(TRUE);	/* EMS default TRUE */
     usexmsvirt(TRUE);	/* XMS default TRUE */
     /* upper memory is utilized for the virtual heap/page area if */
     /* it is available. */
     vmuseumb(TRUE);	/* default TRUE add upper memory to heap */
     vmuseems(TRUE);	/* default TRUE  add ems page frame (3/4 of it) to heap */



      /* -- VideoAutoDetect returns a string that has the highest detectable  */
      /* -- resolution for the graphics hardware. SUPER VGA is NEVER enabled.  */
      /* -- This will return at most VGA 640 x 480 x 16 colors. Other modes  */
      /* -- must be set explicitly.  */

      /* -- TeglInit does all sorts of stuff, saves the interrupt vectors  */
      /* -- sets important exit routines. The second parameter to TEGLInit  */
      /* -- is no longer used. It is just there for compatability with	*/
      /* -- previous versions.	*/

    teglinit(videoautodetect(),12000);	 /* -- initialize graphics system  */
/*  teglinit("SVGA640x480x256",12000);*/ /* -- initialize graphics system  */
    twcommoninit();			 /* for tw & to windows */
    twclearscreen();
    eraseframe = twerasearea;		 /* if non buffered windows */
    emergencyexit();			 /* -- provide abort mechanism	*/
    setalttabrotate(TRUE);		 /* rotate windows with keyboard */
    /* check to see if a mouse driver is installed, if not then */
    /* disable the mouse cursor. */
    if (!mouse_installed) showmousecursor = FALSE;

  }

/* this variable sets the overlay buffer size */
/* for TURBO/BORLAND compilers */
/* unsigned _ovrbuffer = 0x1000; */

void main(void)
{

  /* an overlaid application */
  /* if (_OvrInitExt(0L,0L)) {}; */


  /* -- do startup, see function above */
  startup();

  TECHNA_FONT = installuserfont("TECHNA.CHR");
  TALL_FONT   = installuserfont("TALL.CHR");
  sethidesubmenu(TRUE);

   /* -- set the font to use in window headers, TWCOMMON  */
  twsetheaderfont((fontptr)font14);
  twsetglobalcolors(BLACK,
		    LIGHTGRAY, DARKGRAY,
		    0x0103,WHITE,
		    LIGHTGRAY,WHITE,
		    WHITE,BLACK,
		    WHITE);
  if (getmaxcolor() > 2) setmenuselectorcolor(RED);
  twmenusense = MSSENSE;     /* bar menu on tw windows */
  menufont = (fontptr)font14;	/* -- set the font to use on the menu  */


  fileom = createoptionmenu(menufont);
    defineoptions(fileom," Dos [~S~]hell ",TRUE,dosshell);
    defineoptions(fileom,"-",FALSE,nilunitproc);
    defineoptions(fileom," E[~x~]it ",TRUE,twexitoption);
  devicesom = createoptionmenu(menufont);
    defineoptions(devicesom,"[~M~]enus",TRUE,openmenudemo);
    defineoptions(devicesom,"[~S~]liders",TRUE,opensliderdemo);

  dialogom = createoptionmenu(menufont);
    defineoptions(dialogom,"[~S~]imple",TRUE,opendialogdemo);
  worldom = createoptionmenu(menufont);
    defineoptions(worldom,"[~S~]ample",TRUE,openworlddemo);
    defineoptions(worldom,"[~B~]ar Graph ",TRUE,openworldbardemo);
    defineoptions(worldom,"S[~i~]ne wave",TRUE,openworldsindemo);
    defineoptions(worldom,"[~T~]ext (scaled)",TRUE,openworldtextdemo);

    /* -- we create the bar menu last an attach all the option menus to  */
    /* -- it, this is the only order that will work.  */

  setteglfont(menufont);   /* -- bar menu uses the current font  */
  createbarmenu(0,0,getmaxx());
  setframeautorotate(stackptr,FALSE);
  setframemobility(stackptr,!twnobuffers);
  mainmenu = stackptr;	 /* -- just another frame  */
    outbaroption(" [~F~]ile ",fileom);
    outbaroption(" [~D~]evices ",devicesom);
    outbaroption(" Dia[~l~]ogues ",dialogom);
    outbaroption(" [~W~]orld ",worldom);
    outbarevent(" [~M~]emMonitor ",memorymonitor);

  setautorotate(TRUE);	 /* -- windows rotate to the top automatically	*/
  teglsupervisor();   /* -- do not adjust your set, the supervisor  */
				/* -- is in control!  */
}
