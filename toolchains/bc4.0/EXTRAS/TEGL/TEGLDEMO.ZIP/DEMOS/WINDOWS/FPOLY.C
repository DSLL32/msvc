/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
#include "teglsys.h"
#include "dos.h"

extern	unsigned _stklen=10000;

  optionmptr   fileom;


unsigned fillpolyredraw(imagestkptr  ifs, msclickptr   ms)
{    int _TGSHORT_ poly[14];

     poly[0] = -286;
     poly[1] = 478;
     poly[2] = -475;
     poly[3] = 370;
     poly[4]= -425;
     poly[5]= 1193;
     poly[6]= -72;
     poly[7]= 1357;
     poly[8]= 224;
     poly[9]= 144;
     poly[10]= 140;
     poly[11]= 338;
     poly[12]= -48;
     poly[13]= 466;

     setcolor(BLUE);
     setfillstyle(1, RED);
     fillpoly(7, poly);

     return 0;
}

unsigned openfillpolydemo(imagestkptr  ifs, msclickptr	 ms)
{ winframeptr  wf;


    /* --------- */
  twinit(&wf,100,100,400,300);
    twsetthickness(wf,6);
    twsetwinframecolors(wf,LIGHTGRAY,DARKGRAY);
    twsetheader(wf,"FillPoly Test");
    twsetredraw(wf,fillpolyredraw);
    twsetwindowstyle(wf,stdbox);
  twdrawwindowframe(wf);
  return 0;
}

  /* -- this is the start up code for the system. A sample only. Your  */
  /* -- application should do its own start up.  */

void	     startup(void)
  {
/*  registertgidriver((void (*)(void))GREVGA16_driver);
    registertgidriver((void (*)(void))GRCGABW_driver);
    registertgidriver((void (*)(void))GRHERCBW_driver); */
    registertgidriver((void (*)(void))GRVGA256_driver);

    setstandardheapsize(16000);
    allocatescanbuffer(12000);
    initteglheap();
/*  maxwindowsize = cmaxavail() / 3; */
    maxwindowsize = 0x8000;

/*  teglinit(videoautodetect(),12000); */ /* -- initialize graphics system  */
/*  teglinit("SVGA800x600x256",12000); *//* -- initialize graphics system  */
  teglinit("SVGA640x480x256",12000);   /* -- initialize graphics system  */
    twcommoninit();	 /* for tw & to windows */
    clearteglscreen();	 /* -- clear screen  */
    emergencyexit();   /* -- provide abort mechanism  */
  }

void main(void)
{

  startup();

  twsetheaderfont((fontptr)f8x12bol);

  fileom = createoptionmenu((fontptr)f8x12bol);
    defineoptions(fileom," ~F~illpoly ",TRUE,openfillpolydemo);
    defineoptions(fileom,"-",FALSE,nilunitproc);
    defineoptions(fileom," E~x~it ",TRUE,twexitoption);

  setteglfont((fontptr)f8x12bol);  /* -- bar menu uses the current font  */
  createbarmenu(0,0,getmaxx());
    outbaroption(" ~F~ile ",fileom);

  teglsupervisor();
}
