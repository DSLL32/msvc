/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
  /* -- a simple window with a world coordinate system, the items are  */
  /* -- redraw and fitted to the window when it is resized.  */

#include "teglsys.h"

#ifdef WCFLOATLINT

unsigned  worldredraw(imagestkptr  ifs, msclickptr   ms)
  { winframeptr  wf;

    wf = findwinframe(ifs);
    twwdefineworld(wf,-10000,10000,10000,-10000);
    twwline(wf,-10000,-10000,10000,10000);
    twwrectangle(wf,-5000,-5000,5000,5000);
    setfillstyle(SOLID_FILL,BLUE);
    twwbar(wf,-9000,9000,-5000,5000);
    twwarc(wf,0,0,180,360,5000);
    twwellipse(wf,0,0,180,360,4000,4000);
    twwcircle(wf,0,0,6000);
    return 0;
  }


#else


unsigned  worldredraw(imagestkptr  ifs, msclickptr   ms)
  { winframeptr  wf;

    wf = findwinframe(ifs);
    twwdefineworld(wf,-10.0,10.0,10.0,-10.0);
    twwline(wf,-10.0,-10.0,10.0,10.0);
    twwrectangle(wf,-5,-5,5,5);
    setfillstyle(SOLID_FILL,BLUE);
    twwbar(wf,-9,9,-5,5);
    twwarc(wf,0,0,360,180,5.0);
    twwellipse(wf,0,0,180,360,4.0,4.0);
    twwcircle(wf,0,0,6.0);
    return 0;
  }

#endif

winframeptr  wf;


void main(int argc, char **argv)
{


  tweasystart();

  setautorotate(TRUE);
  setteglfont((fontptr)font14);
    /* --------- */
  twinit(&wf,100,100,400,300);
  twsetthickness(wf,6);
  twsetwinframecolors(wf,LIGHTGRAY,DARKGRAY);
  twsetheader(wf,"World Window");
  twsetredraw(wf,worldredraw);
  twdrawwindowframe(wf);

  setautorotate(TRUE);
  teglsupervisor();
}



