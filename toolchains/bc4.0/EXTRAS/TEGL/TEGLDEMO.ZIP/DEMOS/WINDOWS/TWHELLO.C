/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
  /* -- simplest program using high level windows  */

#include "teglsys.h"

   winframeptr	wf;

void main(void)
{

  tweasystart();   /* -- simple startup  */

  twinit(&wf,100,100,400,250);	 /* -- creates & initializes  */
  twsetheader(wf,"Hello World");   /* -- set up individual items  */
  twdrawwindowframe(wf);   /* -- draw it the first time  */

  teglsupervisor();
}
