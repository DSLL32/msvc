  /*  ex_256.c	*/

  /* -- illustrates how to switch into one of the 256 color modes  */
  /* -- supported using InitGraph. 256 color modes are never enabled  */
  /* -- with auto detection.  */

#include "tgraph.h"
#include "fastgrph.h"
#include <stdlib.h>
#include <conio.h>

  /* -- these constants are passed to adddriverbgimodes - then initgraph  */
  /* -- will respond to them.  */


  #define SVGA256DRIVER   11
  #define SVGA16DRIVER	  12

  #define SVGA256_320x200    0
  #define SVGA256_640x480    1
  #define SVGA256_800x600    2
  #define SVGA256_1024x768   3

  #define SVGA16_800x600     0


  int	   gd, gm;
  int	   i, limit;

void main(void)
{


    /* -- the linktgi unit only links in the standard (for detectable modes)  */
    /* -- drivers. This line links in the 256 color driver to the exe file.  */
    /* -- This isn't necessary if the TGI driver is in the path.  */

  registertgidriver((void (*) (void))GRVGA256_driver);	 /* -- link in 256 driver  */
  registertgidriver((void (*) (void))GREVGA16_driver);	 /* -- link in 16 color driver too */

    /* -- adddriverfilename relates the driver to the modes it supports  */
  adddriverfilename("GRVGA256.TGI","VGA320x200x256");
  adddriverfilename("GRVGA256.TGI","SVGA640x480x256");
  adddriverfilename("GRVGA256.TGI","SVGA800x600x256");
  adddriverfilename("GRVGA256.TGI","SVGA1024x768x256");
  adddriverfilename("GREVGA16.TGI","SVGA800x600x16");

    /* -- adddriverbgimodes relates the modes to the driver number and	*/
    /* -- mode number  */
  adddriverbgimodes("VGA320x200x256",SVGA256DRIVER,SVGA256_320x200);
  adddriverbgimodes("SVGA640x480x256",SVGA256DRIVER,SVGA256_640x480);
  adddriverbgimodes("SVGA800x600x256",SVGA256DRIVER,SVGA256_800x600);
  adddriverbgimodes("SVGA1024x768x256",SVGA256DRIVER,SVGA256_1024x768);
  adddriverbgimodes("SVGA800x600x16",SVGA16DRIVER,SVGA16_800x600);


    /* -- change gd and gm to select different modes  */

  gd = SVGA256DRIVER;
  gm = SVGA256_320x200;

  initgraph(&gd,&gm,"");
  if (graphresult() != grok) exit(1);

  if (getmaxx() < 255) limit = getmaxx();
  else limit = 255;
  for (i = 0; i <= limit; i++)
    {
      setcolor(i);
      line(0,i,getmaxx(),i);
    }
  setfillstyle(SOLID_FILL,WHITE);
  bar(5,5,100,20);
  setcolor(BLACK);
  outtextxy(10,10,"256 colors");
  getch();
  closegraph();
}



