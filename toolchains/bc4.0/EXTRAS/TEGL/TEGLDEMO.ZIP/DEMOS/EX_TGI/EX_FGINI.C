  /*  ex_fgini.c  */
  /*  example for minimal graphics startup  */

#include <stdlib.h>
#include <conio.h>
#include "teglcond.h"
#include "fastgrph.h"
#include "fgmisc.h"

#define WHITE 15

void main(int argc, char **argv)
{

  fglinkevga();
  if (!fginit()) return;

  fastbar(0,0,fgmaxx(),fgmaxy(),WHITE);
  getch();
  fgclose();

}



