  /*  ex_settr.c  */

  /*  example for settransparency  */
  /*  if the characters do not appear in inverse on the  */
  /*  screen then transparency is not supported for the  */
  /*  selected driver.  */

#include <stdlib.h>
#include <conio.h>
#include "teglcond.h"
#include "fastgrph.h"
#include "fgmisc.h"


void main(int argc, char **argv)
{
   /**/


  fglinktgi();
  if (!fginit()) return;
  settransparency(FALSE);
  outtgtextxy(10,100,0,fggetmaxcolor(),"This is a transparency test.");
  getch();

  fgclose();
}



