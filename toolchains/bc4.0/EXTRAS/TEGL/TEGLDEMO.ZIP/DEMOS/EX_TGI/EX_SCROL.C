  /*  ex_scrol.c  */
  /*  example for fastscroll up,down,left,right  */

#include <stdlib.h>
#include <conio.h>
#include "fastgrph.h"
#include "iconsys.h"
#include "fgmisc.h"

int i, x1, y1, x2, y2;
    unsigned pw, ph;

void main(void)
{
  fglinktgi();
  if (!fginit()) return;
    /*  use the centre of the screen  */
  x1 = fgmaxx() / 4;
  y1 = fgmaxy() / 4;
  x2 = x1 * 3;
  y2 = y1 * 3;
  fastbar(0,0,fgmaxx(),fgmaxy(),fggetmaxcolor());
  fastrect(x1 - 1,y1 - 1,x2 + 1,y2 + 1,0);
  pictsize(&pw,&ph,imageSYSTEM);
  putpict(fgmaxx() / 2 - pw / 2,fgmaxy() / 2 - ph / 2,imageSYSTEM,0);
  for (i = 1; i <= 30; i++)
    {
      fastscrollup(x1,y1,x2,y2,i);
      fastscrollleft(x1,y1,x2,y2,i);
      fastscrolldown(x1,y1,x2,y2,i);
      fastscrollright(x1,y1,x2,y2,i);
    }
  for (i = 1; i <= 30; i++)
    fastscrollup(x1,y1,x2,y2,1);
  for (i = 1; i <= 30; i++)
    fastscrollright(x1,y1,x2,y2,2);
  for (i = 1; i <= 60; i++)
    fastscrolldown(x1,y1,x2,y2,1);
  for (i = 1; i <= 60; i++)
    fastscrollleft(x1,y1,x2,y2,2);
  for (i = 1; i <= x2 - x1; i++)
    fastscrollup(x1,y1,x2,y2,1);

  fgclose();
}



