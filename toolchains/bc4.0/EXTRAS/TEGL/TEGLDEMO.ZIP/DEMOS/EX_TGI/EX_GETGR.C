  /*  ex_getgr.c  */
  /*  Example for GetGraphMode  */

#include <stdlib.h>
#include <conio.h>
#include <stdio.h>
#include "teglcond.h"
#include "fgmisc.h"
#include "tgraph.h"


  int gd, gm;
  int mode;

void main(void)
{
  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);
  outtext("<Enter> to leave graphics:");
  getch();
  restorecrtmode();
  printf("Now in text mode\n");
  printf("<Enter> to enter graphics mode:");
  getch();
  setgraphmode(getgraphmode());
  outtextxy(0,0,"Back in graphics mode");
  outtextxy(0,textheight("H"),"<Enter> to quit:");
  getch();
  closegraph(); 
}



