  /*  ex_txwid.pas  */
  /*  Example for textwidth and textheight  */


#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "teglcond.h"
#include "fastgrph.h"
#include "fgmisc.h"
#include "tgraph.h"

  int gd, gm;
  int row, size, technafont;
  char title[40];

void main(int argc, char **argv)
{
  technafont = installuserfont("Techna.chr");
  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);
  row = 0;
  strcpy(title,"TEGL Graphics Interface");
  size = 1;
  while (textwidth(title) < getmaxx())
  {
    outtextxy(0,row,title);
    row += textheight("M");
    ++size;
    settextstyle(technafont,HORIZ_DIR,size);
  }
  getch();
  closegraph();
}



