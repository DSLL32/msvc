  /*  ex_getmc.c  */
  /* -- example for getmaxcolor  */

#include <stdlib.h>
#include <conio.h>
#include "teglcond.h"
#include "fgmisc.h"
#include "tgraph.h"

  int gd, gm;
  int i, fac;


void main(void)
{
  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);

  for (i = 0; i <= getmaxcolor(); i++)
    {
      fac = getmaxy() / (getmaxcolor() + 1);
      setfillstyle(SOLID_FILL,i);
      bar(0,i * fac,getmaxx(),i * fac + fac);
    }


  getch();
  closegraph(); 
}



