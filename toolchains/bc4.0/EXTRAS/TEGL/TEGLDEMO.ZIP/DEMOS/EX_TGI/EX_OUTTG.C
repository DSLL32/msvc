
/*  ex_outtg.c  */
/*  example for outtgtextxy  */

#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "fastgrph.h"
#include "fgmisc.h"


extern unsigned char underlinecharstatus;

char s[80];
    int i;

void main(int argc, char **argv)
{
  strcpy(s,"This is a string.");
  fglinktgi();
  if (!fginit()) return;

  /* underline flag */
  /* underlinecharstatus = FALSE; */
  fastbar(0,0,fgmaxx(),fgmaxy(),fggetmaxcolor());
  i = 10;
  do {
    outtgtextxy(10,i,0,fggetmaxcolor(),s);
    i = (int) (i + teglcharheight());
  }  while (!(i >= fgmaxy() - 5));


  getch();
  fgclose();
}



