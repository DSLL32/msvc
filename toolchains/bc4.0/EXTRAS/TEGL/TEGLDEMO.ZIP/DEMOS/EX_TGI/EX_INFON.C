  /*  ex_infon.c  */
  /*   example for installuserfont  */


#include <stdlib.h>
#include <conio.h>
#include <stdio.h>
#include <string.h>
#include "teglcond.h"
#include "fastgrph.h"
#include "fgmisc.h"
#include "tgraph.h"

  int gd, gm;
  int radius;
  int finefont, tallfont, technafont;


void showfont(int font, char * fname)
  { int i, y;
    char s[40];

    setfillstyle(SOLID_FILL,WHITE);
    bar(0,0,1000,1000);
    y = 0;
    for (i = 1; i <= 10; i++)
      {
        settextstyle(font,HORIZ_DIR,i);
        setcolor(BLACK);
        y = (y + textheight("H"));
        outtextxy(10,y,strcat(strcpy(s,"This is the "),fname));
      }
    getch();
  }



void main(void)
{

  finefont = installuserfont("fine.chr");
  tallfont = installuserfont("tall.chr");
  technafont = installuserfont("techna.chr");
  if ((finefont < 0) || (tallfont < 0) || (technafont < 0))
    {
      printf("Font file missing.\n");
      exit(1);
    }
  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);
  setfillstyle(SOLID_FILL,LIGHTGRAY);
  bar(0,0,getmaxx(),getmaxy());
  setviewport(100,40,540,getmaxy() - 40,1);
  showfont(finefont,"Fine Font");
  showfont(tallfont,"Tall Font");
  showfont(technafont,"Techna Font");
  closegraph();
}



