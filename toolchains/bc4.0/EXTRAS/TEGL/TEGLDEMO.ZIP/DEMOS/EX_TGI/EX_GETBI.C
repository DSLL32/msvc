  /*  ex_getbi	*/
  /*  example for getbiti, putbiti  */

#include <stdlib.h>
#include <conio.h>
#include "fastgrph.h"
#include "iconsys.h"
#include "fgmisc.h"

unsigned long isize;
void * ibuf;
int i;

void main(void)
{
  fglinktgi();
  if (!fginit()) return;
  fastbar(0,0,fgmaxx(),fgmaxy(),fggetmaxcolor());
  putpict(0,0,imageSYSTEM,0);
  isize = bigimagesize(0,0,95,75);
  ibuf = malloc((unsigned)isize);
  if (ibuf == NULL) return;
  getbiti(0,0,95,75,ibuf);
  i = 10;
  while (i < (fgmaxy() - 80))
    {
      putbiti(i,i,ibuf,FGNORM);
      i = i + 10;
    }
  getch();
  fgclose();

}



