  /*  ex_rect.c  */

#include <stdlib.h>
#include <conio.h>
#include "fgmisc.h"
#include "tgraph.h"


  int gd, gm;
  int i, x1, y1, x2, y2;

void main(int argc, char **argv)
{
  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);
  i = 0;
  while (i < 50)
    {
      rectangle(i + 10,i + 10,i + 100,i + 100);
      i = i + 5;
    }

  getch();
  closegraph();
}



