 /*  ex_settx.c  */
 /*  example for settextjustify  */

#include <stdlib.h>
#include <conio.h>
#include "fgmisc.h"
#include "tgraph.h"

int gd, gm, cx, cy;


void drawaxis(void)
  {
    setfillstyle(SOLID_FILL,WHITE);
    bar(0,0,getmaxx(),getmaxy());
    setcolor(BLACK);
    line(cx,0,cx,getmaxy());
    line(0,cy,getmaxx(),cy);
  }



void main(void)
{
  fglinktgi();
  gd = DETECT;
  initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);
  cx = getmaxx() / 2;
  cy = getmaxy() / 2;

  drawaxis();
  settextjustify(LEFT_TEXT,TOP_TEXT);
  moveto(cx,cy);
  outtext("LEFT_TEXT - TOP_TEXT");
  getch();

  drawaxis();
  settextjustify(CENTER_TEXT,TOP_TEXT);
  moveto(cx,cy);
  outtext("CENTER_TEXT - TOP_TEXT");
  getch();

  drawaxis();
  settextjustify(CENTER_TEXT,BOTTOM_TEXT);
  moveto(cx,cy);
  outtext("CENTER_TEXT - BOTTOM_TEXT");
  getch();

  drawaxis();
  settextjustify(RIGHT_TEXT,BOTTOM_TEXT);
  moveto(cx,cy);
  outtext("RIGHT_TEXT - BOTTOM_TEXT");


  getch();
  closegraph(); 
}



