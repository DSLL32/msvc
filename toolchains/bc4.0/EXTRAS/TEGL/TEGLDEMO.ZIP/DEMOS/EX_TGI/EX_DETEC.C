  /*  ex_detec.c */
  /*  example for detectgraph  */

#include <stdlib.h>
#include <conio.h>
#include <stdio.h>
#include "tgraph.h"

int gd, gm, err;


void main(void)
{
  detectgraph(&gd,&gm);
  printf("graph driver: %d\n",gd);
  printf("graph mode:   %d\n",gm);
  printf("graph result: %s\n",grapherrormsg(graphresult()));
  getch();
}



