  /*  -- ex_fpoly.pas  */

  /* -- example for fill polygon  */
  /* -- fill poly uses the scan buffer. If you  */
  /* -- have complicated fills see allocatescanbuffer  */

#include <stdlib.h>
#include <conio.h>
#include "teglcond.h"
#include "fgmisc.h"
#include "tgraph.h"

  int _TGSHORT_ polygon[8]
       = {100,100,200,200,100,200,100,100};

  int _TGSHORT_ polygon2[8]
       = {70,50,300,300,70,300,70,50};

  int gd, gm;


void main(void)
{
  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);

  setcolor(WHITE);
  setfillstyle(SOLID_FILL,LIGHTGRAY);
  fillpoly(sizeof(polygon2) / 4,polygon2);
  setfillstyle(SOLID_FILL,BLUE);
  fillpoly(sizeof(polygon) / 4,polygon);


  getch();
  closegraph(); 
}



