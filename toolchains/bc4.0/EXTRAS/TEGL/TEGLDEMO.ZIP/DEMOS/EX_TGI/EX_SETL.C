  /*  ex_setl.c  */
  /*  Example for setlinestyle  */

#include <stdlib.h>
#include <conio.h>
#include "fgmisc.h"
#include "tgraph.h"


  int gd, gm;
  int x1, y1, x2, y2;

void main(int argc, char **argv)
{
   /**/


  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);
  x1 = 20;
  y1 = 20;
  x2 = getmaxx() - 20;
  y2 = getmaxy() - 20;
  setlinestyle(DOTTED_LINE,0,NORM_WIDTH);
  rectangle(x1,y1,x2,y2);
  setlinestyle(USERBIT_LINE,0xC3,THICK_WIDTH);
  rectangle(x1 - 5,y1 - 5,x2 + 5,y2 + 5);

  getch();
  closegraph();
}



