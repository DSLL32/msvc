  /*  ex_setft.c  */

  /*  example for setteglfont, getteglfont */


#include <stdlib.h>
#include <conio.h>
#include "teglcond.h"
#include "fontsys.h"
#include "fastgrph.h"
#include "fgmisc.h"

fontptr fontsave;


void main(int argc, char **argv)
{
  fglinktgi();
  if (!fginit()) return;

  fontsave = getteglfont();
  setteglfont(countdwn);
  outtgtextxy(100,80,15,0,"Changed the font.");
  setteglfont(fontsave);
  outtgtextxy(100,120,15,0,"Default font restored.");

  getch();
  fgclose();
}



