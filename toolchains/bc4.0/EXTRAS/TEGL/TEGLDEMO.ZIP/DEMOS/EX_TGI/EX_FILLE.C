  /* -- ex_fille.c  */

#include <stdlib.h>
#include <conio.h>
#include "fgmisc.h"
#include "tgraph.h"

#define r 30

  int driver, mode;
  int xasp, yasp;

void main(int argc, char **argv)
{
  fglinktgi();
  driver = DETECT;
  initgraph(&driver,&mode,"");
  if (graphresult < 0) exit(1);

  fillellipse(getmaxx() / 2,getmaxy() / 2,50,100);
  getaspectratio(&xasp,&yasp);
    /*  Ellipse will be circular  */
  fillellipse(r,r,r,r * xasp / yasp);
  getch();
  closegraph(); 
}



