  /*  ex_iview.c  */
  /*  example for putpict and pictsize  */

#include <stdlib.h>
#include <conio.h>
#include "teglcond.h"
#include "iconsys.h"
#include "fastgrph.h"
#include "fgmisc.h"

  enum { iconlimit = 14 };
  iconptr ips[15]
      = {imageARROWLF,imageARROWDN,imageDISK35,
      imageDISK,imageCANCEL,imageSYSTEM,
      imageTRASH,imageFILE,imageKEYBRD2,
      imageTIGER,imageDRAWER,imageBELL,
      imageMUSIC,imageSTOPSIGN,imageMOUSE};

int i, bcolor, dcolor;
unsigned pw, ph;


void main(int argc, char **argv)
{
  fglinktgi();
  if (!fginit()) return;
  bcolor = 7;   /*  Light Gray  */
  dcolor = 0;   /*  BLACK  */
  if (fggetmaxcolor() == 1)
    {
      bcolor = 1;
      dcolor = 0;
    }
  for (i = 0; i <= iconlimit; i++)
    {
      fastbar(0,0,fgmaxx(),fgmaxy(),bcolor);
        /* -- use pictsize to center the icon  */
      pictsize(&pw,&ph, ips[i]);
      putpict((fgmaxx() - pw) / 2,(fgmaxy() - ph) / 2,
	ips[i],dcolor);
      outtgtextxy(10,fgmaxy() - 20,dcolor,bcolor,"Press Enter");
      getch();
    }
  fgclose();
}



