  /* -- ex_pie.c  */

#include <stdlib.h>
#include <conio.h>
#include "fgmisc.h"
#include "tgraph.h"



int    gd, gm, midx, midy, radius;


void main(int argc, char **argv)
{

  fglinktgi();
  gd = DETECT;
  initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);

  midx = getmaxx() / 2;
  midy = getmaxy() / 2;
  radius = 80;
  setfillstyle(SOLID_FILL, WHITE);
  bar(midx - 90,midy - 90,midx + 90,midy + 90);

    /* -- color is the outline of pie slice  */
  setcolor(BLACK);

  setfillstyle(SOLID_FILL,RED);
  pieslice(midx + 5,midy - 2,0,40,radius);

  setfillstyle(XHATCH_FILL, BLUE);
  pieslice(midx,midy,41,90,radius);

  setfillstyle(SLASH_FILL,GREEN);
  pieslice(midx,midy,91,340,radius);

  setfillstyle(SOLID_FILL,CYAN);
  pieslice(midx,midy,341,359,radius);

  setcolor(WHITE);
  outtextxy(10,10,"Press Enter");
  getch();
  closegraph();
}



