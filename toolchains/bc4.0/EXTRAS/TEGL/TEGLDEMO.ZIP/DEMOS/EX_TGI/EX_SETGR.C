  /*  ex_setgr.c  */

  /*  example for starting up graphics  */
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include "fastgrph.h"
#include "videochk.h"
#include "fgmisc.h"

char *s;

void main(int argc, char **argv)
{
  fglinktgi();
  s = videoautodetect();
  printf("%s\n",s);
  printf("Press Enter\n");
  getch();
  if (setgraphicmode(s,"") != 0)
    {
      printf("Could not find correct driver.\n");
      return;
    }
  if (initvideomode() != 0)
    {
      printf("Could not switch into graphic mode\n");
      return;
    }
    /* -- Must be in graphics mode now. Prove it.  */
  fastbar(0,0,fgmaxx(),fgmaxy(),fggetmaxcolor());
  fastbar(100,50,fgmaxx() - 100,150,0);
  outtgtextxy(200,80,fggetmaxcolor(),0,"This is the video mode:");
  outtgtextxy(200,100,fggetmaxcolor(),0,s);
  getch();
  resetlastvideomode(lastmode__,lastpage__);
}
