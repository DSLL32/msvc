  /*  ex_fgmis.c  */

  /*  example for using the minimal graphics startup  */

#include <conio.h>
#include "teglcond.h"
#include "fastgrph.h"
#include "fgmisc.h"

  int i, clearcolor;


void clearscr(void)
  {
    fastbar(0,0,fgmaxx(),fgmaxy(),clearcolor);
  }


void pressenter(void)
  {
    fastbar(0,fgmaxy() - 10,100,fgmaxy(),clearcolor);
    outtgtextxy(0,fgmaxy() - 10,0,1,"Press Enter");
    getch();
  }


void main(int argc, char **argv)
{

  fglinktgi();
  if (!fginit()) return;


    /*  if two color system then clear to  */
    /*  else clear to light gray  */

  if (fggetmaxcolor() == 1)
    clearcolor = 1;
  else clearcolor = 7;
  clearscr();
  pressenter();

    /*  draw some lines using all colors  */
  for (i = 0; i <= fgmaxy(); i++)
    fastline(0,i,fgmaxx(),i,i % fggetmaxcolor());
  pressenter();

    /*  draw some text  */
  clearscr();
  for (i = 1; i <= 10; i++)
    outtgtextxy(20,i * 10,0,1,"This is some text output!");
  pressenter();

  fgclose();
}



