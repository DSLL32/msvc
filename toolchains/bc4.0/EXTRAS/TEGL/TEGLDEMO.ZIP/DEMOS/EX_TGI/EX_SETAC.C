  /*  ex_setac.c  */
  /*  Example for SetActivePage and SetVisualPage  */

#include <stdlib.h>
#include <conio.h>
#include <dos.h>
#include "fgmisc.h"
#include "tgraph.h"

  int i, gd, gm;

void main(void)
{
  fglinktgi();
  detectgraph(&gd,&gm);
  if (graphresult() != grOk) exit(1);
  if ((gd != HERCMONO) && (gd != EGA) && (gd != VGA))
    exit(1);
  if (gd == VGA) gm = VGAMED;
  initgraph(&gd,&gm,"");
  setvisualpage(0);
  setactivepage(1);
  for (i = 101; i <= getmaxy(); i++)
    {
      setcolor(i % getmaxcolor());
      rectangle(i - 100,i - 100,i,i);
    }

  for (i = 1; i <= 20; i++)
    {
      setvisualpage(0);
      delay(100);
      setvisualpage(1);
      delay(100);
    }
  getch();
  closegraph(); 
}



