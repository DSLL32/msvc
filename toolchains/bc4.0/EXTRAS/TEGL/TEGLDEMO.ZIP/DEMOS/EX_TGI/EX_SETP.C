  /*  ex_setp.c  */
  /*  example for set palette  */

#include <stdlib.h>
#include <conio.h>
#include <dos.h>
#include "fgmisc.h"
#include "tgraph.h"

  int gd, gm;
  int radius, i,color;

void main(int argc, char **argv)
{
   /**/


  fglinktgi();
  gd = (int) DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);
  if (getmaxcolor() < 15)
    {
      closegraph();
      return;
    }
  for (i = 1; i <= getmaxy() / 2; i++)
    {
      setcolor(i % getmaxcolor());
      circle(getmaxx() / 2,getmaxy() / 2,i);
    }
    /*  set all to BLACK  */
  for (i = 0; i <= 15; i++)
    setpalette(i,BLACK);
    /*  restore  */
  for (i = 1; i <= 15; i++)
    setpalette(i,i);
    /*  play  */
  do {
    if (i >= 15)
      {
        i = 0;
        color = color + 1;
        if (color >= WHITE)
          color = BLUE;
      }
    i = i + 1;
    setpalette(i,color);
    /* comment out if not supported */
    delay(50);
    setpalette(i,BLACK);
  }  while (!(kbhit()));

    /*  restore colors  */
  for (i = BLACK; i <= WHITE; i++) setpalette(i,i);
  getch();
  closegraph();
}



