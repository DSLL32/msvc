  /*  ex_arc.c  */

#include <stdlib.h>
#include <conio.h>
#include "fgmisc.h"
#include "tgraph.h"

  int gd, gm;
  int radius;

void main(void)
{

  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);
  for (radius = 1; radius <= 5; radius++)
    arc(100,100,0,90,radius * 10);
  getch();
  closegraph();
}

