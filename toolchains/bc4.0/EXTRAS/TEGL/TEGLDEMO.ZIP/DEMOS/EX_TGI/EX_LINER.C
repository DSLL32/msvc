  /*  ex_liner.pas  */
  /*  example for linerel   */

#include <stdlib.h>
#include <conio.h>
#include "teglcond.h"
#include "fastgrph.h"
#include "fgmisc.h"
#include "tgraph.h"


int gd, gm;

void main(int argc, char **argv)
{
  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);
    /*  position the current void * at the  */
    /*  centre of the screen.  */
  moveto(getmaxx() / 2,getmaxy() / 2);
  setcolor(WHITE);
  linerel(-20,-20);
  linerel(+40,0);
  linerel(-40,+40);
  linerel(+40,0);
  linerel(-20,-20);


  getch();
  closegraph();
}



