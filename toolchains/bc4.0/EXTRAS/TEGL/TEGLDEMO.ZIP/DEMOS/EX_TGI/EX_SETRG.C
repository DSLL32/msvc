  /*  ex_setrg.c  */

#include <stdlib.h>
#include <conio.h>
#include "fastgrph.h"
#include "fgmisc.h"
#include "tgraph.h"


  int gd, gm;
  int radius, i, step;

void main(int argc, char **argv)
{
  fglinkvgax();
  if (!fggraphicmode("VGA320x240x256")) return;

    /*
  Gd := SVGA256;
  gm := SVGAXHi;
  InitGraph(Gd, Gm, '');
  if graphresult() <> grOk then Halt(1);
   */

  step = getmaxx() / 63;

    /* -- show first 128 colors of palette  */
  for (i = 0; i <= 63; i++)
    {
      setfillstyle(SOLID_FILL,i);
      bar(i * step,0,i * step + step,getmaxy() / 2);
      setfillstyle(SOLID_FILL,i + 64);
      bar(i * step,getmaxy() / 2,i * step + step,getmaxy());
    }

    /*  set 64 gray scale on upper screen  */
    /*  use equal values for RED GREEN and BLUE  */
  for (i = 0; i <= 63; i++)
    {
      setrgbpalette(i,i,i,i);
      setrgbpalette(i + 64,31,i,i);
    }
  getch();
  closegraph();
}



