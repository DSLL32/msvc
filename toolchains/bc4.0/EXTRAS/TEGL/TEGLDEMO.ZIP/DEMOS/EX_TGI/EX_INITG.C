  /*  ex_initg.c */
  /*  example for initgraph  */

#include <stdlib.h>
#include <conio.h>
#include <stdio.h>
#include "fgmisc.h"
#include "tgraph.h"

int gd, gm, err;


void main(void)
{
  fglinktgi();
  gd = DETECT;
  initgraph(&gd,&gm,"");
  err = graphresult();
  if (err == grOk)
    {
      line(0,0,getmaxx(),getmaxy());
      getch();
      closegraph();
    }
  else
    printf("Graphics error: %s\n",grapherrormsg(err));
}



