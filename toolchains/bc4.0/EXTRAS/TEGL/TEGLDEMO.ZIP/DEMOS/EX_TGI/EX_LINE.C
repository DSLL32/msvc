  /*  ex_line.c  */
  /*  Example for Line  */

#include <stdlib.h>
#include <conio.h>
#include <time.h>
#include "fgmisc.h"
#include "tgraph.h"


  int gd, gm;

void main(void)
{
  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);
  randomize();
  do {
    setcolor(random(getmaxcolor()));
    line(random(getmaxx()),random(getmaxy()),
	 random(getmaxx()),random(getmaxy()));
  }  while (!kbhit());
  getch();
  closegraph(); 
}



