  /* -- ex_getim.c  */
  /* -- example for getimage, putimage  */

#include <stdlib.h>
#include <conio.h>
#include "teglcond.h"
#include "fgmisc.h"
#include "tgraph.h"


  int gd, gm;
  int x1, y1, x2, y2, i;
  unsigned memreq;
  void *memptr;

void main(void)
{
  fglinktgi();
  gd = DETECT;
  initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);

    /* -- first we set up a background screen  */

  setfillstyle(XHATCH_FILL,BLUE);
  bar(0,0,getmaxx(),getmaxy());
  setcolor(WHITE);
  for (i = 1; i <= 20; i++)
    ellipse(getmaxx() / 2,getmaxy() / 2,0,360,
	(getmaxx() / i) / 2,(getmaxy() / i) / 10);

  getch();
    /* -- then we calculate an area to copy from  */
  x1 = getmaxx() / 4;
  y1 = getmaxy() / 4;
  x2 = x1 * 2;
  y2 = y1 * 2;
    /* -- outline it to prove the copy is correct  */
  setcolor(BLACK);
  rectangle(x1,y1,x2,y2);
  setcolor(WHITE);
  rectangle(x1 + 1,y1 + 1,x2 - 1,y2 - 1);

  getch();

    /* -- now grab the image and replicate it 10 times.  */
  memreq = imagesize(x1,y1,x2,y2);
  memptr = malloc(memreq);

  getimage(x1,y1,x2,y2,memptr);

  i = 10;
  while (i < x1)
    {
      putimage(i,i,memptr,COPY_PUT);
	/* -- alternative is XOR_PUT, an animation  */
        /* -- technique.  */
        /*
      putimage(i,i,memptr,XOR_PUT);
      delay(50);
      putimage(i,i,memptr,XOR_PUT);
       */
      i = i + getmaxx() / 20;
    }

  getch();
  closegraph();
}



