  /*  ex_rgtgi.c  */
  /*  example for registertgidriver  */

#include <conio.h>
#include "fastgrph.h"
#include "fgmisc.h"


void main(int argc, char **argv)
{

    /*  this will link in the driver and  */
    /*  register those modes supported.  */

  registertgidriver((void (*)(void))GRCGABW_driver);
  registertgidriver((void (*)(void))GRHERCBW_driver);
  registertgidriver((void (*) (void))GREVGA16_driver);


  if (!fginit()) return;
  fastbar(0,0,fgmaxx(),fgmaxy(),fggetmaxcolor());


  outtgtextxy(10,fgmaxy() - 30,0,0,"Press Enter");
  getch();

}

