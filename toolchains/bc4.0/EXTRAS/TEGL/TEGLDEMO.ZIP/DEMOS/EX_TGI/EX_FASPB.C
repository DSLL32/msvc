/*  ex_faspb.c   */
/*  example for fastpatternbar  */

#include <stdlib.h>
#include <conio.h>
#include "fastgrph.h"
#include "fgmisc.h"

char fp[8]   = {0,0,0,0xff,0,0,0,0xff};


void main(void)
{

  fglinktgi();
  if (!fginit()) return;
  fastpatternbar(0,0,fgmaxx(),fgmaxy(),1,fp);
  getch();
  fgclose();
}



