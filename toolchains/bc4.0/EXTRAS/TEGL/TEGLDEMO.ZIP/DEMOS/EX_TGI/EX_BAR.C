  /*  ex_bar.pas  */

#include <stdlib.h>
#include <conio.h>
#include "teglcond.h"
#include "fgmisc.h"
#include "tgraph.h"



  char halfon[8]   = {0xAA,0x55,0xAA,
    0x55,0xAA,0x55,0xAA,0x55};


  int gd, gm;
  int i, x1, y1, x2, y2;

void main(void)
{

  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);
    /* -- use bar to clear the screen, this should be an acceptable  */
    /* -- backdrop on any display  */
  setfillpattern(halfon,getmaxcolor());
  bar(0,0,getmaxx(),getmaxy());
  do {
    x2 = random(getmaxx());
    y2 = random(getmaxy());
    x1 = (random(getmaxx() - x2));
    y1 = (random(getmaxy() - y2));

    setfillstyle(random(USER_FILL),random(getmaxcolor()) + 1);
    bar(x1,y1,x2,y2);
  }  while (!(kbhit()));
  getch();
  closegraph();
}



