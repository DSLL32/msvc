  /*  ex_getmx.c  */
  /*  Example for GetMaxX and GetMaxY  */

#include <stdlib.h>
#include <conio.h>
#include "fgmisc.h"
#include "tgraph.h"


  int x, y, gd, gm;

void main(void)
{
  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);
  rectangle(1,1,getmaxx() - 1,getmaxy() - 1);
    /*  getmaxx and getmaxy make it easy to center things  */
  x = getmaxx() / 4;
  y = getmaxy() / 4;
  rectangle(x,y,x * 3,y * 3);
  getch();
  closegraph(); 
}



