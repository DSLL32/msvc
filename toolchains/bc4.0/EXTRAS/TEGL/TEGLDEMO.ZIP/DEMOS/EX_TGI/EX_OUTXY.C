  /*  ex_outxy.pas  */

#include <stdlib.h>
#include <conio.h>
#include "fgmisc.h"
#include "tgraph.h"


  int gd, gm;
  int radius;

void main(int argc, char **argv)
{
  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);

  settextjustify(CENTER_TEXT,TOP_TEXT);
  outtextxy(getmaxx() / 2,getmaxy() / 2,
    "Same as moveto then outtext");
  getch();
  closegraph();
}



