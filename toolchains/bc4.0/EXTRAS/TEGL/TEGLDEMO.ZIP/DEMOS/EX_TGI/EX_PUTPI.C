  /*  ex_putpi.c  */

#include <stdlib.h>
#include <conio.h>
#include "fastgrph.h"
#include "fgmisc.h"


void main(int argc, char **argv)
{
  fglinktgi();
  if (!fginit()) return;

  do {
    putpixs(random(fgmaxx()),random(fgmaxy()),
      random(fggetmaxcolor() + 1));
  }  while (!(kbhit()));

  getch();
  fgclose();
}



