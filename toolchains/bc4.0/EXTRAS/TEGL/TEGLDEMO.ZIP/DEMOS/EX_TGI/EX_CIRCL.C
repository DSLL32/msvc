  /*  ex_circle.c  */

#include <stdlib.h>
#include <conio.h>
#include "teglcond.h"
#include "fgmisc.h"
#include "tgraph.h"


  int gd, gm;
  int i, x1, y1, x2, y2;

void main(void)
{
  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);
    /* -- maxy is usually < maxx  */
  for (i = 1; i <= (getmaxy() / 2); i++)
    {
      setcolor(random(getmaxcolor()) + 1);
      circle(getmaxx() / 2,getmaxy() / 2,i);
    }
  getch();
  closegraph(); 
}



