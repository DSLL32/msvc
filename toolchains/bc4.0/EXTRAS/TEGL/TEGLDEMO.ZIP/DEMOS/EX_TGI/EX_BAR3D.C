  /*  ex_bar3d.c  */

#include <stdlib.h>
#include <conio.h>
#include "fgmisc.h"
#include "tgraph.h"

  char halfon[8]   = {0xAA,0x55,0xAA,
    0x55,0xAA,0x55,0xAA,0x55};


  int gd, gm;
  int i, x1, y1, x2, y2;

void main(void)
{
  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);
    /* -- use bar to clear the screen, this should be an acceptable  */
    /* -- backdrop on any display  */

  setfillpattern(halfon,getmaxcolor());
  bar(0,0,getmaxx(),getmaxy());

  setfillstyle(SOLID_FILL,BLUE);
  setcolor(RED);
  bar3d(10,40,80,180,30,1);
  setfillstyle(LINE_FILL,BLUE);
  bar3d(81,70,150,180,30,1);


  getch();
  closegraph();
}



