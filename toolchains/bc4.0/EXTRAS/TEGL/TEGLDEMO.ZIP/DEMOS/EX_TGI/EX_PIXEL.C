  /*  ex_pixel.c  */
  /*  example for putpixel  */

#include <stdlib.h>
#include <conio.h>
#include "fgmisc.h"
#include "tgraph.h"

int gd, gm;


void main(void)
{
  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);
  do {
    putpixel(random(getmaxx()),random(getmaxy()),
       random(getmaxcolor()
    ));
  }  while (!kbhit());
  closegraph(); 
}



