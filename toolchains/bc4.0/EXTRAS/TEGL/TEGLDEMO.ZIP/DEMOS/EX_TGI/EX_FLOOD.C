  /*  -- ex_flood.c  */

  /* -- example for flood fill  */
  /* -- NOTE! Flood fill uses the stack, make it larger  */
  /* -- if you plan on filling complicated items.  */

#include <stdlib.h>
#include <conio.h>
#include "teglcond.h"
#include "fgmisc.h"
#include "tgraph.h"


  int _TGSHORT_ polygon[8]
       = {100,100,200,200,100,200,100,100};

  int _TGSHORT_ polygon2[8]
       = {70,50,300,300,70,300,70,50};

  int gd, gm;


void main(void)
{
  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);

  setcolor(WHITE);
  drawpoly(sizeof(polygon) / 4,polygon);
  drawpoly(sizeof(polygon2) / 4,polygon2);

  setfillstyle(SOLID_FILL,BLUE);
  floodfill(105,150,WHITE);
  setfillstyle(SOLID_FILL,LIGHTGRAY);
  floodfill(72,100,WHITE);


  getch();
  closegraph(); 
}



