  /*  ex_setcs.c  */
  /*   example for setusercharsize  */

#include <stdlib.h>
#include <conio.h>
#include <stdio.h>
#include "teglcond.h"
#include "fastgrph.h"
#include "fgmisc.h"
#include "tgraph.h"

int gd, gm;
int finefont;



void main(void)
{
   /**/


  finefont = (int) installuserfont("fine.chr");
  if ((finefont < 0))
    {
      printf("Font file missing.\n");
      return;
    }
  fglinktgi();
  gd = (int) DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);
  setfillstyle(SOLID_FILL,WHITE);
  bar(0,0,getmaxx(),getmaxy());
  setcolor(BLACK);
  settextstyle(finefont,HORIZ_DIR,4);
  outtextxy(10,10,"Fine Font at design size.");
  setusercharsize(100,100,500,100);
  outtextxy(10,50,"Change the values and see what happens.");
  getch();
  closegraph();
}



