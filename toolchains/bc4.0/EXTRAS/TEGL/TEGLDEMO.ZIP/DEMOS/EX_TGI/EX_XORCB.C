/*  ex_xorcb.c  */

#include <stdlib.h>
#include <conio.h>
#include <dos.h>
#include "fastgrph.h"
#include "fgmisc.h"

int i, color;

void main(color)
{
  fglinktgi();
  if (!fginit()) return;
  fastbar(0,0,fgmaxx(),fgmaxy(),fggetmaxcolor());
  i = 0;
  color = 0;
  do {
    color = color + 1;
    if (color > fggetmaxcolor()) color = (int) fggetmaxcolor();
    if (i > fgmaxy() / 2) i = 0;
    xorcornerbox(i,i,fgmaxx() - i,fgmaxy() - i,color);
    delay(50);
      /*  try commenting out this line  */
    xorcornerbox(i,i,fgmaxx() - i,fgmaxy() - i,color);
    i = i + fgmaxy() / 50;
  }  while (!(kbhit()));

  getch();
  fgclose();
}



