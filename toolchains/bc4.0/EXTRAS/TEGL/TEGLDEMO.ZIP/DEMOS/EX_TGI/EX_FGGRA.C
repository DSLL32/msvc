  /*   ex_fggra.pas  */

  /*   example for fggraphicmode  */
  /*   switches into VGA X mode   */

#include <conio.h>
#include "teglcond.h"
#include "fastgrph.h"
#include "fgmisc.h"


int i;



void main(int argc, char **argv)
{
  fglinkvgax();
    /* -- this mode supported by most VGA cards */
  if (!fggraphicmode("VGA320x240x256")) return;
    /*  prove it  */

  for (i = 0; i <= fgmaxy(); i++)
    fastline(0,i,fgmaxx(),i,i);

  getch();
  fgclose();
}



