  /* -- ex_clrde.pas  */
  /* -- cleardevice example  */

#include <stdlib.h>
#include <conio.h>
#include "teglcond.h"
#include "fgmisc.h"
#include "tgraph.h"

  int gd, gm;

void main(void)
{
  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);

    /* -- cleardevice uses the background color  */
    /* -- and is not affected by the viewport settings   */
  setbkcolor(WHITE);
  cleardevice();

  getch();
  closegraph(); 
}



