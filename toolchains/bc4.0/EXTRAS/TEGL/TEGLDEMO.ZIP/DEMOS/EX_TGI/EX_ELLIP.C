  /* -- ex_ellip.c  */
  /* -- example for ellipse  */

#include <stdlib.h>
#include <conio.h>
#include "fgmisc.h"
#include "tgraph.h"

  int gd, gm;
  int i, x1, y1, x2, y2;

void main(void)
{
  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);


    /* -- we use ellipse to draw only partial ellipse's, note  */
    /* -- start angle and end angle values.  */

  for (i = 1; i <= 10; i++)
    {
      ellipse(getmaxx() / 2,getmaxy() / 2,0,330,i * 20,i * 10);
      ellipse(getmaxx() / 2,getmaxy() / 2,320,10,i * 20 + 10,i * 10 + 5);
    }

  getch();
  closegraph(); 
}



