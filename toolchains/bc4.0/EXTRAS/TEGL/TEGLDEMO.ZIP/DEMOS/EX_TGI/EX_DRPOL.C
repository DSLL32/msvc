  /*  -- ex_drpol.c  */
  /* -- example for drawpoly  */

#include <stdlib.h>
#include <conio.h>
#include "fgmisc.h"
#include "tgraph.h"


  int polygon[10]
       = {100,100,
       200,200,
       100,200,
       200,100,
       100,100};

  int gd, gm;

void main(int argc, char **argv)
{
  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);

  setcolor(WHITE);
  drawpoly(5,polygon);


  getch();
  closegraph(); 
}



