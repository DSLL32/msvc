  /* -- ex_cview.c  */
  /* -- clearviewport example  */

#include <stdlib.h>
#include <conio.h>
#include "teglcond.h"
#include "fgmisc.h"
#include "tgraph.h"

  int gd, gm;

void main(void)
{
  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);
    /* -- the viewport defaults to 0,0, getmaxx, getmaxy at startup  */
    /* -- but we will specifically set it here.  */
  setviewport(0,0,getmaxx(),getmaxy(),1);

  setfillstyle(SOLID_FILL,WHITE);
    /* -- notice that we let clipping look after the bar region  */
  bar(0,0,4000,4000);


  setbkcolor(getmaxcolor() / 2);
  setviewport(100,100,getmaxx() - 100,getmaxy() - 100,1);
  clearviewport();

  getch();
  closegraph(); 
}



