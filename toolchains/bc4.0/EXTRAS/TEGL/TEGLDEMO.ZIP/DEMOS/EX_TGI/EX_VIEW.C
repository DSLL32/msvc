  /*  ex_view.c  */

  /*  viewport example  */

#include <stdlib.h>
#include <conio.h>
#include "fgmisc.h"
#include "tgraph.h"


int i, x4, y4, gd, gm;


/* -- draw a viewport with a border and clear it.  */


void makeviewport(int x1, int y1, int x2, int y2)
  {
    setviewport(0,0,getmaxx(),getmaxy(),0);
    setcolor(WHITE);
    rectangle(x1 - 1,y1 - 1,x2 + 1,y2 + 1);
    setviewport(x1,y1,x2,y2,1);
    setfillstyle(SOLID_FILL,BLACK);
    bar(0,0,4000,4000);
  }


  /* -- these items will always draw relative to  */
  /* -- the current viewport.  */

void drawthings(void)
  {
    setcolor(WHITE);
    outtextxy(50,10,"Text is relative");
   for (i = 1; i <= 100; i++)
     {
       setcolor(i % getmaxcolor());
       rectangle(30 + i,30 + i,100 + i,100 + i);
       ellipse(i + 100,i + 100,0,360,140,30);
     }
    setfillstyle(SOLID_FILL,CYAN);
    fillellipse(200,200,140,30);
  }


void main(int argc, char **argv)
{
  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) return;
  x4 = getmaxx() / 4; y4 = getmaxy() / 4;

    /* -- see how circles are clipped  */
  makeviewport(x4,y4,x4 * 3,y4 * 3);
  i = 0;
  while (i < 200)
    {
      i = i + 5;
      circle(x4,y4,i);
    }
  getch();

    /* -- call drawthings in several viewports  */
  makeviewport(10,10,10 + x4 * 2,10 + y4 * 2);
  drawthings();
  makeviewport(10,y4 * 3 - 10,10 + x4 * 2,getmaxy() - 10);
  drawthings();
  makeviewport(x4 * 3 - 10,10,getmaxx() - 10,y4 * 2 + 10);
  drawthings();
  makeviewport(x4 * 3 - 10,y4 * 3 - 10,getmaxx() - 10,getmaxy() - 10);
  drawthings();


  getch();
  closegraph();
}



