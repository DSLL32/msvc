  /*  ex_outtx.c  */

#include <stdlib.h>
#include <conio.h>
#include "fgmisc.h"
#include "tgraph.h"


  int gd, gm;
  int radius;

void main(int argc, char **argv)
{
  fglinktgi();
  gd = DETECT; initgraph(&gd,&gm,"");
  if (graphresult() != grOk) exit(1);

  outtext("The default is the Current");
  moveto(0,10);
  outtext("Pointer is at (0,0).");
  getch();
  closegraph();
}



