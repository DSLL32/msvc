  /*  ex_grerr.c  */
  /*  Example for GraphErrorMsg  */

#include <stdlib.h>
#include <conio.h>
#include <stdio.h>
#include "fgmisc.h"
#include "tgraph.h"

  int graphdriver, graphmode, errorcode;

void main(void)
{
  fglinktgi();
  graphdriver = DETECT;
  initgraph(&graphdriver,&graphmode,"");
  errorcode = graphresult();
  if (errorcode != grOk)
  {
    printf("Graphics error: %s\n",grapherrormsg(errorcode));
    getch();
    exit(1);
  }
  line(0,0,getmaxx(),getmaxy());
  getch();
  closegraph(); 
}



