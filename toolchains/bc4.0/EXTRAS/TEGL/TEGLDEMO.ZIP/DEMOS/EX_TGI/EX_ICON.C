  /*  ex_icon.c */
  /*  example showing the internals of an icon  */

#include <stdlib.h>
#include <conio.h>
#include "teglcond.h"
#include "fastgrph.h"
#include "iconsys.h"
#include "fgmisc.h"



     typedef struct iconstruct {
       unsigned length;
       unsigned char d[ /* 0..16384 */ 16385];
     } iconstruct;

     typedef iconstruct *iconstrucptr;


  /*  x1, y1, x2, y2 - the area of the screen to convert to  */
  /*                   icon format.                          */
  /*  tcolor         - color to treat as transparent, this   */
  /*                   color will not be saved in the icon   */



iconstrucptr converttoicon(int x1, int y1, int x2, int y2, int tcolor)
  {
    int oldx, x, y, rx, ry, color, index;
    iconstrucptr icon;

    unsigned char colorchange, isline;

    icon = malloc(sizeof(iconstruct));
    if (icon == NULL) return NULL;

    index = 0;
    color = getpixs(x1,y1);
    colorchange = TRUE;
      /*  process the image line by line  */
    for (ry = y1; ry <= y2; ry++)
      {
      oldx = 0;
      isline = FALSE;
        /*   dot by dot  */
      for (rx = x1; rx <= x2; rx++)
        {
          x = rx - x1 + 2;
          y = ry - y1 + 1;
          if (getpixs(rx,ry) != color)
            {
              color = getpixs(rx,ry);
              colorchange = TRUE;
            }
            /* -- IF END of line, color change or next color  */
            /* -- is transparent THEN encode.  */
          if ((rx == x2) || (getpixs(rx + 1,ry) == tcolor)
              || (getpixs(rx + 1,ry) != color))
            {
               /*  encode only if not transparent  */
             if ((color != tcolor))
              {
              if (isline)
                {
                  icon->d[index++] = oldx | 128;
                  if (colorchange)
                    {
                      icon->d[index++] = y | 128;
                      icon->d[index++] = color;
                    }
                  else
                    {
                      icon->d[index++] = y;
                    }
                  icon->d[index++] = x - 1;
                }
              else
                {
                  icon->d[index++] = x;
                  if (colorchange)
                    {
                      icon->d[index++] = y | 128;
                      icon->d[index++] = color;
                    }
                  else
                    {
                      icon->d[index++] = y;
                    }
                }
              }   /* -- IF color <> tcolor  */
              isline = FALSE;
              colorchange = FALSE;
            }

          if (!isline)
            {
              isline = TRUE;
              oldx = x;
            }

            /* -- used up the full buffer  */
          if (index >= sizeof(iconstruct) - 6)
            {
              rx = x2;
              ry = y2;
            }
          }   /*  for x  */
        }   /*  for y  */

      /* -- now copy into exact memory allocation  */
    /*
    icon2 = malloc(index + 2);
    icon2->length = index - 1;
    for (rx = 0; rx <= index; rx++)
      icon2->d[rx] = icon->d[rx];

    free(icon);
    */
    icon->length = index-1;
    return realloc(icon, index + 2);
  }




void drawicon(int x, int y, iconstrucptr icon_, int defaultc)
  {
    iconstrucptr icon;
    int rx, ry;
    int color, index;
    unsigned char isline, colorchange;


    x = x - 1;
    y = y - 1;

    icon = (iconstrucptr) icon_;
      /* -- icon data, first two unsigned chars are always  */
      /* -- an x and y coordinate  */
    index = 0;
    color = defaultc;
    while (index < icon->length)
      {
        rx = icon->d[index++];
        ry = icon->d[index++];
          /* -- IF hi bit set on y coordinate THEN next unsigned char is a  */
          /* -- a color change.  */
        isline = rx > 127;
        rx = rx & 0x7f;
        colorchange = ry > 127;
        ry = ry & 0x7f;
        if (colorchange)
          {
            color = icon->d[index++];
            if (color == 0) color = defaultc;
          }
        if (isline)
          {
            fastline(x + rx,y + ry,
              x + (icon->d[index++] & 0x7f),y + ry,color);
          }
        else
          putpixs(x + rx,y + ry,color);
      }
  }


int i;
iconstrucptr icn;

void main(void)
{
  fglinktgi();
  if (!fggraphicmode("EGA640x350x16")) return;
  fastbar(0,0,fgmaxx(),fgmaxy(),7);
  drawicon(0,0,(iconstrucptr) imageSYSTEM,0);
    /*  capture it  */
  icn = converttoicon(0,0,91,69,7);
  getch();
    /*  draw it again  */
  fastbar(0,0,fgmaxx(),fgmaxy(),9);
  drawicon(100,0,icn,0);
  getch();
  fgclose();
}



