#include "teglcond.h"
#include "videochk.h"
#include "fastgrph.h"
#include <stdlib.h>
#include <string.h>
#include <conio.h>


    int      errcode;
    char	 videoname[80];
    int      x1, y1, x2, y2;

void main(void)
{

  registertgidriver((void (*) (void))GREVGA16_driver);	 /* -- link in 16 color driver too */

    /* -- detect video and best resolution  */
  strcpy(videoname,videoautodetect());
    /* -- set the graphic mode	*/
  if (setgraphicmode(videoname,"") < 0) exit(1);
    /* -- then initialize the graphics system (this actually switches to  */
    /* -- graphics mode).  */
  errcode =  initvideomode();

    /* -- test it with some random bars  */
  do {
    x2 = (random(activeteglmode->maxx - 1));
    y2 = (random(activeteglmode->maxy - 1));
    x1 = (random(activeteglmode->maxx - x2 - 20));
    y1 = (random(activeteglmode->maxy - y2 - 20));
    if (x1 < 0) x1 = 0;
    if (y1 < 0) y1 = 0;
    if (x2 <= x1) x2 = x1 + 20;
    if (y2 <= y1) y2 = y1 + 20;
    fastbar(x1,y1,x2,y2,random(activeteglmode->maxcolor + 1));
  }  while (!(kbhit()));
  getch(); getch();

    /* -- restore to video mode at start up  */
  resetlastvideomode(lastmode__,lastpage__);
}



