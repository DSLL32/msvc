/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <process.h>
#include <string.h>

#include "teglsys.h"
#ifdef TURBOC
#include <alloc.h>
#include <dir.h>
#endif

#ifdef QUICKC
#ifndef __ZTC__
#include <malloc.h>
#endif
#include <direct.h>
#endif

optionmptr  om1;

unsigned dospawn(imagestkptr frame,msclickptr mouseclickpos)
{
  if (visualbuttonpress(frame, mouseclickpos)) {
     hidemouse();
     pushimage(0,0,getmaxx(),getmaxy());
     setkeyboardmouse(FALSE);
     swapteglintroff();
     restorecrtmode();

     dos_exec("", "", 1, 0xffff, NULL);

     initvideomode();
     swapteglintron();
     setmouseposition(430,230);
     setkeyboardmouse(TRUE);
     popimage();
     showmouse();
     releasebutton(frame,mouseclickpos);
  }

  return 1;
}

unsigned easyquit(imagestkptr frame,msclickptr mouseclickpos)
{
    seteasyfont((fontptr)font14);
    if (getyesno(100,50,"Are you sure"))
       abortexit("Bye....");

    return 1;
}

unsigned infooption(imagestkptr ifs, msclickptr ms)
{
    imagestkptr fs;
    unsigned x=100,y=100,w=370,h=100;

    hidemouse();
    quickframe(&fs,&x,&y,&w,&h);

    setcolor(BLACK);
    frametext(fs,1,2,"Simple program to test spawn capability.");
    definebuttonclick(fs,x+300,y+70,(iconptr)imageOK,NULL);
    showmouse();

    while (checkformouseselect(fs) == NULL) {};

    dropstackimage(fs);

    return 1;
}



void main(void)
{
    easytegl();
    easyout();
    setctrlbreakfs(easyquit);

    setteglfont((fontptr)font14);
    setoptionmenucolors(BLACK,CYAN);
    om1 = createoptionmenu((fontptr)font14);
    defineoptions(om1," Info... ", TRUE, infooption);
    defineoptions(om1,"--",     FALSE, NULL);
    defineoptions(om1," Quit ", TRUE, easyquit);

    createbarmenu(0,0,getmaxx());
    outbaroption(" File ",om1);

    activebutton(440,190," SPAWN  ",dospawn);

    teglsupervisor();
}
