/* ex_keyax.c */
/* illustrates how to trap for standard keypresses. */

#include "teglsys.h"
#include "conio.h"

imagestkptr  myframe;

void         clrframe(imagestkptr  ifs)
  {
    prepareforupdate(ifs);
    setfillstyle(SOLID_FILL,WHITE);
    bar(ifs->x,ifs->y,ifs->x1,ifs->y1);
    setcolor(BLACK);
    rectangle(ifs->x,ifs->y,ifs->x1,ifs->y1);
    commitupdate();
  }

unsigned showkeys(imagestkptr  ifs, msclickptr   ms)
  { char         ch;

    if (kbhit)
      {
	setcolor(BLACK);
	clrframe(ifs);
	prepareforupdate(ifs);
	ch = getch();
	if (ch == '\x00')
	  {
	    ch = getch();
	    outtgtextxy(ifs->x + 10,ifs->y + 10,BLACK,WHITE,
			    "Extended Key Code  %c",ch);
	  }
	else
	  outtgtextxy(ifs->x + 10,ifs->y + 10,BLACK,WHITE,
	       "Key pressed %c",ch);
	commitupdate();
      }
    return 0;
  }

void main(int argc, char **argv)
{
  easytegl();
  easyout();
  setkeyboardmouse(FALSE);
  pushimage(100,100,300,200);
  myframe = stackptr;
  clrframe(myframe);
    /* -- special case, 0 as keycode traps for all keycodes not allready  */
    /* -- trapped for.  */
  defineglobalkeyclickarea(myframe,NULL,0,FALSE,showkeys);
  teglsupervisor();
}

