/* -- ex_user.c  */

#include "teglsys.h"
#include <string.h>
#include <stdio.h>
#include <alloc.h>

/*This example show how to use SetUserDataArea and GetUserDataArea to
  attach and use data that is automatically deallocated when the frame
  is disposed of.

  This example just establishes a message string. The key value here
  is that we establish communication between events without having to
  use global data.   */


#define MESSAGEKEY 7867
#define MESSAGESTRLEN 80



/* -- this function will dispose of a message area that has been  */
/* -- allocated to a frame.  */


unsigned disposemystring(imagestkptr ifs, unsigned key, void * dataitem)
  {
    char *s=dataitem;

    if (((key == MESSAGEKEY) && (s != NULL)))
      cfreemem(s,MESSAGESTRLEN);
      /* -- non zero return value will abort program  */
    return 0;

  }

  /* -- show message displays whatever is in the user message area  */


unsigned showmessage(imagestkptr ifs, msclickptr ms)
  { char *mess;

    getuserdataarea(ifs,MESSAGEKEY,&mess);
    setfillstyle(SOLID_FILL,WHITE);
    setviewport(ifs->x + 10,ifs->y + 10,ifs->x + 180,ifs->y + 30,1);
    prepareforupdate(ifs);
    bar(0,0,180,30);
    setcolor(BLACK);
    outtextxy(2,2,mess);
    commitupdate();
    setviewport(0,0,getmaxx(),getmaxy(),0);
    return 0;
  }


unsigned changemessage(imagestkptr ifs, msclickptr ms)
  { static int mescount   = 1;
    char *mess;
    getuserdataarea(ifs,MESSAGEKEY,&mess);
    switch (mescount) {

      case 1:	strcpy(mess,"Have a nice Day!");
		break;

      case 2:	strcpy(mess,"TEGL windows are FUN!");
		break;
    }
    mescount = mescount + 1;
    if (mescount > 2) mescount = 1;
    if (visualsquarebuttonpress(ifs,ms))
      {
	releasesquarebutton(ifs,ms);
	return showmessage(ifs,ms);
      }
    return 0;
  }


void createwindow(void)
  {  char *mess;
      imagestkptr myframe;

      /* -- orginal memory allocation, DisposeMyString will deallocate	*/
      /* -- this when the frame is disposed (dropstackimage).  */
    mess = cgetmem(MESSAGESTRLEN);
    strcpy(mess,"The Original String");
    pushimage(100,100,300,200);   /*  200 x 100  */
    myframe = stackptr;
    bevelbox(100,100,300,200,LIGHTGRAY,DARKGRAY,WHITE,5);
      /* -- establish the link to the frame  */
    setuserdataarea(myframe,MESSAGEKEY,mess,disposemystring);
      /* -- call show message for the first time  */
    if (showmessage(myframe,NULL) == 0) ;
      /* -- link changemessage by a button.  */
    definesquarebuttontext(myframe,6,70,194,94,20,3,
       "Change Message",changemessage);
  }




void main(void)
  {

    fglinktgi();
    easytegl();
    easyout();

    createwindow();

    teglsupervisor();
  }



