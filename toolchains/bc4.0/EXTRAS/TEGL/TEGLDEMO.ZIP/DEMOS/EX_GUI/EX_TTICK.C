/*  ex_ttick.c  */
/*  example for settimertick  */

#include "teglsys.h"

  int show   = 0;
  imagestkptr timerwin;


unsigned timerevent(imagestkptr ifs, msclickptr ms)
  {
    if (show == 0)
      {
        hideimage(timerwin);
        show = 1;
      }
    else
      {
        showimage(timerwin,timerwin->x,timerwin->y);
        show = 0;
      }
    return 0;
  }


void main(int argc, char **argv)
{
  easytegl();
  easyout();
  pushimage(10,10,100,100);
  timerwin = stackptr;
  shadowbox(10,10,100,100);
  settimertick(9,timerevent,NULL,NULL);
  teglsupervisor();
}



