/* -- ex_frbut.c */

#include "teglsys.h"

imagestkptr  ifs;

unsigned cancelevent(imagestkptr  frame, msclickptr   mouse)
  {
    dropstackimage(ifs);
    return 0;
  }

void main(void)
{
  easytegl();
  easyout();
  pushimage(50,50,200,150);
  shadowbox(50,50,200,150);
  ifs = stackptr;
  definesquarebuttontext(ifs,0,0,80,30,5,5,"CANCEL",cancelevent);
  teglsupervisor();
}

