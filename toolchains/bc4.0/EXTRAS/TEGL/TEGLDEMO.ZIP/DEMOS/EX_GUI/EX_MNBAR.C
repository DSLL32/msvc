  /* -- menu1.c */

#include "teglsys.h"

unsigned exitoption(imagestkptr  ifs, msclickptr   ms)
  {
    abortexit("");
    return 0;
  }

optionmptr   omfile;


void main(void)
{


  easytegl();
  easyout();

  omfile = createoptionmenu((fontptr)f8x12bol);
  defineoptions(omfile," ~O~pen ",TRUE,nilunitproc);
  defineoptions(omfile,"-",FALSE,nilunitproc);
  defineoptions(omfile," E~x~it ",TRUE,exitoption);
  setteglfont((fontptr)f8x12bol);
  createbarmenu(0,0,getmaxx());
  outbaroption(" ~F~ile ",omfile);

  teglsupervisor();
}



