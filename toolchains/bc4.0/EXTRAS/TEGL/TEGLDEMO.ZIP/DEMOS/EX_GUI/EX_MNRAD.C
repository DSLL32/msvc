  /* -- menu5.c  */

#include "teglsys.h"

unsigned exitoption(imagestkptr  ifs, msclickptr   ms)
  {
    abortexit("");
    return 0;
  }


     fontptr	  menufont;
     optionmptr   omfile;

     unsigned	      sortoption    = 1;


void main(void)
{


  easytegl();
  easyout();

  menufont = (fontptr)f8x12bol;


  omfile = createoptionmenu(menufont);
  defineoptions(omfile," ~O~pen ",TRUE,nilunitproc);
  defineoptions(omfile,"-",FALSE,nilunitproc);
  defineoptionsradio(omfile," ~N~ame ",TRUE,nilunitproc,1,&sortoption);
  defineoptionsradio(omfile," ~E~xtension ",TRUE,nilunitproc,2,&sortoption);
  defineoptionsradio(omfile," ~D~ate ",TRUE,nilunitproc,3,&sortoption);
  defineoptionsradio(omfile," N~o~ne ",TRUE,nilunitproc,4,&sortoption);
  defineoptions(omfile,"-",FALSE,nilunitproc);
  defineoptions(omfile," E~x~it ",TRUE,exitoption);

  setteglfont(menufont);
  createbarmenu(0,0,getmaxx());
  outbaroption(" ~F~ile ",omfile);

  teglsupervisor();
}



