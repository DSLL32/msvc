/* -- ex_pkdir.c */

#include "teglsys.h"
#ifdef QUICKC
#include <stdlib.h>
#include <direct.h>
#else
#include "dir.h"
#endif
#include <dos.h>
#include <string.h>

char	     ispicked[40];   /* -- stores the picked file name	*/

  /* -- drops the picklist when the frame is disposed of  */

unsigned _dropplist(imagestkptr fs,unsigned userkey,void *dataarea)
{
    optionmptr picklist = (optionmptr) dataarea;
    dropoptionmenu(picklist);
    return 0;
}

  /* -- simple, but handy  */

void	     setviewporttoframe(imagestkptr  ifs)
  {
    setviewport(ifs->x,ifs->y,ifs->x1,ifs->y1,TRUE);
  }

  /* -- this event is called whenever a an item is clicked on  */

unsigned waspicked(imagestkptr	ifs, msclickptr   ms)
  {
    setviewporttoframe(ifs);   /* -- set relative to frame  */
    setfillstyle(SOLID_FILL, WHITE);   /* -- usual colors  */
    bar(10,10,140,20);	 /* -- bar out old file name  */
    setcolor(BLACK);   /* -- black letters  */
    outtextxy(10,10,ispicked);	 /* -- show selection  */
      /* -- left double click just checks to see if the left mouse button  */
      /* -- was pressed again (within the double click delay) after entering  */
      /* -- this function. If so then it means the file was selected and we  */
      /* -- should exit.  */

    if (leftdoubleclick()) dropstackimage(ifs);
    return 0;
  }

  /* -- just tidy up the files name to make it more acceptable in the pick  */
  /* -- list view.  */

char * fmtfilename(char * s)
  {
    static char    s1[21];
    strcpy(s1,s);

    while (strlen(s1) < 12) strcat(s1," ");
    return s1;
  }

  /* -- findfirst etc. are in your compiler manual */

void   getfilename(char *path,  char *filearg, unsigned attr)

{
#ifdef QUICKC
  struct find_t   dd;
#else
  struct ffblk	  dd;	/* -- store directory entries  */
#endif

  optionmptr   pom;
  imagestkptr  ifs;
  char	       fullpath[80];
  int	       done;
  unsigned x1 = 100;
  unsigned y1 = 100;
  unsigned x2 = 200;
  unsigned y2 = 200;

    quickframe(&ifs,&x1,&y1,&x2,&y2);
    setproportional(FALSE);
    pom = createpicklist((fontptr)f8x8bold);
    setuserdataarea(stackptr,5432,pom,_dropplist);
    setviewporttoframe(ifs);
    setteglfont((fontptr)f8x8bold);
    setcolor(BLACK);
    rectangle(5,5,150,23);
    outtextxy(10,10,filearg);
    outtextxy(10,35,path);
    strcpy(fullpath,path);
    strcat(fullpath,filearg);
#ifdef QUICKC
    done = _dos_findfirst(fullpath, _A_SUBDIR, &dd);
#else
    done = findfirst(fullpath,&dd,attr);
#endif
    while (!done)
      {
#ifdef QUICKC
	definepickitem(pom,fmtfilename(dd.name),waspicked,ispicked);
        done = _dos_findnext(&dd);
#else
	definepickitem(pom,fmtfilename(dd.ff_name),waspicked,ispicked);
	done = findnext(&dd);
#endif
      }
      /* -- attach it  */
    definepicklistarea(ifs,10,60,0,12,pom);
  }


char *current_directory(char *path)
{
   strcpy(path, "X:\\");      /* fill string with form of response: X:\ */
#ifdef QUICKC
   getcwd(path,80);
#else
   path[0] = 'A' + getdisk();    /* replace X with current drive letter */
   getcurdir(0, path+3);  /* fill rest of string with current directory */
#endif
   return(path);
}


char	     curdir[80];

void main(void)
{
  easytegl();
  easyout();
     /* -- for example just load the names  */
     /* -- of all the files in the current  directory */
  current_directory(curdir);
  getfilename(curdir,"\\*.*",FA_ARCH);
  teglsupervisor();
}



