  /*  ex_twdlg  */
  /*  example for using dialogs in tw windows  */

#include "tgdialog.h"
#include "twdlg.h"
#include "teglmain.h"

  unsigned char check   = TRUE;
  char str[21]   = "A string";
  int radio   = 3;



unsigned mydlgdone(imagestkptr ifs, msclickptr ms)
  {
    return twdlgclose(ifs,ms);
  }


void createdlg(void)
  { dlgctrlptr dlg;
    winframeptr wf;

    dlg = twdlginit(&wf,20,20,320,200);
      twsetheader(wf,"Using Dialogues in TW");
      dlgaddinputline(dlg,10,10,"Edit a string",str,20);
      dlgaddcheckbox(dlg,10,35,"A Check Box",&check);
      dlgaddradiobutton(dlg,10,55,"Radio 1",&radio);
      dlgaddradiobutton(dlg,10,75,"Radio 2",&radio);
      dlgaddradiobutton(dlg,10,95,"Radio 3",&radio);
      dlgaddbutton(dlg,120,120,"~O~K",mydlgdone);
      dlgsetenteritem(dlg,dlggetcurrent(dlg));
    twdlgdraw(wf);
  }



void main(int argc, char **argv)
{

  twsetglobalbuffers(FALSE);
  tweasystart();
  createdlg();
  teglsupervisor();
}



