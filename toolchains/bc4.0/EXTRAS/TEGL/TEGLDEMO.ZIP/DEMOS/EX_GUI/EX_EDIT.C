/* ex_edit.c */

#include "teglsys.h"

/* -- here are some related items to make string edits easier  */

  fontptr      fonttouse;

/* -- set the viewport to the frame coordinates. Most graphics functions  */
/* -- are viewport-relative, so we don't have to worry about calculating  */
/* -- exact screen coordinates.  */


void   frameview(imagestkptr  ifs)
  {
    setviewport(ifs->x,ifs->y,ifs->x1,ifs->y1,1);
  }


void   fullscreen(void)  /* -- return the viewport to full screen  */
  {
    setviewport(0,0,getmaxx(),getmaxy(),0);
  }

  /* -- a straight-forward funtion to allow editing of strings  */

  /* -- the frame  */
  /* -- whereat (frame relative)  */
			/* -- tell us what to enter  */
			/* -- the target string  */

void         stringinput(imagestkptr  ifs,  /* the frame */
             unsigned x, unsigned y,    /* where at (frame relative) */
             char *       mess,         /* tell us what to enter */
             char *       s,            /* target string */
			 unsigned char         len)  /* -- how many characters  */
  {   fontptr      font_;
      int      slen, mlen;
      int      dx1, dy1, dx2, dy2;   /* -- edit area  */

    prepareforupdate(ifs);   /* -- we are writing to the frame  */
    font_ = getteglfont();
    setteglfont(fonttouse);
    mlen = (int) tegltextwidth(mess);   /* -- length of prompt message  */
    slen = teglcharwidth('w') * len;   /* -- max len of input  */
    setcolor(BLACK);
    dx1 = x + mlen + 5;
    dy1 = y;
    dx2 = dx1 + slen;
    dy2 = (int) (y + teglcharheight());   /* -- for good measure  */
    frameview(ifs);
    rectangle(dx1 - 2,dy1 - 2,dx2 + 2,dy2 + 2);   /* -- make box around it  */
    outtextxy(x,y,mess);
    definestreditevent(ifs,dx1,dy1,dx2,dy2,len,BLACK,
      fonttouse,TRUE,s,allchars,strnoformat,strnoformat,nilunitproc);

    setteglfont(font_);
    fullscreen();
    commitupdate();   /* -- finished writing  */
  }

  /* ----------------------------------------------------------- */
  imagestkptr  ew;

   char         name[31]          = "Dr. Frank Stein";
   char         address[41]       = "123 Creepy Lane";
   char         city[21]          = "Transylvania";

  /* -- create the edit window.  */

void         createeditwindow(void)
  {
    unsigned x1 = 100; unsigned  y1 = 100;
    unsigned x2 = 450; unsigned y2 = 100;
    quickframe(&ew,&x1, &y1, &x2, &y2);

    prepareforupdate(ew);   /* -- hide mouse, uncover frame if covered  */
    frameview(ew);
    setfillstyle(SOLID_FILL,LIGHTGRAY);
    setteglfont(f8x12bol);
    bar(2,2,ew->x1 - ew->x - 4,teglcharheight() + 4);
    setcolor(BLACK);
    settextjustify(CENTER_TEXT,TOP_TEXT);
    outtextxy((ew->x1 - ew->x) / 2 - 2,4,"A Data-Entry Example");
    commitupdate();

    settextjustify(LEFT_TEXT,TOP_TEXT);
    fullscreen();
    setproportional(FALSE);
    stringinput(ew,10,30,"Name     ",name,30);
    stringinput(ew,10,50,"Address  ",address,40);
    stringinput(ew,10,70,"City     ",city,20);
  }

void main(int argc, char **argv)
{
  easytegl();
  easyout();
  fonttouse = f8x8bold;

  createeditwindow();

  teglsupervisor();
}


