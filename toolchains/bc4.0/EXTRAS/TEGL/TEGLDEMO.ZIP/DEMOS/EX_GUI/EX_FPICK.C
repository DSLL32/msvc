/*  ex_fpick.c	*/

#include "teglsys.h"
#include <string.h>


char fileselected[81];

/* function only called if file selected */

unsigned okselected(imagestkptr ifs, msclickptr ms)
  {
    strcpy(fileselected,(char*)getselectedfilename(ifs));
    dropstackimage(ifs);
    return 0;
  }


unsigned itemselected(imagestkptr ifs, msclickptr ms)
  {
    strcpy(fileselected,(char*)getselectedfilename(ifs));
      /* -- this is a double click on a pick item  */
    if (leftdoubleclick()) dropstackimage(ifs);
    return 0;
  }

void main(void)
{
  easytegl();
  easyout();

  openfileselection("","Selecting a file",okselected,itemselected);

  teglsupervisor();
}



