/*  ex_dlg5.c */
/*  trapping the enter and escape key  */

#include "teglsys.h"

dlgctrlptr dlg;


    unsigned char check   = TRUE;
    int radio   = 2;

void main(void)
{
  easytegl();
  easyout();

  dlg = dlginit(100,20,400,180);
    dlgaddlabel(dlg,60,5,"A Simple Dialogue");
    dlgaddcheckbox(dlg,20,25,"~C~heck box (for TRUE/FALSE)",&check);
    dlgaddradiobutton(dlg,20,45,"Radio button ~1~",&radio);
    dlgaddradiobutton(dlg,20,65,"Radio button ~2~",&radio);
    dlgaddradiobutton(dlg,20,85,"Radio button ~3~",&radio);
    dlgaddbutton(dlg,40,110,"~O~K",dlgclose);
      dlgsetenteritem(dlg,dlggetcurrent(dlg));
    dlgaddbutton(dlg,180,110,"~C~ancel",dlgclose);
      dlgsetescapeitem(dlg,dlggetcurrent(dlg));
  dlgdraw(dlg);

  teglsupervisor();
}



