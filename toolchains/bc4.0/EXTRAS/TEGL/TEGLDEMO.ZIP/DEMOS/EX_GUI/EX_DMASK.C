/* ex_dmask.c */

#include "teglsys.h"

unsigned dropit(imagestkptr ifs, msclickptr ms)
  {
    dropstackimage(ifs);
    return 0;
  }



void main(void)
{
  imagestkptr frame;

  easytegl();
  easyout();

  pushimage(10,10,300,150);
  shadowbox(10,10,300,150);
  fastrect(10,10,40,40,0);
  frame = stackptr;

  definemaskclickarea(frame,0,0,30,30,TRUE,dropit,
      MSCLICK,(maskptr)pointinghand,3,0);

  teglsupervisor();
}



