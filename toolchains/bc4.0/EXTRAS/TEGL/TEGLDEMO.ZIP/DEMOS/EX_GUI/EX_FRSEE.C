/* -- ex_frsee.c */

#include "teglsys.h"

imagestkptr  ifs;

void main(void)
{
  easytegl();
  easyout();
  pushimage(50,50,200,150);
  shadowbox(50,50,200,150);
  ifs = stackptr;
  teglsupervisor();
}

