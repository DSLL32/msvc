/*  ex_dlg4.c */
/*  string editing  */

#include "teglsys.h"

dlgctrlptr dlg;

   char str1[256]   = "This can be a very long string";
   char str2[21]   = "Many can be short";
   char str3[21]   = "Simplest string edit";

void main(void)
{
  easytegl();
  easyout();

  dlg = dlginit(50,20,500,180);
    dlgaddlabel(dlg,80,5,"String Editing");
    dlgaddline(dlg,20,30,180,32,"A Scrolling string",str1,20,255);
    dlgaddline(dlg,20,55,180,57,"No scroll",str2,20,20);
    dlgaddinputline(dlg,20,80,"Simple editing ",str3,20);
    dlgaddbutton(dlg,120,110,"~O~K",dlgclose);
  dlgdraw(dlg);
  teglsupervisor();
}



