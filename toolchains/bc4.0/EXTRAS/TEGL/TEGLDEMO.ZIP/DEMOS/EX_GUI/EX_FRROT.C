/* -- ex_frrot.c */

#include "teglsys.h"

unsigned cancelevent(imagestkptr  frame, msclickptr   mouse)
  {
    if (visualsquarebuttonpress(frame,mouse))
      {
          /* -- was TRUE, we release the button  */
        releasesquarebutton(frame,mouse);
          /* -- then dispose of the frame.  */
        dropstackimage(frame);
      }
    return 0;
  }

void main(void)
{
  imagestkptr  ifs;
  int      i;
  unsigned x1, y1, x2, y2;

  easytegl();
  easyout();
  setautorotate(TRUE);
  for (i = 1; i <= 25; i++)
    {
      x1 = i * 10;
      y1 = i * 10;
      x2 = 150;
      y2 = 100;
      quickframe(&ifs,&x1,&y1,&x2,&y2);
      definesquarebuttontext(ifs,0,0,70,30,5,5,"CANCEL",cancelevent);
    }
  teglsupervisor();
}

