/*  ex_dlg1.c  */
/*  a label and a button  */

#include "teglsys.h"

dlgctrlptr dlg;


void main(void)
{
  easytegl();
  easyout();

  dlg = dlginit(100,50,400,150);
    dlgaddlabel(dlg,60,20,"A Simple Dialogue");
    dlgaddbutton(dlg,120,60,"~O~K",dlgclose);
  dlgdraw(dlg);

  teglsupervisor();
}



