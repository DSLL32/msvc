/*  ex_mcur.c  */
/*  example for setmousemask  */

#include "teglsys.h"

void main(void)
{

  easytegl();
  easyout();
  setmousemask(pointinghand,0,0);
  setmousecolor(4);   /*  RED outline  */
  teglsupervisor();
}



