/* -- ex_keyms.c */

#include "teglsys.h"
  /* -- just press and release a button  */

unsigned pressit(imagestkptr  ifs, msclickptr   ms)
  {
    if (visualsquarebuttonpress(ifs,ms))
       releasesquarebutton(ifs,ms);
    return 0;
  }

imagestkptr  ifs;

void main(void)
{
  unsigned x1 = 100;
  unsigned y1 = 100;
  unsigned x2 = 300;
  unsigned y2 = 100;

  easytegl();
  easyout();
  quickframe(&ifs, &x1, &y1, &x2, &y2);

    /* -- define the square button BEFORE add a key trap  */
  definesquarebuttontext(ifs,10,10,130,35,5,5,"Press Me   F10",pressit);

    /* -- we use the msptr field of the imagestkptr, this was the  */
    /* -- key press is the same as a mouse click.  */
    /* -- the msptr is set to the most recently created mouse click area  */
  definelocalkeyclickarea(ifs,ifs->msptr,key_f10,FALSE,pressit);

  teglsupervisor();
}

