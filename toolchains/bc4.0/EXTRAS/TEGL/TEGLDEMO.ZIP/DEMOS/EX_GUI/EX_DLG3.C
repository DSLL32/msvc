/*  ex_dlg3.c  */
/*  pick list in a dialogue  */

#include "teglsys.h"

dlgctrlptr dlg;
dlgitemptr pl;

char pickstring[41]   = "";

void main(int argc, char **argv)
{

  easytegl();
  easyout();

  dlg = dlginit(100,20,400,180);
    dlgaddlabel(dlg,60,5,"A Simple Picklist");
    pl = dlgaddpicklist(dlg,80,30,0,4,pickstring);
      dlgaddpickitem(pl,"Item Number 1");
      dlgaddpickitem(pl,"Item Number 2");
      dlgaddpickitem(pl,"Item Number 3");
      dlgaddpickitem(pl,"Item Number 4");
      dlgaddpickitem(pl,"Item Number 5");
      dlgaddpickitem(pl,"Item Number 6");
    dlgaddbutton(dlg,120,110,"~O~K",dlgclose);
  dlgdraw(dlg);

  teglsupervisor();
}



