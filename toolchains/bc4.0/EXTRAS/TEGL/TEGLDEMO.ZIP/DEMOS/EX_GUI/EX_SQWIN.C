  /* -- ex_sqwin.c */

#include "teglsys.h"

  /* -- a control variable to make sure that only one instance of the  */
  /* -- format frame is displayed  */


unsigned char formatinstance   = FALSE;


unsigned formatevent(imagestkptr  frame, msclickptr   mouse)
  {
    if (visualsquarebuttonpress(frame,mouse))
      {
	releasesquarebutton(frame,mouse);
	setviewport(0,0,getmaxx(),getmaxy(),FALSE);
	errmess(getmaxx() / 4,getmaxy() / 4,"Function not compete!");
      }
    return 0;
  }


unsigned cancelevent(imagestkptr  frame, msclickptr   mouse)
  {
    if (visualsquarebuttonpress(frame,mouse))
      {
	releasesquarebutton(frame,mouse);
	dropstackimage(frame);
	formatinstance = FALSE;
      }
    return 0;
  }



unsigned diskevent(imagestkptr	frame, msclickptr mouse)
  { imagestkptr  ifs;
    unsigned x1 = 100;
    unsigned y1 = 100;
    unsigned x2 = 200;
    unsigned y2 = 100;

      /* -- if true then the button has been released  */
    if (visualsquarebuttonpress(frame,mouse))
      {
	  /* -- this will pop the button back up  */
	releasesquarebutton(frame,mouse);
	if (formatinstance)
	  {
	    setviewport(0,0,getmaxx(),getmaxy(),FALSE);
	    errmess(200,100,"The format window is open");
	    return 0;
	  }
	formatinstance = TRUE;
	setviewport(0,0,getmaxx(),getmaxy(),FALSE);   /* -- fullscreen	*/
	  /* -- upper corner  */
	quickframe(&ifs,&x1, &y1, &x2, &y2);   /* -- width & height  */
	setteglfont((fontptr)font14);
	  /* -- setting the viewport to the frame makes it easy  */
	  /* -- for outputting text and graphics.  */
	prepareforupdate(ifs);
	setviewport(ifs->x,ifs->y,ifs->x1,ifs->y1,TRUE);
	settextjustify(CENTER_TEXT,TOP_TEXT);
	outtextxy(100,20,"Format a disk?");
	settextjustify(LEFT_TEXT,TOP_TEXT);
	commitupdate();

	definesquarebuttontext(ifs,20,70,60,90,10,5,"OK",formatevent);
	definesquarebuttontext(ifs,110,70,180,90,10,5,"CANCEL",cancelevent);

      }
    return 0;
  }




void main(void)
{

  easytegl();
  easyout();
  setautorotate(TRUE);
  pushimage(0,9,39,49);
  definesquarebuttonclick(stackptr,0,0,39,39,6,4,(iconptr)imageDISK,diskevent);
  setteglfont((fontptr)f5x6norm);
  setcolor(BLACK);
  outtextxy(4,33,"Format");
  outtextxy(9,40,"Disk");
  teglsupervisor();
}



