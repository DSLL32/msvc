/* -- ex_pksel.c */

#include "teglsys.h"

char	     ispicked[40];

unsigned waspicked( imagestkptr ifs, msclickptr ms)
  {
    dropstackimage(ifs);
    pushimage(100,100,200,200);
    prepareforupdate(stackptr);
    shadowbox(100,100,200,200);
    setcolor(BLACK);
    outtextxy(110,110,ispicked);
    commitupdate();
    return 0;
  }

void   createpickframe(void)
  { optionmptr   pom; imagestkptr  ifs;
    unsigned x1 = 100; unsigned y1 = 100;
    unsigned x2 = 100; unsigned y2 = 100;

    quickframe(&ifs,&x1, &y1, &x2, &y2);
    pom = createpicklist((fontptr)f8x8bold);
    setpicklistmargin(pom,12);
    definepickitem(pom,"Item 1",waspicked,ispicked);
    definepickitem(pom,"Item 2",waspicked,ispicked);
    definepickitem(pom,"Item 3",waspicked,ispicked);
    definepicklistarea(ifs,10,10,2,5,pom);
  }

void main(void)
{
  easytegl();
  easyout();
  createpickframe();
  teglsupervisor();
}



