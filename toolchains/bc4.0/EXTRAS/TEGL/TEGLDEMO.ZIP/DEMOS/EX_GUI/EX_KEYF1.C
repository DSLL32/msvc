/* -- key1.c */
/* traps for f1 key press */

#include "teglsys.h"

  /* -- as of release 2.1 all keystoke events have to be associated with  */
  /* -- a frame. Here we create a small, invisible, immovable frame that  */
  /* -- can be used with all defineglobalkeyclickarea.  */

imagestkptr  dumifs;

void         setupdummyframe(void)
  {
    pushemptyimage(0,0,10,10);
    dumifs = stackptr;
    setframemobility(dumifs,FALSE);
    setframeautorotate(dumifs,FALSE);
  }

  /* -- drop any frame from a square button  */

unsigned         dropframe(imagestkptr  ifs, msclickptr   ms)
  {
    if (visualsquarebuttonpress(ifs,ms))
      dropstackimage(ifs);
    return 0;
  }

  /* -- event to call when the F1 key is pressed, standard is help  */

unsigned         f1pressed(imagestkptr  ifs, msclickptr   ms)
  { imagestkptr  hfs;
    unsigned x1 = 100;
    unsigned y1 = 100;
    unsigned x2 = 300;
    unsigned y2 = 100;

    quickframe(&hfs, &x1, &y1, &x2, &y2);
    definesquarebuttontext(hfs,135,70,165,95,5,5,"OK",dropframe);
    prepareforupdate(hfs);
    outtgtextxy(hfs->x + 10,hfs->y + 10,BLACK,BLACK,"HELP key pressed.");
    commitupdate();
    return 0;
  }

void main(void)
{
  easytegl();
  easyout();

    /* -- install the global key click event for the F1 key  */
    /* -- no frame or mouse click is passed since this is independant of  */
    /* -- all windows.  */

  setupdummyframe();
  defineglobalkeyclickarea(dumifs,NULL,key_f1,FALSE,f1pressed);

  teglsupervisor();
}



