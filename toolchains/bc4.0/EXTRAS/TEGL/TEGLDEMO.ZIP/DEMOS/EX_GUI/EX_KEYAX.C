/* -- ex_keyax.c  */
/* global trap for ALT-X */

#include "teglsys.h"
imagestkptr  dumifs;

void         setupdummyframe(void)
  {
    pushemptyimage(0,0,10,10);
    dumifs = stackptr;
    setframemobility(dumifs,FALSE);
    setframeautorotate(dumifs,FALSE);
  }

  /* -- drop any frame from a square button  */

unsigned  dropframe(imagestkptr  ifs, msclickptr   ms)
  {
    if (visualsquarebuttonpress(ifs,ms))
      dropstackimage(ifs);
    return 0;
  }


unsigned  dropframeexit(imagestkptr  ifs, msclickptr   ms)
  {
    if (visualsquarebuttonpress(ifs,ms))
      {
        dropstackimage(ifs);
        abortexit("");
      }
    return 0;
  }

unsigned  altxpressed(imagestkptr  ifs, msclickptr   ms)
  { imagestkptr  xfs;
    unsigned x1 = 100;
    unsigned y1 = 100;
    unsigned x2 = 300;
    unsigned y2 = 100;

    quickframe(&xfs, &x1, &y1, &x2, &y2);

    prepareforupdate(xfs);
    outtgtextxy(xfs->x + 80,xfs->y + 10,BLACK,BLACK,"EXIT Program?");
    commitupdate();
    definesquarebuttontext(xfs,100,70,130,95,5,5,"OK",dropframeexit);
    definesquarebuttontext(xfs,150,70,210,95,5,5,"Cancel",dropframe);
    return 0;
  }

  /* -- event to call when the F1 key is pressed, standard is help  */


unsigned         f1pressed(imagestkptr  ifs, msclickptr   ms)
  { imagestkptr  hfs;
    unsigned x1 = 100;
    unsigned y1 = 100;
    unsigned x2 = 300;
    unsigned y2 = 100;

    quickframe(&hfs, &x1, &y1, &x2, &y2);
    prepareforupdate(hfs);
    definesquarebuttontext(hfs,135,70,165,95,5,5,"OK",dropframe);
    commitupdate();
    outtgtextxy(hfs->x + 10,hfs->y + 10,BLACK,BLACK,"HELP key pressed.");
    return 0;
  }

void main(void)
{
  easytegl();
  easyout();
    /* -- install the global key click event for the F1 key  */
    /* -- no frame or mouse click is passed since this is independant of  */
    /* -- all windows.  */

  setupdummyframe();
  defineglobalkeyclickarea(dumifs,NULL,key_f1,FALSE,f1pressed);
  defineglobalkeyclickarea(dumifs,NULL,key(sk_altshift,key_x),
        FALSE,altxpressed);

  teglsupervisor();
}



