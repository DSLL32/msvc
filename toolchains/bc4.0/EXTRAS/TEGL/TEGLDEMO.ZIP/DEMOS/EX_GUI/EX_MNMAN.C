  /* -- menu3.c  */

#include "teglsys.h"
#include <string.h>
#include <stdlib.h>

char *itos(int i)
  {
    static char 	s[25];

    itoa(i,s,10);
    return s;
  }


unsigned exitoption( imagestkptr ifs, msclickptr ms)
  {
    abortexit("");
    return 0;
  }

optionmptr   omfile;
     optionmptr   omopen;
     int      i;

void main(void)
{

  char	fn[20];
  easytegl();
  easyout();

  omopen = createoptionmenu((fontptr)f8x8bold);
    for (i = 1; i <= 50; i++) {
      strcpy(fn," file ");
      strcat(fn,itos(i));
      defineoptions(omopen,fn,(unsigned char)(random(2) == 1),nilunitproc);
      }

  omfile = createoptionmenu((fontptr)f8x12bol);
  defineoptionssub(omfile," ~O~pen ",TRUE,omopen);
  defineoptions(omfile,"-",FALSE,nilunitproc);
  defineoptions(omfile," E~x~it ",TRUE,exitoption);
  setteglfont((fontptr)f8x12bol);
  createbarmenu(0,0,getmaxx());
  outbaroption(" ~F~ile ",omfile);

  teglsupervisor();
}



