/* -- twmenu.c */

#include "teglsys.h"

winframeptr  wf;

/* -- RedrawIt is a standard event-handler. It is called after  */
/* -- the window standard items have been drawn.  */

unsigned redrawit(imagestkptr  ifs, msclickptr	 ms)
  { winframeptr  wf;

    wf = findwinframe(ifs);
    twputpict(wf,10,10,(iconptr)imageSYSTEM,BLACK);
    return 0;
  }

  /* -- this is the close event for the window.  */

unsigned closeit(imagestkptr  ifs, msclickptr	ms)
  { winframeptr  wf;
      int      i;
      int      color;

    wf = findwinframe(ifs);
    prepareforupdate(ifs);
      /* -- prove that we are going through here  */
    color = 0;
    for (i = 0; i <= 100; i++)
      {
	twsetfillcolor(wf,(unsigned char)color);
	twclear(wf);
	color++;
	if (color > 15) color = 0;
      }
    commitupdate();
      /* -- then call close to actually dispose of the window  */
    twclose(wf);
    return 0;
  }

void main(void)
{
  tweasystart();

  twinit(&wf,100,50,300,190);
    twsetheader(wf,"Window with a local menu");
    twsetmaximize(wf,FALSE);   /* -- no minimize/maximize */
    twsetredraw(wf,redrawit);
    twsetcloseevent(wf,closeit);
    twmenuitem(wf,"~F~ile",TRUE);
	/* -- NilUnitProc is just a dummy event-handler, use it  */
	/* -- as a place holder when you are just building an interface  */
      twsubmenuitem(wf,"~O~pen",TRUE,nilunitproc);
      twsubmenuitem(wf,"-",FALSE,nilunitproc);
      twsubmenuitem(wf,"E~x~it",TRUE,closeit);
      twmenuitem(wf,"~D~raw",TRUE);
      twsubmenuitem(wf,"~A~rc",FALSE,nilunitproc);
      twsubmenuitem(wf,"~C~ircle",FALSE,nilunitproc);
      twsubmenuitem(wf,"~E~llipse",FALSE,nilunitproc);
      twsubmenuitem(wf,"~R~ectangle",FALSE,nilunitproc);
  twdrawwindowframe(wf);

  teglsupervisor();
}



