/*  ex_dlg6.c  */
/*  using a dispatcher  */

#include "teglsys.h"

    unsigned char check   = FALSE;
    int radio   = 2;
    char pickitem[41]   = "I must be changed";

dlgitemptr pl;
dlgitemptr pc;   /* -- picklist item edit  */


unsigned mydispatcher(imagestkptr ifs, msclickptr ms)
  { dlgctrlptr dlg;
      int mode;

      /* -- we can find the dialogue using the ifs  */
    dlg = dlgfind(ifs);
    mode = dlggetmode(dlg);

      /* -- An important use for the dispatcher is that  */
      /* -- you can update one item from the dialogue.  */
      /* -- Here we update the edit field that points to  */
      /* -- the same string as the pick list. Note we are  */
      /* -- calling the dialogue item's action function  */
    if (dlggetcurrent(dlg) != pc)
      {
	pc->action(pc,DLGCAPTURE);
	pc->action(pc,DLGREDISPLAY);
      }

      /* was a double click on the picklist, here we */
      /* just flag it to close, a real dialogue would do */
      /* some other processing. */

    if ((dlggetcurrent(dlg)==pl) && (dlg->doubleclick))
      dlgsetmode(dlg,DLGDISPOSE);

      /* -- here we check to see if either the enter  */
      /* -- or escape key items were selected. If so  */
      /* -- we just set the mode to dispose. These are  */
      /* -- only checking for the key press.  */
    if ((mode == DLGENTERKEY) || (mode == DLGESCAPEKEY))
      dlgsetmode(dlg,DLGDISPOSE);

      /* -- here we check to see if the dialogue  */
      /* -- is about to be disposed of. This is   */
      /* -- not allowed unless the check box has  */
      /* -- been ticked.  */
    if (dlggetmode(dlg) == DLGDISPOSE)
      if ((!check))
	dlgsetmode(dlg,DLGCLICK);
    return 0;
  }


dlgctrlptr dlg;


void main(void)
{
   /**/


  easytegl();
  easyout();

  dlg = dlginit(100,20,540,190);
    dlgaddlabel(dlg,60,5,"A Dialogue with Dispatcher");
    dlgaddcheckbox(dlg,20,25,"O~K~ to close dialogue",&check);
    dlgaddradiobutton(dlg,20,45,"Radio button ~1~",&radio);
    dlgaddradiobutton(dlg,20,65,"Radio button ~2~",&radio);
    dlgaddradiobutton(dlg,20,85,"Radio button ~3~",&radio);
    dlgaddline(dlg,280,5,280,25,"Pick item:",pickitem,15,40);
      pc = dlggetcurrent(dlg);
    pl = dlgaddpicklist(dlg,280,55,0,5,pickitem);
      dlgaddpickitem(pl,"Pick choice 1");
      dlgaddpickitem(pl,"Pick choice 2");
      dlgaddpickitem(pl,"Pick choice 3");
      dlgaddpickitem(pl,"Pick choice 4");
      dlgaddpickitem(pl,"Pick choice 5");
    dlgaddbutton(dlg,40,110,"~O~K",dlgclose);
      dlgsetenteritem(dlg,dlggetcurrent(dlg));
    dlgaddbutton(dlg,140,110,"~C~ancel",dlgclose);
      dlgsetescapeitem(dlg,dlggetcurrent(dlg));
    dlgsetdispatcher(dlg,mydispatcher);
  dlgdraw(dlg);

  teglsupervisor();
}



