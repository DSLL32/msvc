  /* -- twwin2.c */

#include "teglsys.h"

winframeptr  wf;




void main(void)
{
  tweasystart();

  twsetglobalbuttonsize(24,12);
  twsetglobalslidersize(36,8);
  twsetglobalresizearea(50,20);
  twsetheaderfont(f8x12bol);
  twinit(&wf,100,50,300,170);
    twsetheader(wf,"Common Window characteristics");
    twsetwindowstyle(wf,stdbox);
    twsetupdownslider(wf,TRUE);
    twsetleftrightslider(wf,TRUE);
  twdrawwindowframe(wf);

  teglsupervisor();
}



