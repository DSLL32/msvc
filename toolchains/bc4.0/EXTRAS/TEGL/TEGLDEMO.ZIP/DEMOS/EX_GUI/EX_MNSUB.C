  /* -- menu2.c */

#include "teglsys.h"


unsigned exitoption(imagestkptr  ifs, msclickptr   ms)
  {
    abortexit("");
    return 0;
  }


     fontptr	  menufont;   /* -- by setting the font into a pointer we can  */
			   /* -- more easily change our selection of the font */
			   /* -- to use.  */
     optionmptr   omfile;
     optionmptr   omfile2;
     optionmptr   omfile3;


void main(void)
{


  easytegl();
  easyout();

  menufont = (fontptr)f8x12bol;

  omfile3 = createoptionmenu(menufont);
    defineoptions(omfile3," ~T~o floppy ",TRUE,nilunitproc);
    defineoptions(omfile3," ~F~rom floppy ",TRUE,nilunitproc);

  omfile2 = createoptionmenu(menufont);
    defineoptions(omfile2," ~F~ormat ",FALSE,nilunitproc);
    defineoptions(omfile2," ~D~elete ",FALSE,nilunitproc);
    defineoptionssub(omfile2," ~C~opy ",TRUE,omfile3);

  omfile = createoptionmenu(menufont);
  defineoptions(omfile," ~O~pen ",TRUE,nilunitproc);
  defineoptionssub(omfile," ~D~os functions ",TRUE,omfile2);
  defineoptions(omfile,"-",FALSE,nilunitproc);
  defineoptions(omfile," E~x~it ",TRUE,exitoption);

  setteglfont(menufont);
  createbarmenu(0,0,getmaxx());
  outbaroption(" ~F~ile ",omfile);

  teglsupervisor();
}



