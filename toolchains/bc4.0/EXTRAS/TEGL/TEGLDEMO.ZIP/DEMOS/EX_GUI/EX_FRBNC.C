/* -- ex_frbnc.c */

#include "teglsys.h"

imagestkptr  ifs;

unsigned cancelevent(imagestkptr  frame, msclickptr   mouse)
  {
      /* -- this will press the button down and if the mouse button  */
      /* -- is release WHILE it is over the button it will return  */
      /* -- TRUE. If the mouse cursor passes out of the button without  */
      /* -- being released then it will return FALSE and  */
      /* -- releasesquarebutton will be called automatically.  */
    if (visualsquarebuttonpress(frame,mouse))
      {
          /* -- was TRUE, we release the button  */
        releasesquarebutton(frame,mouse);
          /* -- then dispose of the frame.  */
        dropstackimage(ifs);
      }
    return 0;
  }

void main(void)
{
  easytegl();
  easyout();
  pushimage(50,50,200,150);
  shadowbox(50,50,200,150);
  ifs = stackptr;
  definesquarebuttontext(ifs,0,0,70,30,5,5,"CANCEL",cancelevent);
  teglsupervisor();
}



