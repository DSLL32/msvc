  /* -- ex_sqclk.c */

#include "teglsys.h"
#include <stdlib.h>


unsigned shownumber( imagestkptr frame, msclickptr mouse )
  {
    char s[25];
      /* -- if true then the button has been released  */
    if (visualsquarebuttonpress(frame,mouse))
      {
	  /* -- this will pop the button back up  */
	releasesquarebutton(frame,mouse);
	prepareforupdate(frame);
	setviewport(frame->x,frame->y,frame->x1,frame->y1,TRUE);
	setfillstyle(SOLID_FILL,WHITE);
	bar(5,110,210,130);
	setteglfont((fontptr)f8x12bol);
	  /* -- the mouse pointer contains what clicknumber it was  */
	  /* -- assigned to.  */
setcolor(BLACK);
	outtextxy(5,112,"Button ");
	itoa(mouse->clicknumber,s,10);
	outtextxy(70,112,s);
	commitupdate();
      }
    return 0;
  }


void	     buttonbunch(void)
{ int	   i, xd, yd;
    imagestkptr  ifs;
    unsigned x1 = 100;
    unsigned y1 = 100;
    unsigned x2 = 222;
    unsigned y2 = 140;
    char s[25];

    setviewport(0,0,getmaxx(),getmaxy(),FALSE);
    quickframe(&ifs,&x1,&y1,&x2,&y2);
    xd = 0; yd = 0;
    for (i = 1; i <= 50; i++)
      {
	  /* -- as we define each button we put its clicknumber on it */
	  /* -- note that MsClickCount would only be the correct on return */
	  /* -- so we add one to it.  */
	setteglfont((fontptr)f7x7bold);
	itoa(+ifs->msclickcount + 1,s,10);
	definesquarebuttontext(ifs,xd,yd,xd + 20,yd + 20,3,8,s,shownumber);
	xd = xd + 22;
	if (xd > 200)
	  {
	    xd = 0;
	    yd = yd + 22;
	  }
      }
  }



void main(void)
{

  easytegl();
  easyout();
  buttonbunch();
  teglsupervisor();
}



