/* -- twsim.c */

#include "teglsys.h"

winframeptr  wf;


void main(void)
{
  tweasystart();

  twinit(&wf,100,50,300,150);
  twsetheader(wf,"A Simple Window");
  twdrawwindowframe(wf);

  teglsupervisor();
}



