/* -- ex_sqbut.c */

#include "teglsys.h"

imagestkptr  ifs;


unsigned cancelevent(imagestkptr  frame, msclickptr   mouse)
  {
      /* -- if true then the button has been released  */
    if (visualsquarebuttonpress(frame,mouse))
      {
	  /* -- this will pop the button back up  */
	releasesquarebutton(frame,mouse);
	  /* -- and dispose of the frame.  */
	dropstackimage(ifs);
      }
    return 0;
  }


void main(void)
{

  easytegl();
  easyout();
  pushimage(50,50,200,150);
  shadowbox(50,50,200,150);
  ifs = stackptr;
  definesquarebuttontext(ifs,30,35,120,65,5,5,"PRESS ME",cancelevent);
  teglsupervisor();
}



