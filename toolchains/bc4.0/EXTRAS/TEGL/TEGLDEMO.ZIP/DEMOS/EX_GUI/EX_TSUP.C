#include "teglsys.h"

void main(void)
  {
    easytegl();
    easyout();
    /* all the setup code for menus etc goes first */
    teglsupervisor();
  }


