/* -- ex_key0.c */

#include "teglsys.h"
#include <conio.h>

  /* -- this event is called everytime a key is pressed that has not  */
  /* -- been trapped for. It just displays the character in the upper  */
  /* -- left corner of window.	*/


unsigned akeywaspressed(imagestkptr  ifs, msclickptr   ms)
  { char	 c;

    c = getch();
      /* -- we assume the viewport is (0,0,maxx(),maxy())  */
    setfillstyle(SOLID_FILL, WHITE);
    bar(ifs->x + 1,ifs->y + 2,ifs->x + 30,ifs->y + 30);
    outtgtextxy(ifs->x + 2,ifs->y + 2,BLACK,BLACK,"%c",c);
    return 0;
  }

imagestkptr  ifs;

void main(int argc, char **argv)
{
  unsigned x1 = 100;
  unsigned y1 = 100;
  unsigned x2 = 300;
  unsigned y2 = 100;

  easytegl();
  easyout();
  quickframe(&ifs, &x1, &y1, &x2, &y2);
  definelocalkeyclickarea(ifs,NULL,0,FALSE,akeywaspressed);
  teglsupervisor();
}



