/* -- ex_sqflt.c */

#include "teglsys.h"


unsigned disk35event(imagestkptr  frame, msclickptr   mouse)
  {
      /* -- if true then the button has been released  */
    if (visualsquarebuttonpress(frame,mouse))
      {
	  /* -- this will pop the button back up  */
       releasesquarebutton(frame,mouse);
      }
    return 0;
  }


unsigned diskevent(imagestkptr	frame, msclickptr   mouse)
  {
      /* -- if true then the button has been released  */
    if (visualsquarebuttonpress(frame,mouse))
      {
	  /* -- this will pop the button back up  */
      releasesquarebutton(frame,mouse);
      }
    return 0;
  }

void main(void)
{
  easytegl();
  easyout();
  pushimage(0,9,39,49);
  definesquarebuttonclick(stackptr,0,0,39,39,5,5,
         (iconptr)imageDISK,diskevent);
  pushimage(0,49,39,89);
  definesquarebuttonclick(stackptr,0,0,39,39,5,5,
         (iconptr)imageDISK35,disk35event);

  teglsupervisor();
}



