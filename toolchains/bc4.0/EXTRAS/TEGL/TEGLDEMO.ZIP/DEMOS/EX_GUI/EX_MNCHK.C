  /* -- menu4.c */

#include "teglsys.h"

unsigned exitoption(imagestkptr  ifs, msclickptr   ms)
  {
    abortexit("");
    return 0;
  }


     fontptr	  menufont;
     optionmptr   omfile;


    char  fullpath	= TRUE;


void main(void)
{


  easytegl();
  easyout();

  menufont = (fontptr)f8x12bol;



  omfile = createoptionmenu(menufont);
  defineoptions(omfile," ~O~pen ",TRUE,nilunitproc);
  defineoptionscheck(omfile," ~F~ull path ",TRUE,nilunitproc,&fullpath);
  defineoptions(omfile,"-",FALSE,nilunitproc);
  defineoptions(omfile," E~x~it ",TRUE,exitoption);

  setteglfont(menufont);
  createbarmenu(0,0,getmaxx());
  outbaroption(" ~F~ile ",omfile);

  teglsupervisor();
}



