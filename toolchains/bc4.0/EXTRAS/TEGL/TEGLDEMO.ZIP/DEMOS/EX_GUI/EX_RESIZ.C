/* ex_resiz.c  */

#include "teglsys.h"

/* this program illustrates how to define a mouse click area, specifically  */
/* a resize click area and how to associate an event that will be called  */
/* by the supervisor whenever the frame is resized.  */


  /* -- Just draws a frame with a rectangle in the corner which will  */
  /* -- be the resize mouse click area.  */

void drawwinframe(imagestkptr  ifs);

void  frameit(imagestkptr  ifs)
  {
    setfillstyle(SOLID_FILL,WHITE);
    setviewport(0,0,getmaxx(),getmaxy(),FALSE);
    bar(ifs->x,ifs->y,ifs->x1,ifs->y1);
    setcolor(BLACK);
    rectangle(ifs->x,ifs->y,ifs->x1,ifs->y1);
    rectangle(ifs->x1 - 10,ifs->y1 - 10,ifs->x1 - 1,ifs->y1 - 1);
  }


  /* -- event that is called automatically after a resize mouse click area  */
  /* -- is selected and the frame is resized.  */


unsigned redrawwinframe(imagestkptr  ifs, msclickptr   ms)
  {
    drawwinframe(ifs);
    return 0;
  }

  /* -- Draw the window frame and define the the mouse click area for the  */
  /* -- resizing action  */


void drawwinframe(imagestkptr  ifs)
  { int     mx, my;

    frameit(ifs);
    resetmouseclicks(ifs,NULL);
    mx = ifs->x1 - ifs->x;
    my = ifs->y1 - ifs->y;

      /* -- set framesize constraints  */

    defineresizeminmax(ifs,100,100,400,200);
      /* -- set the mouse click area  */
    defineresizeclickarea(ifs,mx - 10,my - 10,mx,my,redrawwinframe);
  }

imagestkptr  window;

void main(int argc, char **argv)
{

  easytegl();	/* -- standard set up  */
  easyout();
  pushimage(100,100,300,200);	/* -- save background  */
  window = stackptr;   /* -- get the pointer  */
  drawwinframe(window);   /* -- draw it the first time	*/
  teglsupervisor();   /* -- give it to the supervisor  */
}
