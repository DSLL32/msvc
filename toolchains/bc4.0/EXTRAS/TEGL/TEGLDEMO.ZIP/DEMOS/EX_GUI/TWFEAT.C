/* -- twfeat.c */

#include "teglsys.h"

winframeptr  wf;

  /* -- RedrawIt is a standard event-handler. It is called after  */
  /* -- the window standard items have been drawn.  */

unsigned redrawit(imagestkptr  ifs, msclickptr   ms)
  { winframeptr  wf;

    wf = findwinframe(ifs);
    twputpict(wf,1,1,imageSYSTEM,BLACK);
    return 0;
  }

  /* -- this is the close event for the window.  */


unsigned closeit(imagestkptr  ifs, msclickptr   ms)
  { winframeptr  wf;
      int      i;
      int      color;

    wf = findwinframe(ifs);
    prepareforupdate(ifs);
      /* -- prove that we are going through here  */
    color = 0;
    for (i = 0; i <= 100; i++)
      {
        twsetfillcolor(wf,color);
        twclear(wf);
        color++;
        if (color > 15) color = 0;
      }
    commitupdate();
      /* -- then call close to actually dispose of the window  */
    twclose(wf);
    return 0;
  }

void main(void)
{
  tweasystart();

  twinit(&wf,100,50,300,170);
    twsetheader(wf,"Window characteristics");
    twsetthickness(wf,6);
    twsetfillcolor(wf,GREEN);
    twsetbordercolor(wf,BLACK);
    twsetwinframecolors(wf,CYAN,MAGENTA);
    twsetmaximize(wf,FALSE);   /* -- no minimize/maximize */
    twsetwindowstyle(wf,bevbox);
    twsetredraw(wf,redrawit);
    twsetcloseevent(wf,closeit);
  twdrawwindowframe(wf);

  teglsupervisor();
}

