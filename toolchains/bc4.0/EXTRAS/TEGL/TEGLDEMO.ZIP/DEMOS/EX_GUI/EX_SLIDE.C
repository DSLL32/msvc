/* ex_slide.c */
/*  Demonstrates how to place a slider in a frame.	     */

#include "teglsys.h"
#include "stdlib.h"             /* iota */

imagestkptr  ifs;
sliderptr    sldptr;

  /* -- slideaction is called whenever the slider is moved  */


unsigned slideaction(imagestkptr  ifs, msclickptr   ms)
  { unsigned long      dx, dy;	 /* -- delta  */
    char s[20];

    getsliderrelative(sldptr,100l,&dx,0l,&dy);	 /* -- ignore y  */
    setviewport(ifs->x + 1,ifs->y + 60,ifs->x1 - 1,ifs->y1 - 1,TRUE);

      /* -- clear lower part of frame  */
    prepareforupdate(ifs);
    setfillstyle(SOLID_FILL,WHITE);
    bar(0,0,1000,1000);   /* -- let clip do the work  */
    outtextxy(10,10,itoa((int)dx,s,10));
     /* -- restore to full screen  */
    setviewport(0,0,getmaxx(),getmaxy(),FALSE);  
    commitupdate();
    return 0;
  }


void  framewithslider(void)
  {
      /* -- push an image an save the frame pointer, then clear it */
    pushimage(10,10,310,190);
    ifs = stackptr;

      /* -- set the viewport over the frame so bar and rectangle will  */
      /* -- be relative to the frame  */
    setviewport(10,10,310,190,FALSE);
    setfillstyle(SOLID_FILL,WHITE);
    bar(0,0,300,180);
    setcolor(BLACK);
    rectangle(0,0,300,180);
    setfillstyle(SOLID_FILL,LIGHTGRAY);
    bar(50,0,200,20);
    setcolor(BLACK);
    rectangle(50,0,200,20);

   /* -- definesliderarea is FRAME RELATIVE, the first 4 coordinates define  */
   /* -- the slider thumb (the moveable part) and the second 4 coordinates  */
   /* -- define the entire slider area (its scope)  */
   /* -- slider thumb  */
   /* -- slider bar  */        /* -- event to call when moved  */
    definesliderarea(ifs,50,0,100,20,50,0,200,20,slideaction);  

   /* -- save the slider pointer  */
    sldptr = getlastsliderdef(ifs);

   /* -- only AFTER drawing the slider then defining it do we draw the  */
   /* -- thumb. During define is when the slider captures the screen image */
   /* -- of the slider area.  */

    setfillstyle(SOLID_FILL,RED);
    bar(50,0,100,20);	/* -- note same coordiantes as slider thumb above.  */
    setcolor(BLACK);
    rectangle(50,0,100,20);
    putpict(ifs->x + 65,ifs->y + 5,(iconptr)imageSLIDER2,BLACK);
    setviewport(0,0,getmaxx(),getmaxy(),FALSE);   /* --restore viewport  */
  }


void main(int argc, char **argv)
{
  easytegl();
  easyout();
  framewithslider();
  teglsupervisor();
}
