/* ex_nobuf.c */

#include "teglsys.h"

winframeptr wf;

void main(void)
{

  twsetglobalbuffers(FALSE);
  setautorotate(TRUE);
  tweasystart();

  twinit(&wf,10,10,300,120);
    twsetheader(wf,"Unbuffered ONE");
  twdrawwindowframe(wf);

  twinit(&wf,50,50,400,180);
    twsetheader(wf,"Unbufferd TWO");
  twdrawwindowframe(wf);

  teglsupervisor();
}



