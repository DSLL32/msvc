/*  ex_defms.c  */
/*  example for define mouse click area  */

#include "teglsys.h"

int color   = 0;


unsigned iwasclickedon(imagestkptr ifs, msclickptr ms)
  {
    prepareforupdate(ifs);
    fastbar(ifs->x + 1,ifs->y + 1,ifs->x1 - 3,ifs->y1 - 3,color);
    color = color + 1;
    if (color > fggetmaxcolor()) color = 0;
    commitupdate();
    waitforuserrelease();
    return 0;
  }


void main(void)
{
  easytegl();
  easyout();

  pushimage(10,10,300,150);
  shadowbox(10,10,300,150);

  definemouseclickarea(stackptr,1,1,287,137,TRUE,iwasclickedon,MSCLICK);

  teglsupervisor();
}



