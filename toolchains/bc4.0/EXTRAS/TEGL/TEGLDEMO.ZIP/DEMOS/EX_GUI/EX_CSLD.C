/*  ex_clsd.pas  */
/*  example for create slider  */

#include "teglsys.h"

sliderptr myslider;
int position;


void pressrelease(imagestkptr ifs, msclickptr ms)
  {
    if (visualsquarebuttonpress(ifs,ms))
      releasesquarebutton(ifs,ms);
  }

  /* -- called when slider thumb moved.  */

unsigned slideaction(imagestkptr ifs, msclickptr ms)
  {
    return 0;
  }

  /* -- called when left button pressed  */

unsigned slideleft(imagestkptr ifs, msclickptr ms)
  { _TGLONG_ dx, dy;

    pressrelease(ifs,ms);
    getsliderrelative(myslider,100,(unsigned _TGLONG_ *)&dx,0L,(unsigned _TGLONG_ *)&dy);
    if (dx < 10)
      dx = 0;
    else
      dx = dx - 10L;
    if (dx < 0) dx = 0;
    setsliderrelative(myslider,100,dx,0L,dy);
    return 0;
  }

  /* -- called when right button pressed.  */

unsigned slideright(imagestkptr ifs, msclickptr ms)
  { unsigned long dx, dy;

    pressrelease(ifs,ms);
    getsliderrelative(myslider,100,&dx,0L,&dy);
    dx = dx + 10L;
    if (dx > 100L) dx = 100L;
    setsliderrelative(myslider,100,dx,0L,dy);
    return 0;
  }


void main(void)
{
  easytegl();
  easyout();
  pushimage(10,10,400,190);
  shadowbox(10,10,400,190);
  myslider = createslider(stackptr,
		10,155,380,175,
		20,20,20,
		LIGHTGRAY,BLACK,1,
		imageARROWLF,imageARROWRT,
		slideaction,slideleft,slideright);

  teglsupervisor();
}



