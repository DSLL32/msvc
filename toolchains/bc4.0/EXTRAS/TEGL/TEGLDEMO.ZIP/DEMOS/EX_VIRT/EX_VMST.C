  /*  ex_vmst.c  */

#include <stdio.h>
#include <conio.h>
#include "virtmem.h"
#include "vmxms.h"
unsigned long umfree;
unsigned long myheapsize;

void main(int argc, char **argv)
{

    /* -- a small but usable virtual heap  */
  myheapsize = 1024L * 64L;
    /* -- use upper memory if we can!  */
  if (xmminstalled())
    {
      if (uppermemorybytesavailable(&umfree) == 0)
	{
	  if (umfree > myheapsize)
	    myheapsize = umfree;
	}
    }
  if ((umfree == myheapsize))
    {
      printf("Upper memory is available.\n");
      printf("Will use %lu bytes of upper memory\n",umfree);
      vmuseumb(TRUE);
    }
  else vmuseumb(TRUE);

  setvirtualheapsize(myheapsize);
  initteglheap();
  printf("Virtual Heap Initialized!\n");
  printf("Requested heap: %lu\n",myheapsize);
  printf("Actual heap   : %lu\n",vmmemavail());
  getch();
}



