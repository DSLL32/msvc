
  /*  -- vmarray.c  */
  /*  -- example of how to allocate a bunch of memory blocks on the  */
  /*  -- virtual heap, initialize, access and then dispose of them.  */

#include "virtmem.h"
#include "stdio.h"
#include "conio.h"

  /* -- change these constants to larger values  */


  #define maxarrays    16
  #define bounds       4095


  typedef int intarray[bounds+1];

/*   typedef intarray     *intarrayptr; */


  intarray  *curarray;
  virtualptr   vparray[maxarrays+1];

  int      i, i2;


void         pressakey(void)
  {
    printf("press a key ...");
    if (getch() == ' ') ;
    printf("\n");
  }


void main(void)
{


  setstandardheapsize(32000);
  initteglheap();

  printf("page area is: %lu\n",vmmaxavail());

    /* -- allocate and initialize the arrays  */

  for (i = 0; i <= maxarrays; i++)
    {
      printf("allocating and initilizing array %d\n",i);
	/* -- allocate  */
      vpgetmem(&vparray[i],sizeof(intarray));
	/* -- set an access to use the memory. This places a soft lock  */
	/* -- on the memory block so that it must remain in the page  */
        /* -- area.  */
      vpaccess(vparray[i],&(void*)curarray);
	/* -- set all values to the array counter  */

      for (i2 = 0; i2 <= bounds; i2++)
	(*curarray)[i2] = i;


        /* -- remove the access (soft lock) so that the memory block  */
        /* -- can be paged out if the virtual page area fills up.  */
      vpunuse(vparray[i]);
    }

  printf("free mem in page area is %lu\n",vmmemavail());
  printf("flushing page area\n");
  if (vmpageout(600000L)) ;
  printf("free mem in page area is now %lu\n",vmmemavail());
  pressakey();


    /* -- now access each array and display some elements to show it  */
    /* -- has been read in ok.  */

  for (i = 0; i < maxarrays; i++)
    {
      printf("accessing array %d\n",i);
	/* -- to access the memory block again we access it  */
	/* -- so it is moved into the page area (if it wasn't there  */
	/* -- already).  */
      vpaccess(vparray[i],&(void *)curarray);
      printf("displaying elements 0 - 9, should all be %d\n",i);
      for (i2 = 0; i2 < 9; i2++)
	printf("%4d",(*curarray)[i2]);
      printf("\n");
      vpunuse(vparray[i]);

    }

  printf("free mem in page area is %lu\n",vmmemavail());
  printf("virtual mem in use is %lu\n",virtualmemused());
  printf("now disposing of virtual allocations\n");

    /* -- now dispose of virtual allocations  */

  for (i = 0; i < maxarrays; i++)
      vpfreemem(vparray[i]);
  printf("free mem in page area is %lu\n",vmmemavail());
  printf("virtual mem in use is %lu\n",virtualmemused());
  pressakey();

}



