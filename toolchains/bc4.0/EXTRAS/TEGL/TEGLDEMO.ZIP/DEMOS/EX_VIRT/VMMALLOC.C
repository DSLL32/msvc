
  /* -- vmmalloc.c  */
  /* -- allocating an array of memory blocks in virtual memory  */ 

#include "virtmem.h"
#include "stdio.h"
#include "conio.h"

#define maxblocks    96     /* -- max blocks of memory to allocate  */
#define blocksize    16384

  virtualptr   vpa[maxblocks+1];
  int          i;


void main(void)
{


  initteglheap();   /* -- initialize using defaults  */ 
  printf("Virtual Memory in use    = %lu\n",virtualmemused());
  printf("allocating %d blocks of %d\n",maxblocks ,blocksize);
  for (i = 0; i < maxblocks; i++)
    {
      printf("allocating block %d\n",i);
      vpgetmem(&vpa[i],blocksize);
    } 
    /* -- the vmpageout forces the virtual memory manager to  */
    /* -- try and create a free block of the requested size. All  */
    /* -- blocks (even with soft locks) can be paged out and  */
    /* -- housekeeping performed so free blocks can be consolidated.  */
    /* -- If no blocks have soft locks then cmaxavail will return  */
    /* -- the virtual page area size.  */
  if (vmpageout(640000L)) ;
  printf("Virtual Memory in use    = %lu\n",virtualmemused());
  printf("Virtual page area        = %lu\n",vmmaxavail());

  printf("accessing all blocks\n"); 
  for (i = 0; i <= maxblocks; i++) 
    { 
      printf("Using block %d\n",i); 
        /* -- using a virtual memory block places a soft lock on  */ 
        /* -- it so it is moved into the virtual page area.  */ 
        /* -- note that this program does not really access any of the  */ 
        /* -- memory allocated, just reads it into the page area.  */ 
      vpuse(vpa[i]); 
        /* -- Now the block has the soft lock removed so the  */ 
        /* -- virtual memory manager can page it out if  */ 
        /* -- necessary.  */ 
      vpunuse(vpa[i]); 
    } 

    /* -- when a virtual memory block is deallocated it does not have to */ 
    /* -- be read in. This is a fast function.  */ 
  printf("deallocating virtual memory\n"); 
  for (i = 0; i <= maxblocks; i++) 
    vpfreemem(vpa[i]); 
  printf("Virtual Memory in use    = %lu\n",virtualmemused());
  printf("Virtual page area        = %lu\n",vmmaxavail());


  printf("\n"); 
  printf("press any key"); 
  if (getch() == ' ') ;
}



