  /*  xmschk.pas  */
  /*  check for extended memory  */

#include <stdio.h>
#include "teglcond.h"
#include "vmxms.h"

#ifdef MSDOS
#else
#include "conio.h"
#endif

char xmver[81];
unsigned long totalxms, biggestxms, umbytes;

void main(void)
{
  if (xmminstalled())
    {
      if (getxmsversionnumber(xmver) == 0) ;
      if (xmsbytesavailable(&totalxms,&biggestxms) == 0) ;
      if (uppermemorybytesavailable(&umbytes) == 0) ;
      printf("Extended memory manager version %s\n",(char*)&xmver[1]);
      printf("Total extended memory available: %lu\n",totalxms);
      printf("Upper memory available         : %lu\n",umbytes);
      printf("Largest extended memory block  : %lu\n",biggestxms);
    }
  else
    printf("Extended memory manager not found!\n");

  printf("Press Enter\n");
  getch();
}



