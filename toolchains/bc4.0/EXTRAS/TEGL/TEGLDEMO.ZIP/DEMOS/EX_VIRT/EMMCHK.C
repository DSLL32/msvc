
  /* -- emmchk.c  */
  /* -- checks to see if an expanded memory manager is installed  */
  /* -- and if it is displays the version number and the number  */
  /* -- of available pages of memory.  */

#include "virtmem.h"
#include "vmems.h"
#include "stdio.h"

#ifdef MSDOS
#else
#include "conio.h"
#endif

  unsigned     tot, pages;
  unsigned long  int	pg;
  char	       ver[81];

void main(void)
{


  if (emminstalled)   /* -- returns true if EM manager is installed  */
    {
      printf("EMM is installed\n");
	/* -- get the version number of the EMM  */
      if (getemsversionnumber(ver) == 0)
	 printf("Version number  = %s\n",ver+1);
	/* -- get total and free pages	*/
      if (emspagesavailable(&tot,&pages) == 0) ;
      printf("total pages     = %u\n",tot);
      printf("pages available = %u\n",pages);
      pg = pages;
      pg = pg * 16383L;
      printf("bytes           = %lu\n",pg);
    }
  else
    printf("EMM is not available\n");

  printf("\n");
  printf("press any key");
  if (getch() == ' ') ;
}



