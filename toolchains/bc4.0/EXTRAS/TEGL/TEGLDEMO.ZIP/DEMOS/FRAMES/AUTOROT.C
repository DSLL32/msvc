/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
  /* -- Program to illustrate auto rotation of frames by using setautorotate.  */
  /* -- Whichever frame is clicked on will move to the top.  */

#include "teglcond.h"
#include "teglunit.h"
#include "teglmain.h"

imagestkptr  fs;

void main(void)
{
   easytegl();
   easyout();

     /* -- create the first frame  */

   pushimage(1,1,100,100);
   shadowbox(1,1,100,100);

     /* -- then create the second frame  */

   pushimage(50,50,150,150);
   shadowbox(50,50,150,150);

   setautorotate(TRUE);

   teglsupervisor();
}
