/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
#include "teglcond.h"
#include "teglunit.h"
#include "teglmain.h"

unsigned myproc(imagestkptr  fs, msclickptr   ms)
{
	beep(1000,1,50);
	return 1;
}

unsigned yourproc(imagestkptr  fs, msclickptr	ms)
{
	beep(1500,1,50);
	return 1;
}

void main(void)
{
	easytegl();
	easyout();

	pushimage(10,10,100,100);
	shadowbox(10,10,100,100);

	shadowbox(15,15,30,30);
	definemouseclickarea(stackptr,5,5,20,20,TRUE,myproc,MSCLICK);

	setframeentercallproc(stackptr,yourproc);

	teglsupervisor();
}
