/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
  /* -- This program shows how a image can be moved around behind  */
  /* -- another image(s). */

#include "teglcond.h"
#include "teglunit.h"
#include "teglmain.h"

imagestkptr  fs;

void main(void)
{
  easytegl();
  easyout();

  pushimage(1,1,100,100);
  shadowbox(1,1,100,100);
  fs = stackptr;

  pushimage(50,50,150,150);
  shadowbox(50,50,150,150);

  while (mouse_buttons == 0) ;

  hideimage(fs);
  showimage(fs,fs->x + 100,fs->y + 100);

  teglsupervisor();
}
