/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
  /* -- This program draws a frame then waits for a mouse button to be pressed	*/
  /* -- then disposes of it.  */

#include "teglcond.h"
#include "teglunit.h"
#include "teglmain.h"

void main(void)
{
   easytegl();
   easyout();

   pushimage(1,1,100,100);
   shadowbox(1,1,100,100);
   showmouse();

   while (mouse_buttons == 0) ;
   popimage();

   teglsupervisor();
}
