/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
  /* -- This program shows how prepareforupdate and commitupdate work  */
  /* -- together in uncovering and then recovering an image so that drawing  */
  /* -- can be performed on a frame that is partially (or completely)  */
  /* -- covered.  */

#include "teglcond.h"
#include "teglunit.h"
#include "teglmain.h"
#include "tgraph.h"

imagestkptr  fs;

void main(void)
{
  easytegl();
  easyout();

    /* -- create the bottom frame (which we are going to draw on  */

  pushimage(1,1,100,100);
  shadowbox(1,1,100,100);
  fs = stackptr;   /* -- save the imagestkptr  */

    /* -- create the frame that partially covers it.  */

  pushimage(50,50,150,150);
  shadowbox(50,50,150,150);

    /* -- as soon as there is a mouse press then we go to work	*/

  while (mouse_buttons == 0) ;
    /* -- tells the window manager to uncover the frame because we want to */
    /* -- work on it (draw to it).  */

  prepareforupdate(fs);
  setcolor(BLUE);
  circle(fs->x + 48,fs->y + 45,40);

    /* -- commitupdate then tells the window manager that all drawing is done  */
    /* -- and it can return things to how they were before prepareforupdate.  */

  commitupdate();


  teglsupervisor();
}
