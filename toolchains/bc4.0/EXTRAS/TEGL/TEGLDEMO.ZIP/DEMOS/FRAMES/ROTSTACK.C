/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
  /* -- Program to illustrate moving a one frame onto the top of another  */
  /* -- frame.	*/

#include "teglcond.h"
#include "teglunit.h"
#include "teglmain.h"

imagestkptr  fs;

void main(void)
{
   easytegl();
   easyout();

     /* -- create the first frame  */

   pushimage(1,1,100,100);
   shadowbox(1,1,100,100);
   fs = stackptr;   /* -- stackptr always has the most recent frame  */

     /* -- then create the second frame  */
   pushimage(50,50,150,150);
   shadowbox(50,50,150,150);

     /* -- since we haven't gone to the supervisor yet we must  */
     /* -- specifically display the mouse.  */
   showmouse();
     /* -- wait for a mouse click  */
   while (mouse_buttons == 0) ;

     /* -- then move them around.  */
   rotatestackimage(fs,stackptr);


   teglsupervisor();
}
