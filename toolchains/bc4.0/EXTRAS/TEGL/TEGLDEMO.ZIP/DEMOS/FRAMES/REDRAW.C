/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990,TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
#include "teglcond.h"
#include "tgraph.h"
#include "fastgrph.h"
#include "iconsys.h"
#include "teglspec.h"
#include "teglunit.h"
#include "teglmain.h"

char gridf[8] = {0xFF,0x88,0x88,0x88,0xFF,0x88,0x88,0x88};

void griderase(int x1,int y1,int x2,int y2)
{
    fillpatternbar(x1,y1,x2,y2,LIGHTGRAY,BLUE,gridf);
}


unsigned rotatemeup(imagestkptr ifs,msclickptr ms)
{
    if (visualsquarebuttonpress(ifs,ms)) {
	releasesquarebutton(ifs,ms);
	if (ifs->nxtptr != NULL)
	    rotatestackimage(ifs,ifs->nxtptr);
    }
    return 0;
}


unsigned rotatemedown(imagestkptr ifs,msclickptr ms)
{
    if (visualsquarebuttonpress(ifs,ms)) {
	releasesquarebutton(ifs,ms);
	if (ifs->lstptr != NULL)
	    rotateunderstackimage(ifs,ifs->lstptr);
    }
    return 0;
}


unsigned dropme(imagestkptr ifs,msclickptr ms)
{
    if (visualsquarebuttonpress(ifs,ms))
	dropstackimage(ifs);
    return 0;
}


unsigned beepme(imagestkptr ifs,msclickptr ms)
{
    beep(1000,1,50);
    return 0;
}


unsigned frameredraw(imagestkptr ifs,msclickptr ms)
{
    unsigned interiorc;

    resetmouseclicks(ifs,NULL);

    interiorc = RED;
    if (ifs->emptyframe)
	interiorc = WHITE;

    prepareforupdate(ifs);
    bevelbox(ifs->x,ifs->y,ifs->x1,ifs->y1,LIGHTGRAY,LIGHTGRAY,interiorc,5);
    commitupdate();
    definesquarebuttontext(ifs,5,5,95,27,2,2,"ROTATEUP",rotatemeup);
    definesquarebuttontext(ifs,5,27,95,49,2,2,"ROTATEDOWN",rotatemedown);
    definesquarebuttontext(ifs,5,49,95,71,2,2,"DROPME",dropme);

    defineresizeareas(ifs,5,5,5,selectandresizeframe);
    defineresizeminmax(ifs,100,100,getmaxx(),getmaxy());
    return 0;
}


void main(int argc,char **argv)
{
    imagestkptr firstframe;

    easytegl();

    setautorotate(FALSE);
    griderase(0,0,getmaxx(),getmaxy());
    eraseframe = griderase;
    easyout();
    setframeautorotate(stackptr,FALSE);

    pushimage(50,50,150,150);
    setframeredraw(stackptr,frameredraw);
    firstframe = stackptr;

    defineiconframe(400,20,imageMONITOR,DARKGRAY,TRUE,beepme,MSCLICK);

    pushemptyimage(100,100,200,200);
    setframeredraw(stackptr,frameredraw);

    pushemptyimage(150,150,250,250);
    setframeredraw(stackptr,frameredraw);

    refreshredrawframe(firstframe,firstframe);
    teglsupervisor();
}
