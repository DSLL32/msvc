/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
#include "teglcond.h"
#include "teglunit.h"
#include "teglmain.h"
#include "tgraph.h"

void main(void)
  {
    easytegl();
    easyout();

    pushimage(100,100,200,130);
    shadowbox(100,100,200,130);
    setcolor(BLACK);
    outtegltextxy(105,105,"Hello World!");
    teglsupervisor();
  }

