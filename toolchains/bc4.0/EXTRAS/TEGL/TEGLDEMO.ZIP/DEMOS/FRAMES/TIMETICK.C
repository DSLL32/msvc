/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
#include "teglcond.h"
#include "teglunit.h"
#include "teglmain.h"
#include "tgraph.h"
#include <stdio.h>

unsigned secs  = 0;
unsigned mins  = 0;
unsigned hours = 0;
imagestkptr timefs;

unsigned inc_time(imagestkptr frame,msclickptr mouseclickpos)
{
  char *ptr;
  char strings[40];

  ++secs;
  if (secs > 59) {
    secs = 0;
    ++mins;
    if (mins > 59) {
      mins = 0;
      ++hours;
      if (hours > 23) {
	hours = 0;
      }
    }
  }

  ptr = strings;
  sprintf(ptr,"%2d:%2d:%2d",hours,mins,secs);
  if (hours < 10)		      /* fill in leading zeros */
    ptr[0] = '0';
  if (mins < 10)
    ptr[3] = '0';
  if (secs < 10)
    ptr[6] = '0';

  prepareforupdate(timefs);
  shadowbox(timefs->x,timefs->y,timefs->x1,timefs->y1);
  setcolor(BLACK);
  outtegltextxy(timefs->x+5,timefs->y+2,ptr);
  commitupdate();

  return 0;
}

void main()
{
   easytegl();
   easyout();

   pushimage(10,10,100,35);
   shadowbox(10,10,100,35);
   timefs = stackptr;
   settimertick(18,inc_time,timefs,NULL);

   teglsupervisor();
}
