/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
  /* -- Program to illustrate moving a one frame onto the top of another  */
  /* -- frame.	*/

#include "teglcond.h"
#include "teglunit.h"
#include "teglmain.h"

imagestkptr  fs;

void main(void)
{
   easytegl();
   easyout();

     /* -- create the first frame  */

   pushimage(0,0,400,400);
   shadowbox(0,0,400,400);
   fs = stackptr;   /* -- stackptr always has the most recent frame  */

     /* -- then create the second frame  */
   pushimage(200,200,600,600);
   shadowbox(200,200,600,600);

   teglsupervisor();
}
