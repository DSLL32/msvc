/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
  /* -- This program show how an image that is covered can still be  */
  /* -- disposed of without affecting the image overlapping it.  */
#include "teglcond.h"
#include "teglunit.h"
#include "teglmain.h"

imagestkptr  fs;

void main(void)
{
  easytegl();
  easyout();

  pushimage(1,1,100,100);
  shadowbox(1,1,100,100);
  fs = stackptr;

  pushimage(50,50,150,150);
  shadowbox(50,50,150,150);

  while (mouse_buttons == 0) ;

    /* -- the window manager will restore the covered areas of the screen  */
    /* -- and in the case of the area that is overlapped the background that  */
    /* -- has been saved by that frame is updated with the partial contents  */
    /* -- of the disposed image.  */

  dropstackimage(fs);

  teglsupervisor();
}
