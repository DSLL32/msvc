/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
  /* -- This program show how we could use an empty image  */

#include "teglcond.h"
#include "teglunit.h"
#include "teglmain.h"
#include "tgraph.h"
#include "errorlog.h"

imagestkptr  background;

unsigned exitprogram(imagestkptr ifs, msclickptr ms)
  {
    if (visualsquarebuttonpress(ifs,ms))
	abortexit("");
    return 0;
  }

void main(void)
  {
    easytegl();

    /* push empty image creates a frame that has no associated */
    /* background image buffer. Here we are creating a frame that */
    /* is the entire screen. */
    pushemptyimage(0,0,getmaxx(),getmaxy());
    background = stackptr;

    /* since this is an empty frame we don't want it to move */
    setframemobility(background,FALSE);
    setframeautorotate(background,FALSE);
    setfillstyle(CLOSE_DOT_FILL,LIGHTGRAY);

    bar(0,0,getmaxx(),getmaxy());
    setcolor(LIGHTBLUE);

    rectangle(0,0,getmaxx(),getmaxy());
    definesquarebuttontext(background,getmaxx()-80,0,getmaxx(),30,
	       20,4,"EXIT",exitprogram);
    teglsupervisor();
  }
