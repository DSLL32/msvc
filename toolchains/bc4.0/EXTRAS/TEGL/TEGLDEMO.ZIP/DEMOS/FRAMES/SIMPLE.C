/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
  /* -- a simple program that draws a blank frame on the screen. The left  */
  /* -- mouse button can be used to move it around. To exit the program click */
  /* -- on the EASY OUT button that is displayed in the bottom right corner.  */

#include "teglcond.h"
#include "teglunit.h"
#include "teglmain.h"

void main(void)
{
   easytegl();	 /* -- simple start up	*/
   easyout();	/* -- displays a button to break out with  */


   pushimage(1,1,100,100);   /* -- save the background and  */
   shadowbox(1,1,100,100);   /* -- then draw a box over it.  */

   teglsupervisor();   /* -- pass control to the supervisor  */
}
