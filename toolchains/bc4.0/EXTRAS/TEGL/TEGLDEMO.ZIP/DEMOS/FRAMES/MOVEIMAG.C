/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
  /* -- This program illustrates how an image can be hidden then displayed  */
  /* -- again at a different screen location.  */

#include "teglcond.h"
#include "tgraph.h"
#include "teglunit.h"
#include "teglmain.h"

imagestkptr  fs;
    unsigned	     i, dx, dy;

void main(void)
{
  easytegl();
  easyout();


  pushimage(1,1,50,50);
  shadowbox(1,1,50,50);
  fs = stackptr;

  i = 20000;   /* -- counter  */
  dx = 0;   /* -- simple delta for the frame  */
  dy = 0;
  do {
     i = i - 1;
     if (i == 100)
	hideimage(fs);	 /* -- just hides the image, doesn't dispose  */
     if (i == 0)
	{
	  dx = dx + 3;
	  dy = dy + 2;

	    /* -- check for screen boundaries  */
	  if (((dx > getmaxx() - 60) | (dy > getmaxy() - 60)))
	    {
	      dx = 1;
	      dy = 1;
	    }
	    /* -- show image places the image at the new location. If you want	*/
	    /* -- to display it at it's orginal location use the imagestackptr  */
	    /* -- x and y, they are the same as when it was hidden.  */
	  showimage(fs,dx,dy);
	  i = 4000;
	}
  }  while (mouse_buttons == 0);

  if (i <= 100)
    showimage(fs,fs->x,fs->y);

  teglsupervisor();
}
