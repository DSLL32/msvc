/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/

#include <conio.h>		/* kbhit() */
#include "teglsys.h"

animateobject bounceicon;

void main(int argc, char **argv)
{
   setvideochoices(TG_CGA,FALSE);
   setvideochoices(TG_VGA,FALSE);
   easytegl();
   easyout();

   init(&bounceicon);
   addframe(&bounceicon,(iconptr)imageBLANKBUT,-15,0,14,37,10,0,0,BLACK);
   sequence(&bounceicon,1);

   resetsequence(&bounceicon);
   addframe(&bounceicon,(iconptr)imageBLANKBUT,15,0,14,37,10,0,0,BLACK);
   sequence(&bounceicon,2);

   origin(&bounceicon,getmaxx() / 2,getmaxy() / 2);

   animateinit();

   clearkeyboardbuf();

   while (!kbhit())
      {
	 sequence(&bounceicon,1);
	 animate(&bounceicon,destination(&bounceicon,36,0));

	 sequence(&bounceicon,2);
	 animate(&bounceicon,destination(&bounceicon,560,0));
      }

   teglsupervisor();
}
