/*---------------------------------------------------------------------------*
 |			    Demo Test Program				     |
 |									     |
 |			   TEGL Windows ToolKit II			     |
 |		  Copyright (C) 1990, TEGL Systems Corporation		     |
 |			    All Rights Reserved.			     |
 *---------------------------------------------------------------------------*/
#include "teglsys.h"
#include "animtst1.inc"

animateobject oriental;
imagestkptr   orientalfs;

unsigned orientalbow(imagestkptr frame, msclickptr mouseclickpos)
   {
      hideimage(frame);

      hidemouse();
      resetframe(&oriental,1);
      animateinit();
      origin(&oriental,frame->x,frame->y);
      animate(&oriental,8);
      showmouse();

      showimage(frame,frame->x,frame->y);
      return 1;
   }

void main(int argc, char **argv)
{
   setvideochoices(TG_CGA,FALSE);
   setvideochoices(TG_VGA,FALSE);
   easytegl();
   easyout();

   init(&oriental);
   addframe(&oriental,(iconptr)imageCHINA,0,0,55,37,350,1200,55,BLACK);
   addframe(&oriental,(iconptr)imageCHINA,0,0,55,37,150,1200,56,BLACK);

   addframe(&oriental,(iconptr)imageCHINA2,0,0,55,37,75,1100,55,BLACK);
   addframe(&oriental,(iconptr)imageCHINA2,0,0,55,37,75,1100,56,BLACK);

   addframe(&oriental,(iconptr)imageCHINA3,0,0,55,37,150,900,55,BLACK);
   addframe(&oriental,(iconptr)imageCHINA3,0,0,55,37,150,900,56,BLACK);
   addframe(&oriental,(iconptr)imageCHINA3,0,0,55,37,600,1100,56,BLACK);

   addframe(&oriental,(iconptr)imageCHINA2,0,0,55,37,150,1100,0,BLACK);
   addframe(&oriental,(iconptr)imageCHINA,0,0,55,37,500,1100,55,BLACK);

   pushimage(15,285,15 + 37,285 + 55);
   putpict(15,285,(iconptr)imageCHINA,BLACK);
   definemouseclickarea(stackptr,0,0,37,55,TRUE,orientalbow,MSCLICK);
   orientalfs = stackptr;
   setframemobility(stackptr,FALSE);

   teglsupervisor();
}
