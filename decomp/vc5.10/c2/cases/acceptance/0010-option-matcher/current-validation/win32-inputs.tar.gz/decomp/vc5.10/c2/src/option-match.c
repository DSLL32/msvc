#include "c2.h"
#include <recon.h>

char *c2_current_option, *c2_option_operand;

int __fastcall c2_match_option(C2Option *table, char *input,
                              char *(__cdecl *next)(void), int mode)
{
    char *text, *pattern, *value;
    if (!input)
        return 0;
    c2_current_option = input;
    for (; table->kind; ++table) {
        text = input;
        pattern = table->pattern;
        for (;;) {
            switch (*pattern) {
            case '\0':
                if (*text)
                    goto mismatch;
                value = NULL;
                if (table->kind & 0x20) {
                    value = next();
                    c2_option_operand = value;
                }
                c2_apply_option(table, value, mode);
                return table->result;
            case '#':
                value = text;
                if (!*value) {
                    value = next();
                    c2_option_operand = value;
                }
                c2_apply_option(table, value, mode);
                return table->result;
            case '*':
                if (!*text || !c2_wildcard_match(pattern, text, table->kind))
                    goto mismatch;
                c2_apply_option(table, text, mode);
                return table->result;
            case '-':
                if (*text != '-')
                    goto mismatch;
                ++text;
                ++pattern;
                break;
            default:
                if (*pattern++ != *text++)
                    goto mismatch;
                break;
            }
        }
    mismatch: ;
    }
    return 0;
}
