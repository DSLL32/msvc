#include "functions.h"
#include <recon.h>

/* Unknown child functions remain named trapping frontiers. */
int c2_math_error(struct _exception *exception)
{
    __asm { int 3 }
    return 0;
}

void c2_print_banner(void)
{
    __asm { int 3 }
}

int __fastcall c2_open_pdb(char *name, char *object_name)
{
    __asm { int 3 }
    return 0;
}
int __fastcall function_retains_symbols(C2FunctionSymbol *symbol, int conditional)
{
    __asm { int 3 }
    return 0;
}

C2Symbol *__fastcall lookup_symbol(C2ScopeHash *scope, unsigned serial)
{
    __asm { int 3 }
    return NULL;
}


void __fastcall queue_symbol_debug(C2Symbol *symbol)
{
    __asm { int 3 }
}


unsigned __fastcall reserve_symbol_storage(C2Symbol *symbol)
{
    __asm { int 3 }
    return 0;
}



void c2_compile_unit(void)
{
    __asm { int 3 }
}

void c2_finalize_output(void)
{
    __asm { int 3 }
}

void c2_flush_debug(void)
{
    __asm { int 3 }
}



BOOL WINAPI c2_console_handler(DWORD control)
{
    __asm { int 3 }
    return FALSE;
}

void __fastcall c2_report_internal(char *source, int line)
{
    __asm { int 3 }
}






void __fastcall c2_system_fatal(int message, char *prefix, char *filename)
{
    __asm { int 3 }
}









unsigned __fastcall resolve_diagnostic_location(unsigned location, char **file)
{
    __asm { int 3 }
    return 0;
}

unsigned input_extended_flags(void) { __asm { int 3 } return 0; }
void __fastcall clone_alias_symbol(C2Symbol *symbol) { __asm { int 3 } }
void __fastcall read_qualified_symbol(C2Symbol *symbol, int pool) { __asm { int 3 } }
void compiler_warning(int level, int code, ...) { __asm { int 3 } }
void __fastcall read_module_directive(int kind) { __asm { int 3 } }
int __fastcall register_source_file(char *name) { __asm { int 3 } return 0; }
char *__fastcall lookup_source_file(char *name, unsigned *bytes) { __asm { int 3 } return NULL; }
void __fastcall uppercase_symbol_name(char *name) { __asm { int 3 } }

int __fastcall is_constant_symbol(C2Symbol *symbol) { __asm { int 3 } return 0; }
int __fastcall is_known_symbol(unsigned serial) { __asm { int 3 } return 0; }
C2Section *__fastcall select_symbol_section(C2FunctionSymbol *function, C2Symbol *symbol) { __asm { int 3 } return NULL; }

C2InitRecord *__fastcall new_initializer(int kind) { __asm { int 3 } return NULL; }
void __fastcall read_initializer_values(C2InitRecord *record) { __asm { int 3 } }
C2InitRecord *__fastcall queue_initializer(C2InitRecord *record) { __asm { int 3 } return NULL; }
void __fastcall emit_initializer(C2InitRecord *record) { __asm { int 3 } }
void __fastcall free_initializer(C2InitRecord *record) { __asm { int 3 } }

void initialize_backend(void)
{
    __asm { int 3 }
}

int check_extended_backend(void)
{
    __asm { int 3 }
    return 0;
}

unsigned short __fastcall listing_source_index(unsigned serial, unsigned source)
{
    __asm { int 3 }
    return 0;
}

int prepare_deferred_function(void)
{
    __asm { int 3 }
    return 0;
}

void finish_deferred_function(void)
{
    __asm { int 3 }
}

void begin_function_input(void)
{
    __asm { int 3 }
}

C2Function *__fastcall read_function(C2FunctionSymbol *symbol)
{
    __asm { int 3 }
    return NULL;
}

void __fastcall activate_scope(C2ScopeHash *scope)
{
    __asm { int 3 }
}

void __fastcall canonicalize_function(C2Function *function)
{
    __asm { int 3 }
}

int __fastcall skip_global_optimization(C2Function *function)
{
    __asm { int 3 }
    return 0;
}

void __fastcall function_pass_409dac(C2Function *function, int mode)
{
    __asm { int 3 }
}

void __fastcall function_pass_40d9be(C2Function *function, int mode)
{
    __asm { int 3 }
}

void __fastcall function_pass_456857(C2Function *function, int mode)
{
    __asm { int 3 }
}

void __fastcall function_pass_4570e0(C2Function *function, int mode)
{
    __asm { int 3 }
}

void finish_function(void)
{
    __asm { int 3 }
}

void __fastcall function_pass_463ff1(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_456b13(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_45729f(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_458c9f(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_46481c(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_483f46(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_4088c7(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_427d89(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_4828f8(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_421bdf(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_421e34(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_409c5c(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_42127d(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_4180e8(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_413245(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_4132fa(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_413369(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_412292(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_412412(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_464b8a(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_412457(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_4120d4(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_412d5c(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_4144ef(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_414862(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_40d254(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_414a64(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_41759e(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_416e6a(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_42a8aa(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_42b3e2(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_42b750(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_42e689(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_483b6f(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_42e6a6(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_402cb6(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_402b6e(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_42d635(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_42d65a(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_42f060(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_402c2c(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_42f3e4(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_42f446(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_4330f7(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_433546(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_4338ab(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_465486(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_47d1d3(C2Function *function)
{
    __asm { int 3 }
}

void __fastcall function_pass_433906(C2Function *function)
{
    __asm { int 3 }
}
