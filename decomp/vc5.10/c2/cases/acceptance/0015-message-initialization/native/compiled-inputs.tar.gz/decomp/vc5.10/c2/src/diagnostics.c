#include "c2.h"
#include <recon.h>

extern int c2_errors;

void c2_fatal(int message, ...)
{
    va_list arguments;
    char *format;
    _fcloseall();
    format = lookup_message(message + 1000, 0);
    va_start(arguments, message);
    emit_diagnostic(1000, message, format, arguments);
    va_end(arguments);
    exit(++c2_errors);
}

char message_buffer[384];

char *__fastcall lookup_message(unsigned message, int allow_missing)
{
    initialize_messages();
    return load_message(message, message_buffer, sizeof(message_buffer), allow_missing);
}

MessageEntry messages[7] = {
    { 301, NULL }, { 302, NULL }, { 303, NULL },
    { 310, NULL }, { 311, NULL }, { 312, NULL }, { 0, NULL }
};
int messages_initialized;

void initialize_messages(void)
{
    MessageEntry *entry;
    char *text;
    char *(__cdecl *copy)(const char *);
    if (!messages_initialized) {
        messages_initialized = 1;
        if (messages[0].id) {
            copy = _strdup;
            for (entry = messages; entry->id; ++entry) {
                text = lookup_message(entry->id, 1);
                if (text)
                    entry->text = copy(text);
                else if (entry->id == 301)
                    entry->text = "warning";
                else if (entry->id == 302)
                    entry->text = "error";
                else if (entry->id == 303)
                    entry->text = "fatal error";
            }
        }
    }
}
