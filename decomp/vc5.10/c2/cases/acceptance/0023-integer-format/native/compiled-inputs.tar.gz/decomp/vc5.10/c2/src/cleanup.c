#include "c2.h"
#include <recon.h>

int c2_cleanup_started, c2_output_incomplete;
FILE *c2_output_stream;
