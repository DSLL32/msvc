#include "c2.h"
#include <recon.h>

extern int c2_errors;

void c2_fatal(int message, ...)
{
    va_list arguments;
    char *format;
    _fcloseall();
    format = lookup_message(message + 1000, 0);
    va_start(arguments, message);
    emit_diagnostic(1000, message, format, arguments);
    va_end(arguments);
    exit(++c2_errors);
}

char message_buffer[384];

char *__fastcall lookup_message(unsigned message, int allow_missing)
{
    initialize_messages();
    return load_message(message, message_buffer, sizeof(message_buffer), allow_missing);
}
