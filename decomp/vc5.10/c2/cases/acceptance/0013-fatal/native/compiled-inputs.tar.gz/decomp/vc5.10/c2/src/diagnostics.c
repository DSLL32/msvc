#include "c2.h"
#include <recon.h>

extern int c2_errors;

void c2_fatal(int message, ...)
{
    va_list arguments;
    char *format;
    _fcloseall();
    format = lookup_message(message + 1000, 0);
    va_start(arguments, message);
    emit_diagnostic(1000, message, format, arguments);
    va_end(arguments);
    exit(++c2_errors);
}
