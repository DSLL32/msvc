#include "c2.h"
#include <recon.h>

/* Unknown child functions remain named trapping frontiers. */
int c2_math_error(struct _exception *exception)
{
    __asm { int 3 }
    return 0;
}

int c2_main(int argc, char **argv, char **environment)
{
    __asm { int 3 }
    return 0;
}
