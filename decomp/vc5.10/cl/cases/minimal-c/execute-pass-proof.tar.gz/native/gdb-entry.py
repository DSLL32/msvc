import sys
sys.path.insert(0,'/root/.ai-tmp/msvc2/vc5.10/cl/execute-pass-provider-5-native')
from gdb_entry import capture
capture('/root/.ai-tmp/msvc2/vc5.10/cl/execute-pass-provider-5-native')
from gdb_mktemp import install
install('/root/.ai-tmp/msvc2/vc5.10/cl/execute-pass-provider-5-native')
