import sys
sys.path.insert(0,'/root/.ai-tmp/msvc2/vc5.10/cl/show-usage-3-native')
from gdb_capture import capture
capture('/root/.ai-tmp/msvc2/vc5.10/cl/show-usage-3-native')
