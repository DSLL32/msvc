
../../../toolchains/1.0-nt/bin/C1XX3232.EXE:     file format pei-i386


Disassembly of section .text:

00024290 <.text+0xd290>:
   24290:	83 ec 10             	sub    esp,0x10
   24293:	53                   	push   ebx
   24294:	56                   	push   esi
   24295:	57                   	push   edi
   24296:	55                   	push   ebp
   24297:	2b ff                	sub    edi,edi
   24299:	a1 d4 cf 08 00       	mov    eax,ds:0x8cfd4
   2429e:	89 44 24 14          	mov    DWORD PTR [esp+0x14],eax
   242a2:	66 89 7c 24 18       	mov    WORD PTR [esp+0x18],di
   242a7:	8b 74 24 10          	mov    esi,DWORD PTR [esp+0x10]
   242ab:	8b 44 24 14          	mov    eax,DWORD PTR [esp+0x14]
   242af:	66 8b 4c 24 18       	mov    cx,WORD PTR [esp+0x18]
   242b4:	66 39 08             	cmp    WORD PTR [eax],cx
   242b7:	0f 8e a6 00 00 00    	jle    0x24363
   242bd:	8b 40 08             	mov    eax,DWORD PTR [eax+0x8]
   242c0:	0f bf c9             	movsx  ecx,cx
   242c3:	8b 04 88             	mov    eax,DWORD PTR [eax+ecx*4]
   242c6:	66 ff 44 24 18       	inc    WORD PTR [esp+0x18]
   242cb:	bf 01 00 00 00       	mov    edi,0x1
   242d0:	8b 1d 4c fc 09 00    	mov    ebx,DWORD PTR ds:0x9fc4c
   242d6:	8b c8                	mov    ecx,eax
   242d8:	0b c0                	or     eax,eax
   242da:	74 57                	je     0x24333
   242dc:	ba 34 e7 09 00       	mov    edx,0x9e734
   242e1:	66 8b 28             	mov    bp,WORD PTR [eax]
   242e4:	66 3b 2a             	cmp    bp,WORD PTR [edx]
   242e7:	75 06                	jne    0x242ef
   242e9:	8a 40 02             	mov    al,BYTE PTR [eax+0x2]
   242ec:	3a 42 02             	cmp    al,BYTE PTR [edx+0x2]
   242ef:	74 42                	je     0x24333
   242f1:	80 39 00             	cmp    BYTE PTR [ecx],0x0
   242f4:	74 18                	je     0x2430e
   242f6:	8b 15 4c fc 09 00    	mov    edx,DWORD PTR ds:0x9fc4c
   242fc:	8a 01                	mov    al,BYTE PTR [ecx]
   242fe:	88 02                	mov    BYTE PTR [edx],al
   24300:	8b f1                	mov    esi,ecx
   24302:	41                   	inc    ecx
   24303:	ff 05 4c fc 09 00    	inc    DWORD PTR ds:0x9fc4c
   24309:	80 39 00             	cmp    BYTE PTR [ecx],0x0
   2430c:	75 e8                	jne    0x242f6
   2430e:	33 c0                	xor    eax,eax
   24310:	8a 06                	mov    al,BYTE PTR [esi]
   24312:	50                   	push   eax
   24313:	a1 60 fc 09 00       	mov    eax,ds:0x9fc60
   24318:	50                   	push   eax
   24319:	e8 d2 d1 05 00       	call   0x814f0
   2431e:	83 c4 08             	add    esp,0x8
   24321:	0b c0                	or     eax,eax
   24323:	75 0e                	jne    0x24333
   24325:	a1 4c fc 09 00       	mov    eax,ds:0x9fc4c
   2432a:	c6 00 5c             	mov    BYTE PTR [eax],0x5c
   2432d:	ff 05 4c fc 09 00    	inc    DWORD PTR ds:0x9fc4c
   24333:	8b 4c 24 24          	mov    ecx,DWORD PTR [esp+0x24]
   24337:	8b 15 4c fc 09 00    	mov    edx,DWORD PTR ds:0x9fc4c
   2433d:	ff 05 4c fc 09 00    	inc    DWORD PTR ds:0x9fc4c
   24343:	8a 01                	mov    al,BYTE PTR [ecx]
   24345:	88 02                	mov    BYTE PTR [edx],al
   24347:	41                   	inc    ecx
   24348:	0a c0                	or     al,al
   2434a:	75 eb                	jne    0x24337
   2434c:	6a 00                	push   0x0
   2434e:	53                   	push   ebx
   2434f:	e8 2c a1 ff ff       	call   0x1e480
   24354:	0b c0                	or     eax,eax
   24356:	75 4c                	jne    0x243a4
   24358:	89 1d 4c fc 09 00    	mov    DWORD PTR ds:0x9fc4c,ebx
   2435e:	e9 48 ff ff ff       	jmp    0x242ab
   24363:	0b ff                	or     edi,edi
   24365:	8b 44 24 24          	mov    eax,DWORD PTR [esp+0x24]
   24369:	50                   	push   eax
   2436a:	74 24                	je     0x24390
   2436c:	68 57 01 00 00       	push   0x157
   24371:	e8 8a 07 05 00       	call   0x74b00
   24376:	83 c4 04             	add    esp,0x4
   24379:	50                   	push   eax
   2437a:	6a 53                	push   0x53
   2437c:	e8 bf ee 04 00       	call   0x73240
   24381:	83 c4 0c             	add    esp,0xc
   24384:	5d                   	pop    ebp
   24385:	5f                   	pop    edi
   24386:	5e                   	pop    esi
   24387:	5b                   	pop    ebx
   24388:	83 c4 10             	add    esp,0x10
   2438b:	c2 04 00             	ret    0x4
   2438e:	8b ff                	mov    edi,edi
   24390:	6a 22                	push   0x22
   24392:	e8 e9 ee 04 00       	call   0x73280
   24397:	83 c4 08             	add    esp,0x8
   2439a:	5d                   	pop    ebp
   2439b:	5f                   	pop    edi
   2439c:	5e                   	pop    esi
   2439d:	5b                   	pop    ebx
   2439e:	83 c4 10             	add    esp,0x10
   243a1:	c2 04 00             	ret    0x4
   243a4:	83 3d d0 cc 08 00 01 	cmp    DWORD PTR ds:0x8ccd0,0x1
   243ab:	75 06                	jne    0x243b3
   243ad:	53                   	push   ebx
   243ae:	e8 9d 72 04 00       	call   0x6b650
   243b3:	5d                   	pop    ebp
   243b4:	5f                   	pop    edi
   243b5:	5e                   	pop    esi
   243b6:	5b                   	pop    ebx
   243b7:	83 c4 10             	add    esp,0x10
   243ba:	c2 04 00             	ret    0x4
