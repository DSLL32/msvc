
../../../toolchains/1.0-nt/bin/C1XX3232.EXE:     file format pei-i386


Disassembly of section .text:

000238b0 <.text+0xc8b0>:
   238b0:	56                   	push   esi
   238b1:	57                   	push   edi
   238b2:	66 83 3d f4 d7 09 00 	cmp    WORD PTR ds:0x9d7f4,0x0
   238b9:	00 
   238ba:	75 29                	jne    0x238e5
   238bc:	83 3d 98 fa 09 00 00 	cmp    DWORD PTR ds:0x9fa98,0x0
   238c3:	8b 74 24 0c          	mov    esi,DWORD PTR [esp+0xc]
   238c7:	74 20                	je     0x238e9
   238c9:	56                   	push   esi
   238ca:	a1 98 fa 09 00       	mov    eax,ds:0x9fa98
   238cf:	50                   	push   eax
   238d0:	e8 6b 0f 00 00       	call   0x24840
   238d5:	83 c4 08             	add    esp,0x8
   238d8:	0b c0                	or     eax,eax
   238da:	74 0d                	je     0x238e9
   238dc:	c6 05 b8 fa 09 00 01 	mov    BYTE PTR ds:0x9fab8,0x1
   238e3:	eb 04                	jmp    0x238e9
   238e5:	8b 74 24 0c          	mov    esi,DWORD PTR [esp+0xc]
   238e9:	66 83 3d f4 d7 09 00 	cmp    WORD PTR ds:0x9d7f4,0x0
   238f0:	00 
   238f1:	75 11                	jne    0x23904
   238f3:	56                   	push   esi
   238f4:	e8 37 7c 04 00       	call   0x6b530
   238f9:	0b c0                	or     eax,eax
   238fb:	74 07                	je     0x23904
   238fd:	2b c0                	sub    eax,eax
   238ff:	5f                   	pop    edi
   23900:	5e                   	pop    esi
   23901:	c2 08 00             	ret    0x8
   23904:	68 f0 e6 09 00       	push   0x9e6f0
   23909:	e8 b2 0a 00 00       	call   0x243c0
   2390e:	83 3d 14 c0 08 00 00 	cmp    DWORD PTR ds:0x8c014,0x0
   23915:	75 07                	jne    0x2391e
   23917:	6a 01                	push   0x1
   23919:	e8 d2 77 03 00       	call   0x5b0f0
   2391e:	33 c0                	xor    eax,eax
   23920:	8a 06                	mov    al,BYTE PTR [esi]
   23922:	50                   	push   eax
   23923:	a1 60 fc 09 00       	mov    eax,ds:0x9fc60
   23928:	50                   	push   eax
   23929:	e8 c2 db 05 00       	call   0x814f0
   2392e:	83 c4 08             	add    esp,0x8
   23931:	0b c0                	or     eax,eax
   23933:	75 3b                	jne    0x23970
   23935:	6a 3a                	push   0x3a
   23937:	a1 60 fc 09 00       	mov    eax,ds:0x9fc60
   2393c:	50                   	push   eax
   2393d:	e8 ae db 05 00       	call   0x814f0
   23942:	83 c4 08             	add    esp,0x8
   23945:	0b c0                	or     eax,eax
   23947:	74 06                	je     0x2394f
   23949:	80 7e 01 3a          	cmp    BYTE PTR [esi+0x1],0x3a
   2394d:	74 21                	je     0x23970
   2394f:	83 7c 24 10 00       	cmp    DWORD PTR [esp+0x10],0x0
   23954:	75 0a                	jne    0x23960
   23956:	56                   	push   esi
   23957:	e8 24 b3 ff ff       	call   0x1ec80
   2395c:	0b c0                	or     eax,eax
   2395e:	75 5e                	jne    0x239be
   23960:	56                   	push   esi
   23961:	e8 2a 09 00 00       	call   0x24290
   23966:	b8 01 00 00 00       	mov    eax,0x1
   2396b:	5f                   	pop    edi
   2396c:	5e                   	pop    esi
   2396d:	c2 08 00             	ret    0x8
   23970:	8b 3d 4c fc 09 00    	mov    edi,DWORD PTR ds:0x9fc4c
   23976:	a1 4c fc 09 00       	mov    eax,ds:0x9fc4c
   2397b:	ff 05 4c fc 09 00    	inc    DWORD PTR ds:0x9fc4c
   23981:	8a 0e                	mov    cl,BYTE PTR [esi]
   23983:	88 08                	mov    BYTE PTR [eax],cl
   23985:	46                   	inc    esi
   23986:	0a c9                	or     cl,cl
   23988:	75 ec                	jne    0x23976
   2398a:	6a 00                	push   0x0
   2398c:	57                   	push   edi
   2398d:	e8 ee aa ff ff       	call   0x1e480
   23992:	0b c0                	or     eax,eax
   23994:	75 19                	jne    0x239af
   23996:	57                   	push   edi
   23997:	68 57 01 00 00       	push   0x157
   2399c:	e8 5f 11 05 00       	call   0x74b00
   239a1:	83 c4 04             	add    esp,0x4
   239a4:	50                   	push   eax
   239a5:	6a 53                	push   0x53
   239a7:	e8 94 f8 04 00       	call   0x73240
   239ac:	83 c4 0c             	add    esp,0xc
   239af:	83 3d d0 cc 08 00 01 	cmp    DWORD PTR ds:0x8ccd0,0x1
   239b6:	75 06                	jne    0x239be
   239b8:	56                   	push   esi
   239b9:	e8 92 7c 04 00       	call   0x6b650
   239be:	b8 01 00 00 00       	mov    eax,0x1
   239c3:	5f                   	pop    edi
   239c4:	5e                   	pop    esi
   239c5:	c2 08 00             	ret    0x8
