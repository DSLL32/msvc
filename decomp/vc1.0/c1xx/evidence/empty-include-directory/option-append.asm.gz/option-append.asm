
../../../toolchains/1.0-nt/bin/C1XX3232.EXE:     file format pei-i386


Disassembly of section .text:

00073960 <.text+0x5c960>:
   73960:	56                   	push   esi
   73961:	57                   	push   edi
   73962:	8b 74 24 0c          	mov    esi,DWORD PTR [esp+0xc]
   73966:	33 c0                	xor    eax,eax
   73968:	8a 46 09             	mov    al,BYTE PTR [esi+0x9]
   7396b:	83 f8 23             	cmp    eax,0x23
   7396e:	7f 20                	jg     0x73990
   73970:	0f 84 fa 00 00 00    	je     0x73a70
   73976:	83 f8 01             	cmp    eax,0x1
   73979:	74 27                	je     0x739a2
   7397b:	83 f8 05             	cmp    eax,0x5
   7397e:	74 30                	je     0x739b0
   73980:	83 f8 22             	cmp    eax,0x22
   73983:	0f 84 b7 00 00 00    	je     0x73a40
   73989:	5f                   	pop    edi
   7398a:	5e                   	pop    esi
   7398b:	c3                   	ret
   7398c:	8d 64 24 00          	lea    esp,[esp+0x0]
   73990:	83 f8 24             	cmp    eax,0x24
   73993:	74 2b                	je     0x739c0
   73995:	83 f8 26             	cmp    eax,0x26
   73998:	74 3b                	je     0x739d5
   7399a:	83 f8 27             	cmp    eax,0x27
   7399d:	74 61                	je     0x73a00
   7399f:	5f                   	pop    edi
   739a0:	5e                   	pop    esi
   739a1:	c3                   	ret
   739a2:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
   739a5:	5f                   	pop    edi
   739a6:	c7 00 01 00 00 00    	mov    DWORD PTR [eax],0x1
   739ac:	5e                   	pop    esi
   739ad:	c3                   	ret
   739ae:	8b ff                	mov    edi,edi
   739b0:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
   739b3:	5f                   	pop    edi
   739b4:	c7 00 00 00 00 00    	mov    DWORD PTR [eax],0x0
   739ba:	5e                   	pop    esi
   739bb:	c3                   	ret
   739bc:	8d 64 24 00          	lea    esp,[esp+0x0]
   739c0:	8b 7c 24 10          	mov    edi,DWORD PTR [esp+0x10]
   739c4:	57                   	push   edi
   739c5:	e8 16 01 00 00       	call   0x73ae0
   739ca:	83 c4 04             	add    esp,0x4
   739cd:	8b 4e 04             	mov    ecx,DWORD PTR [esi+0x4]
   739d0:	5f                   	pop    edi
   739d1:	89 01                	mov    DWORD PTR [ecx],eax
   739d3:	5e                   	pop    esi
   739d4:	c3                   	ret
   739d5:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
   739d8:	83 7c 24 14 00       	cmp    DWORD PTR [esp+0x14],0x0
   739dd:	8b 30                	mov    esi,DWORD PTR [eax]
   739df:	74 0f                	je     0x739f0
   739e1:	8b 7c 24 10          	mov    edi,DWORD PTR [esp+0x10]
   739e5:	57                   	push   edi
   739e6:	e8 45 67 01 00       	call   0x8a130
   739eb:	83 c4 04             	add    esp,0x4
   739ee:	eb 04                	jmp    0x739f4
   739f0:	8b 44 24 10          	mov    eax,DWORD PTR [esp+0x10]
   739f4:	50                   	push   eax
   739f5:	56                   	push   esi
   739f6:	e8 d5 b0 fd ff       	call   0x4ead0
   739fb:	5f                   	pop    edi
   739fc:	5e                   	pop    esi
   739fd:	c3                   	ret
   739fe:	8b ff                	mov    edi,edi
   73a00:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
   73a03:	83 38 00             	cmp    DWORD PTR [eax],0x0
   73a06:	74 38                	je     0x73a40
   73a08:	8b 06                	mov    eax,DWORD PTR [esi]
   73a0a:	50                   	push   eax
   73a0b:	e8 20 67 01 00       	call   0x8a130
   73a10:	83 c4 04             	add    esp,0x4
   73a13:	8b d0                	mov    edx,eax
   73a15:	8b fa                	mov    edi,edx
   73a17:	b9 ff ff ff ff       	mov    ecx,0xffffffff
   73a1c:	2b c0                	sub    eax,eax
   73a1e:	f2 ae                	repnz scas al,BYTE PTR es:[edi]
   73a20:	f7 d1                	not    ecx
   73a22:	c6 44 0a fe 00       	mov    BYTE PTR [edx+ecx*1-0x2],0x0
   73a27:	8b 7c 24 10          	mov    edi,DWORD PTR [esp+0x10]
   73a2b:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
   73a2e:	57                   	push   edi
   73a2f:	8b 00                	mov    eax,DWORD PTR [eax]
   73a31:	50                   	push   eax
   73a32:	52                   	push   edx
   73a33:	6a 2e                	push   0x2e
   73a35:	e8 46 f8 ff ff       	call   0x73280
   73a3a:	83 c4 10             	add    esp,0x10
   73a3d:	5f                   	pop    edi
   73a3e:	5e                   	pop    esi
   73a3f:	c3                   	ret
   73a40:	83 7c 24 14 00       	cmp    DWORD PTR [esp+0x14],0x0
   73a45:	74 19                	je     0x73a60
   73a47:	8b 7c 24 10          	mov    edi,DWORD PTR [esp+0x10]
   73a4b:	57                   	push   edi
   73a4c:	e8 df 66 01 00       	call   0x8a130
   73a51:	83 c4 04             	add    esp,0x4
   73a54:	8b 4e 04             	mov    ecx,DWORD PTR [esi+0x4]
   73a57:	5f                   	pop    edi
   73a58:	89 01                	mov    DWORD PTR [ecx],eax
   73a5a:	5e                   	pop    esi
   73a5b:	c3                   	ret
   73a5c:	8d 64 24 00          	lea    esp,[esp+0x0]
   73a60:	8b 46 04             	mov    eax,DWORD PTR [esi+0x4]
   73a63:	8b 7c 24 10          	mov    edi,DWORD PTR [esp+0x10]
   73a67:	89 38                	mov    DWORD PTR [eax],edi
   73a69:	5f                   	pop    edi
   73a6a:	5e                   	pop    esi
   73a6b:	c3                   	ret
   73a6c:	8d 64 24 00          	lea    esp,[esp+0x0]
   73a70:	8b 7c 24 10          	mov    edi,DWORD PTR [esp+0x10]
   73a74:	80 3f 00             	cmp    BYTE PTR [edi],0x0
   73a77:	74 5f                	je     0x73ad8
   73a79:	8b 4e 04             	mov    ecx,DWORD PTR [esi+0x4]
   73a7c:	83 39 00             	cmp    DWORD PTR [ecx],0x0
   73a7f:	74 3d                	je     0x73abe
   73a81:	8a 07                	mov    al,BYTE PTR [edi]
   73a83:	38 01                	cmp    BYTE PTR [ecx],al
   73a85:	74 0a                	je     0x73a91
   73a87:	83 c1 0c             	add    ecx,0xc
   73a8a:	83 39 00             	cmp    DWORD PTR [ecx],0x0
   73a8d:	75 f4                	jne    0x73a83
   73a8f:	eb 28                	jmp    0x73ab9
   73a91:	8b 41 04             	mov    eax,DWORD PTR [ecx+0x4]
   73a94:	83 f8 01             	cmp    eax,0x1
   73a97:	74 07                	je     0x73aa0
   73a99:	83 f8 05             	cmp    eax,0x5
   73a9c:	74 12                	je     0x73ab0
   73a9e:	eb 19                	jmp    0x73ab9
   73aa0:	8b 41 08             	mov    eax,DWORD PTR [ecx+0x8]
   73aa3:	c7 00 01 00 00 00    	mov    DWORD PTR [eax],0x1
   73aa9:	eb 0e                	jmp    0x73ab9
   73aab:	05 00 00 00 00       	add    eax,0x0
   73ab0:	8b 41 08             	mov    eax,DWORD PTR [ecx+0x8]
   73ab3:	c7 00 00 00 00 00    	mov    DWORD PTR [eax],0x0
   73ab9:	83 39 00             	cmp    DWORD PTR [ecx],0x0
   73abc:	75 14                	jne    0x73ad2
   73abe:	a1 5c a1 09 00       	mov    eax,ds:0x9a15c
   73ac3:	50                   	push   eax
   73ac4:	0f be 07             	movsx  eax,BYTE PTR [edi]
   73ac7:	50                   	push   eax
   73ac8:	6a 30                	push   0x30
   73aca:	e8 b1 f7 ff ff       	call   0x73280
   73acf:	83 c4 0c             	add    esp,0xc
   73ad2:	47                   	inc    edi
   73ad3:	80 3f 00             	cmp    BYTE PTR [edi],0x0
   73ad6:	75 a1                	jne    0x73a79
   73ad8:	5f                   	pop    edi
   73ad9:	5e                   	pop    esi
   73ada:	c3                   	ret
   73adb:	05                   	.byte 0x5
