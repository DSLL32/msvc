
../../../toolchains/1.0-nt/bin/C1XX3232.EXE:     file format pei-i386


Disassembly of section .text:

00073c60 <.text+0x5cc60>:
   73c60:	53                   	push   ebx
   73c61:	56                   	push   esi
   73c62:	57                   	push   edi
   73c63:	2b ff                	sub    edi,edi
   73c65:	8b 74 24 10          	mov    esi,DWORD PTR [esp+0x10]
   73c69:	3b f7                	cmp    esi,edi
   73c6b:	0f 84 b5 00 00 00    	je     0x73d26
   73c71:	e8 8a ff ff ff       	call   0x73c00
   73c76:	8a 0e                	mov    cl,BYTE PTR [esi]
   73c78:	0a c9                	or     cl,cl
   73c7a:	0f 84 a0 00 00 00    	je     0x73d20
   73c80:	80 f9 20             	cmp    cl,0x20
   73c83:	75 06                	jne    0x73c8b
   73c85:	46                   	inc    esi
   73c86:	80 3e 20             	cmp    BYTE PTR [esi],0x20
   73c89:	74 fa                	je     0x73c85
   73c8b:	80 3e 00             	cmp    BYTE PTR [esi],0x0
   73c8e:	74 e6                	je     0x73c76
   73c90:	8b d6                	mov    edx,esi
   73c92:	89 30                	mov    DWORD PTR [eax],esi
   73c94:	83 c0 04             	add    eax,0x4
   73c97:	ff 05 78 cc 08 00    	inc    DWORD PTR ds:0x8cc78
   73c9d:	80 3e 00             	cmp    BYTE PTR [esi],0x0
   73ca0:	74 71                	je     0x73d13
   73ca2:	8a 0e                	mov    cl,BYTE PTR [esi]
   73ca4:	80 f9 20             	cmp    cl,0x20
   73ca7:	75 04                	jne    0x73cad
   73ca9:	0b ff                	or     edi,edi
   73cab:	74 60                	je     0x73d0d
   73cad:	33 db                	xor    ebx,ebx
   73caf:	8a d9                	mov    bl,cl
   73cb1:	8a 9b b0 d5 09 00    	mov    bl,BYTE PTR [ebx+0x9d5b0]
   73cb7:	81 e3 ff 00 00 00    	and    ebx,0xff
   73cbd:	83 fb 03             	cmp    ebx,0x3
   73cc0:	74 0e                	je     0x73cd0
   73cc2:	83 fb 08             	cmp    ebx,0x8
   73cc5:	74 30                	je     0x73cf7
   73cc7:	83 fb 2a             	cmp    ebx,0x2a
   73cca:	88 0a                	mov    BYTE PTR [edx],cl
   73ccc:	74 32                	je     0x73d00
   73cce:	eb 36                	jmp    0x73d06
   73cd0:	80 f9 3f             	cmp    cl,0x3f
   73cd3:	75 02                	jne    0x73cd7
   73cd5:	eb 2d                	jmp    0x73d04
   73cd7:	8a 4e 01             	mov    cl,BYTE PTR [esi+0x1]
   73cda:	46                   	inc    esi
   73cdb:	80 f9 22             	cmp    cl,0x22
   73cde:	75 02                	jne    0x73ce2
   73ce0:	eb 22                	jmp    0x73d04
   73ce2:	c6 02 5c             	mov    BYTE PTR [edx],0x5c
   73ce5:	42                   	inc    edx
   73ce6:	8a 0e                	mov    cl,BYTE PTR [esi]
   73ce8:	0a c9                	or     cl,cl
   73cea:	74 1c                	je     0x73d08
   73cec:	80 f9 20             	cmp    cl,0x20
   73cef:	75 13                	jne    0x73d04
   73cf1:	0b ff                	or     edi,edi
   73cf3:	74 13                	je     0x73d08
   73cf5:	eb 0d                	jmp    0x73d04
   73cf7:	83 ff 01             	cmp    edi,0x1
   73cfa:	1b ff                	sbb    edi,edi
   73cfc:	f7 df                	neg    edi
   73cfe:	eb 07                	jmp    0x73d07
   73d00:	46                   	inc    esi
   73d01:	42                   	inc    edx
   73d02:	8a 0e                	mov    cl,BYTE PTR [esi]
   73d04:	88 0a                	mov    BYTE PTR [edx],cl
   73d06:	42                   	inc    edx
   73d07:	46                   	inc    esi
   73d08:	80 3e 00             	cmp    BYTE PTR [esi],0x0
   73d0b:	75 95                	jne    0x73ca2
   73d0d:	80 3e 00             	cmp    BYTE PTR [esi],0x0
   73d10:	74 01                	je     0x73d13
   73d12:	46                   	inc    esi
   73d13:	c6 02 00             	mov    BYTE PTR [edx],0x0
   73d16:	e9 5b ff ff ff       	jmp    0x73c76
   73d1b:	05 00 00 00 00       	add    eax,0x0
   73d20:	c7 00 00 00 00 00    	mov    DWORD PTR [eax],0x0
   73d26:	5f                   	pop    edi
   73d27:	5e                   	pop    esi
   73d28:	5b                   	pop    ebx
   73d29:	c3                   	ret
   73d2a:	8d                   	.byte 0x8d
