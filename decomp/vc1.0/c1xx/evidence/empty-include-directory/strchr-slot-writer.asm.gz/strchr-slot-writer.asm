
../../../toolchains/1.0-nt/bin/C1XX3232.EXE:     file format pei-i386


Disassembly of section .text:

000814f0 <.text+0x6a4f0>:
   814f0:	c8 00 00 00          	enter  0x0,0x0
   814f4:	57                   	push   edi
   814f5:	8b 7d 08             	mov    edi,DWORD PTR [ebp+0x8]
   814f8:	57                   	push   edi
   814f9:	33 c0                	xor    eax,eax
   814fb:	b9 ff ff ff ff       	mov    ecx,0xffffffff
   81500:	f2 ae                	repnz scas al,BYTE PTR es:[edi]
   81502:	f7 d1                	not    ecx
   81504:	8a 45 0c             	mov    al,BYTE PTR [ebp+0xc]
   81507:	5f                   	pop    edi
   81508:	f2 ae                	repnz scas al,BYTE PTR es:[edi]
   8150a:	4f                   	dec    edi
   8150b:	38 07                	cmp    BYTE PTR [edi],al
   8150d:	74 02                	je     0x81511
   8150f:	33 ff                	xor    edi,edi
   81511:	8b c7                	mov    eax,edi
   81513:	5f                   	pop    edi
   81514:	c9                   	leave
   81515:	c3                   	ret
