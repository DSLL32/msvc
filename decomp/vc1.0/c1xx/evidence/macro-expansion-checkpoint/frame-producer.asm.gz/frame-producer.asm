
../../../toolchains/1.0-nt/bin/C1XX3232.EXE:     file format pei-i386


Disassembly of section .text:

00020c60 <.text+0x9c60>:
   20c60:	a1 80 18 09 00       	mov    eax,ds:0x91880
   20c65:	40                   	inc    eax
   20c66:	a3 80 18 09 00       	mov    ds:0x91880,eax
   20c6b:	3d 00 01 00 00       	cmp    eax,0x100
   20c70:	7c 0f                	jl     0x20c81
   20c72:	6a 09                	push   0x9
   20c74:	e8 07 26 05 00       	call   0x73280
   20c79:	83 c4 04             	add    esp,0x4
   20c7c:	a1 80 18 09 00       	mov    eax,ds:0x91880
   20c81:	a3 80 18 09 00       	mov    ds:0x91880,eax
   20c86:	8b 0d e0 56 09 00    	mov    ecx,DWORD PTR ds:0x956e0
   20c8c:	41                   	inc    ecx
   20c8d:	c1 e0 02             	shl    eax,0x2
   20c90:	89 0d e0 56 09 00    	mov    DWORD PTR ds:0x956e0,ecx
   20c96:	8d 0c 80             	lea    ecx,[eax+eax*4]
   20c99:	8b 44 24 04          	mov    eax,DWORD PTR [esp+0x4]
   20c9d:	89 81 98 57 09 00    	mov    DWORD PTR [ecx+0x95798],eax
   20ca3:	a1 6c 57 09 00       	mov    eax,ds:0x9576c
   20ca8:	89 81 90 57 09 00    	mov    DWORD PTR [ecx+0x95790],eax
   20cae:	a0 70 57 09 00       	mov    al,ds:0x95770
   20cb3:	88 81 9c 57 09 00    	mov    BYTE PTR [ecx+0x9579c],al
   20cb9:	c6 81 9d 57 09 00 00 	mov    BYTE PTR [ecx+0x9579d],0x0
   20cc0:	a1 4c c1 08 00       	mov    eax,ds:0x8c14c
   20cc5:	89 81 8c 57 09 00    	mov    DWORD PTR [ecx+0x9578c],eax
   20ccb:	a1 7c 57 09 00       	mov    eax,ds:0x9577c
   20cd0:	a3 dc 56 09 00       	mov    ds:0x956dc,eax
   20cd5:	89 81 94 57 09 00    	mov    DWORD PTR [ecx+0x95794],eax
   20cdb:	c2 04 00             	ret    0x4
