
../../../toolchains/1.0-nt/bin/C1XX3232.EXE:     file format pei-i386


Disassembly of section .text:

00020090 <.text+0x9090>:
   20090:	53                   	push   ebx
   20091:	56                   	push   esi
   20092:	57                   	push   edi
   20093:	55                   	push   ebp
   20094:	2b ed                	sub    ebp,ebp
   20096:	89 2d e0 56 09 00    	mov    DWORD PTR ds:0x956e0,ebp
   2009c:	a1 dc 56 09 00       	mov    eax,ds:0x956dc
   200a1:	a3 7c 57 09 00       	mov    ds:0x9577c,eax
   200a6:	a1 98 cc 08 00       	mov    eax,ds:0x8cc98
   200ab:	a3 78 57 09 00       	mov    ds:0x95778,eax
   200b0:	8b 7c 24 14          	mov    edi,DWORD PTR [esp+0x14]
   200b4:	a1 80 57 09 00       	mov    eax,ds:0x95780
   200b9:	a3 6c 57 09 00       	mov    ds:0x9576c,eax
   200be:	c7 05 70 57 09 00 00 	mov    DWORD PTR ds:0x95770,0x0
   200c5:	00 00 00 
   200c8:	8a 47 0c             	mov    al,BYTE PTR [edi+0xc]
   200cb:	0f be f0             	movsx  esi,al
   200ce:	3c fe                	cmp    al,0xfe
   200d0:	0f 8d 55 01 00 00    	jge    0x2022b
   200d6:	83 3d 04 c4 08 00 00 	cmp    DWORD PTR ds:0x8c404,0x0
   200dd:	74 06                	je     0x200e5
   200df:	57                   	push   edi
   200e0:	e8 5b c3 00 00       	call   0x2c440
   200e5:	57                   	push   edi
   200e6:	e8 75 0b 00 00       	call   0x20c60
   200eb:	a1 80 18 09 00       	mov    eax,ds:0x91880
   200f0:	c1 e0 02             	shl    eax,0x2
   200f3:	83 c6 09             	add    esi,0x9
   200f6:	8b 84 80 98 57 09 00 	mov    eax,DWORD PTR [eax+eax*4+0x95798]
   200fd:	fe 40 0d             	inc    BYTE PTR [eax+0xd]
   20100:	83 fe 06             	cmp    esi,0x6
   20103:	0f 87 09 01 00 00    	ja     0x20212
   20109:	ff 24 b5 b4 05 02 00 	jmp    DWORD PTR [esi*4+0x205b4]
   20110:	68 40 e5 09 00       	push   0x9e540
   20115:	e9 f3 00 00 00       	jmp    0x2020d
   2011a:	8d 9b 00 00 00 00    	lea    ebx,[ebx+0x0]
   20120:	83 3d 28 f8 09 00 00 	cmp    DWORD PTR ds:0x9f828,0x0
   20127:	75 47                	jne    0x20170
   20129:	e8 72 e2 ff ff       	call   0x1e3a0
   2012e:	50                   	push   eax
   2012f:	e8 1c 44 05 00       	call   0x74550
   20134:	bf c8 18 09 00       	mov    edi,0x918c8
   20139:	8b f0                	mov    esi,eax
   2013b:	b9 06 00 00 00       	mov    ecx,0x6
   20140:	f3 a5                	rep movs DWORD PTR es:[edi],DWORD PTR ds:[esi]
   20142:	a4                   	movs   BYTE PTR es:[edi],BYTE PTR ds:[esi]
   20143:	8d 48 10             	lea    ecx,[eax+0x10]
   20146:	be d3 18 09 00       	mov    esi,0x918d3
   2014b:	8b 11                	mov    edx,DWORD PTR [ecx]
   2014d:	89 16                	mov    DWORD PTR [esi],edx
   2014f:	8b 49 04             	mov    ecx,DWORD PTR [ecx+0x4]
   20152:	89 4e 04             	mov    DWORD PTR [esi+0x4],ecx
   20155:	83 c0 0a             	add    eax,0xa
   20158:	b9 db 18 09 00       	mov    ecx,0x918db
   2015d:	8b 10                	mov    edx,DWORD PTR [eax]
   2015f:	89 11                	mov    DWORD PTR [ecx],edx
   20161:	8a 40 04             	mov    al,BYTE PTR [eax+0x4]
   20164:	88 41 04             	mov    BYTE PTR [ecx+0x4],al
   20167:	c6 05 e0 18 09 00 00 	mov    BYTE PTR ds:0x918e0,0x0
   2016e:	eb 0e                	jmp    0x2017e
   20170:	c6 05 c8 18 09 00 31 	mov    BYTE PTR ds:0x918c8,0x31
   20177:	c6 05 c9 18 09 00 00 	mov    BYTE PTR ds:0x918c9,0x0
   2017e:	68 c8 18 09 00       	push   0x918c8
   20183:	6a 22                	push   0x22
   20185:	e8 56 09 00 00       	call   0x20ae0
   2018a:	e9 83 00 00 00       	jmp    0x20212
   2018f:	90                   	nop
   20190:	68 3c e5 09 00       	push   0x9e53c
   20195:	eb 76                	jmp    0x2020d
   20197:	a1 98 18 09 00       	mov    eax,ds:0x91898
   2019c:	50                   	push   eax
   2019d:	6a 22                	push   0x22
   2019f:	e8 3c 09 00 00       	call   0x20ae0
   201a4:	eb 6c                	jmp    0x20212
   201a6:	a1 a0 18 09 00       	mov    eax,ds:0x918a0
   201ab:	50                   	push   eax
   201ac:	6a 22                	push   0x22
   201ae:	e8 2d 09 00 00       	call   0x20ae0
   201b3:	eb 5d                	jmp    0x20212
   201b5:	83 3d 28 f8 09 00 00 	cmp    DWORD PTR ds:0x9f828,0x0
   201bc:	75 18                	jne    0x201d6
   201be:	a1 50 fc 09 00       	mov    eax,ds:0x9fc50
   201c3:	50                   	push   eax
   201c4:	a1 dc 56 09 00       	mov    eax,ds:0x956dc
   201c9:	50                   	push   eax
   201ca:	e8 e1 eb ff ff       	call   0x1edb0
   201cf:	a3 dc 56 09 00       	mov    ds:0x956dc,eax
   201d4:	eb 3c                	jmp    0x20212
   201d6:	68 30 e5 09 00       	push   0x9e530
   201db:	a1 dc 56 09 00       	mov    eax,ds:0x956dc
   201e0:	50                   	push   eax
   201e1:	e8 ca eb ff ff       	call   0x1edb0
   201e6:	a3 dc 56 09 00       	mov    ds:0x956dc,eax
   201eb:	eb 25                	jmp    0x20212
   201ed:	8d 49 00             	lea    ecx,[ecx+0x0]
   201f0:	a1 98 cc 08 00       	mov    eax,ds:0x8cc98
   201f5:	50                   	push   eax
   201f6:	68 2c e5 09 00       	push   0x9e52c
   201fb:	68 58 c1 08 00       	push   0x8c158
   20200:	e8 cb 34 05 00       	call   0x736d0
   20205:	83 c4 0c             	add    esp,0xc
   20208:	68 58 c1 08 00       	push   0x8c158
   2020d:	e8 fe 09 00 00       	call   0x20c10
   20212:	e8 a9 07 00 00       	call   0x209c0
   20217:	0b c0                	or     eax,eax
   20219:	0f 84 20 01 00 00    	je     0x2033f
   2021f:	b8 01 00 00 00       	mov    eax,0x1
   20224:	5d                   	pop    ebp
   20225:	5f                   	pop    edi
   20226:	5e                   	pop    esi
   20227:	5b                   	pop    ebx
   20228:	c2 04 00             	ret    0x4
   2022b:	0b f6                	or     esi,esi
   2022d:	75 41                	jne    0x20270
   2022f:	bd 01 00 00 00       	mov    ebp,0x1
   20234:	83 3d 04 c4 08 00 00 	cmp    DWORD PTR ds:0x8c404,0x0
   2023b:	74 06                	je     0x20243
   2023d:	57                   	push   edi
   2023e:	e8 fd c1 00 00       	call   0x2c440
   20243:	83 7f 08 00          	cmp    DWORD PTR [edi+0x8],0x0
   20247:	74 17                	je     0x20260
   20249:	57                   	push   edi
   2024a:	e8 11 0a 00 00       	call   0x20c60
   2024f:	e8 8c 0a 00 00       	call   0x20ce0
   20254:	e9 e6 00 00 00       	jmp    0x2033f
   20259:	8d a4 24 00 00 00 00 	lea    esp,[esp+0x0]
   20260:	a1 7c 57 09 00       	mov    eax,ds:0x9577c
   20265:	a3 dc 56 09 00       	mov    ds:0x956dc,eax
   2026a:	e9 d0 00 00 00       	jmp    0x2033f
   2026f:	90                   	nop
   20270:	83 fe ff             	cmp    esi,0xffffffff
   20273:	75 02                	jne    0x20277
   20275:	2b f6                	sub    esi,esi
   20277:	bb 02 00 00 00       	mov    ebx,0x2
   2027c:	8d 64 24 00          	lea    esp,[esp+0x0]
   20280:	e8 bb 0d 00 00       	call   0x21040
   20285:	0b c0                	or     eax,eax
   20287:	0f 84 b2 00 00 00    	je     0x2033f
   2028d:	a1 4c c1 08 00       	mov    eax,ds:0x8c14c
   20292:	8a 00                	mov    al,BYTE PTR [eax]
   20294:	25 ff 00 00 00       	and    eax,0xff
   20299:	38 98 b0 d5 09 00    	cmp    BYTE PTR [eax+0x9d5b0],bl
   2029f:	75 15                	jne    0x202b6
   202a1:	ff 05 4c c1 08 00    	inc    DWORD PTR ds:0x8c14c
   202a7:	e8 74 5c 00 00       	call   0x25f20
   202ac:	0b c0                	or     eax,eax
   202ae:	75 d0                	jne    0x20280
   202b0:	ff 0d 4c c1 08 00    	dec    DWORD PTR ds:0x8c14c
   202b6:	a1 4c c1 08 00       	mov    eax,ds:0x8c14c
   202bb:	8a 00                	mov    al,BYTE PTR [eax]
   202bd:	25 ff 00 00 00       	and    eax,0xff
   202c2:	80 b8 b0 d5 09 00 20 	cmp    BYTE PTR [eax+0x9d5b0],0x20
   202c9:	75 35                	jne    0x20300
   202cb:	bd 01 00 00 00       	mov    ebp,0x1
   202d0:	ff 05 4c c1 08 00    	inc    DWORD PTR ds:0x8c14c
   202d6:	66 81 0d 90 f7 09 00 	or     WORD PTR ds:0x9f790,0x2000
   202dd:	00 20 
   202df:	56                   	push   esi
   202e0:	57                   	push   edi
   202e1:	e8 ea 02 00 00       	call   0x205d0
   202e6:	66 81 25 90 f7 09 00 	and    WORD PTR ds:0x9f790,0xdfff
   202ed:	ff df 
   202ef:	83 3d 04 c4 08 00 00 	cmp    DWORD PTR ds:0x8c404,0x0
   202f6:	74 47                	je     0x2033f
   202f8:	57                   	push   edi
   202f9:	e8 42 c1 00 00       	call   0x2c440
   202fe:	eb 3f                	jmp    0x2033f
   20300:	f6 05 92 f7 09 00 80 	test   BYTE PTR ds:0x9f792,0x80
   20307:	74 1f                	je     0x20328
   20309:	ff 0d 4c c1 08 00    	dec    DWORD PTR ds:0x8c14c
   2030f:	a1 4c c1 08 00       	mov    eax,ds:0x8c14c
   20314:	66 81 25 92 f7 09 00 	and    WORD PTR ds:0x9f792,0xff7f
   2031b:	7f ff 
   2031d:	c6 00 0a             	mov    BYTE PTR [eax],0xa
   20320:	ff 0d 98 cc 08 00    	dec    DWORD PTR ds:0x8cc98
   20326:	eb 17                	jmp    0x2033f
   20328:	83 3d 74 57 09 00 00 	cmp    DWORD PTR ds:0x95774,0x0
   2032f:	74 0e                	je     0x2033f
   20331:	ff 0d 4c c1 08 00    	dec    DWORD PTR ds:0x8c14c
   20337:	a1 4c c1 08 00       	mov    eax,ds:0x8c14c
   2033c:	c6 00 20             	mov    BYTE PTR [eax],0x20
   2033f:	83 3d e0 56 09 00 00 	cmp    DWORD PTR ds:0x956e0,0x0
   20346:	0f 84 76 01 00 00    	je     0x204c2
   2034c:	be 00 80 00 00       	mov    esi,0x8000
   20351:	a1 44 fc 09 00       	mov    eax,ds:0x9fc44
   20356:	03 05 88 18 09 00    	add    eax,DWORD PTR ds:0x91888
   2035c:	83 e8 05             	sub    eax,0x5
   2035f:	3b 05 dc 56 09 00    	cmp    eax,DWORD PTR ds:0x956dc
   20365:	77 07                	ja     0x2036e
   20367:	6a 38                	push   0x38
   20369:	e8 02 0e 00 00       	call   0x21170
   2036e:	a1 4c c1 08 00       	mov    eax,ds:0x8c14c
   20373:	8a 18                	mov    bl,BYTE PTR [eax]
   20375:	33 c0                	xor    eax,eax
   20377:	8a c3                	mov    al,bl
   20379:	ff 05 4c c1 08 00    	inc    DWORD PTR ds:0x8c14c
   2037f:	8a 80 b0 d5 09 00    	mov    al,BYTE PTR [eax+0x9d5b0]
   20385:	25 ff 00 00 00       	and    eax,0xff
   2038a:	83 f8 24             	cmp    eax,0x24
   2038d:	7f 35                	jg     0x203c4
   2038f:	0f 84 3b 01 00 00    	je     0x204d0
   20395:	83 f8 08             	cmp    eax,0x8
   20398:	7f 17                	jg     0x203b1
   2039a:	83 f8 07             	cmp    eax,0x7
   2039d:	7d 63                	jge    0x20402
   2039f:	0b c0                	or     eax,eax
   203a1:	0f 84 cd 01 00 00    	je     0x20574
   203a7:	83 f8 03             	cmp    eax,0x3
   203aa:	74 44                	je     0x203f0
   203ac:	e9 f1 01 00 00       	jmp    0x205a2
   203b1:	83 f8 09             	cmp    eax,0x9
   203b4:	74 71                	je     0x20427
   203b6:	83 f8 1d             	cmp    eax,0x1d
   203b9:	0f 84 93 00 00 00    	je     0x20452
   203bf:	e9 de 01 00 00       	jmp    0x205a2
   203c4:	83 f8 25             	cmp    eax,0x25
   203c7:	0f 84 83 01 00 00    	je     0x20550
   203cd:	83 f8 26             	cmp    eax,0x26
   203d0:	0f 84 8c 01 00 00    	je     0x20562
   203d6:	83 f8 28             	cmp    eax,0x28
   203d9:	0f 84 f1 00 00 00    	je     0x204d0
   203df:	83 f8 2d             	cmp    eax,0x2d
   203e2:	0f 84 e8 00 00 00    	je     0x204d0
   203e8:	e9 b5 01 00 00       	jmp    0x205a2
   203ed:	8d 49 00             	lea    ecx,[ecx+0x0]
   203f0:	e8 8b 0f 00 00       	call   0x21380
   203f5:	a8 50                	test   al,0x50
   203f7:	0f 84 b8 00 00 00    	je     0x204b5
   203fd:	e9 a0 01 00 00       	jmp    0x205a2
   20402:	53                   	push   ebx
   20403:	a1 44 fc 09 00       	mov    eax,ds:0x9fc44
   20408:	03 05 88 18 09 00    	add    eax,DWORD PTR ds:0x91888
   2040e:	83 e8 05             	sub    eax,0x5
   20411:	50                   	push   eax
   20412:	a1 dc 56 09 00       	mov    eax,ds:0x956dc
   20417:	50                   	push   eax
   20418:	e8 83 fb ff ff       	call   0x1ffa0
   2041d:	a3 dc 56 09 00       	mov    ds:0x956dc,eax
   20422:	e9 8e 00 00 00       	jmp    0x204b5
   20427:	a1 4c c1 08 00       	mov    eax,ds:0x8c14c
   2042c:	8a 00                	mov    al,BYTE PTR [eax]
   2042e:	25 ff 00 00 00       	and    eax,0xff
   20433:	f6 80 b0 d6 09 00 04 	test   BYTE PTR [eax+0x9d6b0],0x4
   2043a:	75 14                	jne    0x20450
   2043c:	a1 dc 56 09 00       	mov    eax,ds:0x956dc
   20441:	c6 00 2e             	mov    BYTE PTR [eax],0x2e
   20444:	ff 05 dc 56 09 00    	inc    DWORD PTR ds:0x956dc
   2044a:	eb 69                	jmp    0x204b5
   2044c:	8d 64 24 00          	lea    esp,[esp+0x0]
   20450:	b3 2e                	mov    bl,0x2e
   20452:	a1 dc 56 09 00       	mov    eax,ds:0x956dc
   20457:	88 18                	mov    BYTE PTR [eax],bl
   20459:	ff 05 dc 56 09 00    	inc    DWORD PTR ds:0x956dc
   2045f:	a1 44 fc 09 00       	mov    eax,ds:0x9fc44
   20464:	03 05 88 18 09 00    	add    eax,DWORD PTR ds:0x91888
   2046a:	83 e8 05             	sub    eax,0x5
   2046d:	3b 05 dc 56 09 00    	cmp    eax,DWORD PTR ds:0x956dc
   20473:	77 07                	ja     0x2047c
   20475:	6a 38                	push   0x38
   20477:	e8 f4 0c 00 00       	call   0x21170
   2047c:	a1 4c c1 08 00       	mov    eax,ds:0x8c14c
   20481:	8a 18                	mov    bl,BYTE PTR [eax]
   20483:	33 c0                	xor    eax,eax
   20485:	8a c3                	mov    al,bl
   20487:	ff 05 4c c1 08 00    	inc    DWORD PTR ds:0x8c14c
   2048d:	f6 80 b0 d6 09 00 01 	test   BYTE PTR [eax+0x9d6b0],0x1
   20494:	75 bc                	jne    0x20452
   20496:	80 fb 2b             	cmp    bl,0x2b
   20499:	74 05                	je     0x204a0
   2049b:	80 fb 2d             	cmp    bl,0x2d
   2049e:	75 0f                	jne    0x204af
   204a0:	a1 dc 56 09 00       	mov    eax,ds:0x956dc
   204a5:	8a 00                	mov    al,BYTE PTR [eax]
   204a7:	3c 65                	cmp    al,0x65
   204a9:	74 a7                	je     0x20452
   204ab:	3c 45                	cmp    al,0x45
   204ad:	74 a3                	je     0x20452
   204af:	ff 0d 4c c1 08 00    	dec    DWORD PTR ds:0x8c14c
   204b5:	83 3d e0 56 09 00 00 	cmp    DWORD PTR ds:0x956e0,0x0
   204bc:	0f 85 8f fe ff ff    	jne    0x20351
   204c2:	8b c5                	mov    eax,ebp
   204c4:	5d                   	pop    ebp
   204c5:	5f                   	pop    edi
   204c6:	5e                   	pop    esi
   204c7:	5b                   	pop    ebx
   204c8:	c2 04 00             	ret    0x4
   204cb:	05 00 00 00 00       	add    eax,0x0
   204d0:	a1 dc 56 09 00       	mov    eax,ds:0x956dc
   204d5:	a3 7c 57 09 00       	mov    ds:0x9577c,eax
   204da:	53                   	push   ebx
   204db:	e8 60 09 00 00       	call   0x20e40
   204e0:	0b c0                	or     eax,eax
   204e2:	74 42                	je     0x20526
   204e4:	e8 a7 f5 ff ff       	call   0x1fa90
   204e9:	8b f8                	mov    edi,eax
   204eb:	0b ff                	or     edi,edi
   204ed:	74 37                	je     0x20526
   204ef:	80 7f 0d 00          	cmp    BYTE PTR [edi+0xd],0x0
   204f3:	0f 84 bb fb ff ff    	je     0x200b4
   204f9:	8b 3d 04 f2 09 00    	mov    edi,DWORD PTR ds:0x9f204
   204ff:	b9 ff ff ff ff       	mov    ecx,0xffffffff
   20504:	2b c0                	sub    eax,eax
   20506:	f2 ae                	repnz scas al,BYTE PTR es:[edi]
   20508:	f7 d1                	not    ecx
   2050a:	a1 dc 56 09 00       	mov    eax,ds:0x956dc
   2050f:	49                   	dec    ecx
   20510:	c6 00 04             	mov    BYTE PTR [eax],0x4
   20513:	ff 05 dc 56 09 00    	inc    DWORD PTR ds:0x956dc
   20519:	a1 dc 56 09 00       	mov    eax,ds:0x956dc
   2051e:	88 08                	mov    BYTE PTR [eax],cl
   20520:	ff 05 dc 56 09 00    	inc    DWORD PTR ds:0x956dc
   20526:	66 85 35 90 f7 09 00 	test   WORD PTR ds:0x9f790,si
   2052d:	74 86                	je     0x204b5
   2052f:	a1 04 f2 09 00       	mov    eax,ds:0x9f204
   20534:	39 05 24 f2 09 00    	cmp    DWORD PTR ds:0x9f224,eax
   2053a:	0f 85 75 ff ff ff    	jne    0x204b5
   20540:	50                   	push   eax
   20541:	e8 0a 40 00 00       	call   0x24550
   20546:	e9 6a ff ff ff       	jmp    0x204b5
   2054b:	05 00 00 00 00       	add    eax,0x0
   20550:	e8 ab 0a 00 00       	call   0x21000
   20555:	50                   	push   eax
   20556:	6a 22                	push   0x22
   20558:	e8 83 05 00 00       	call   0x20ae0
   2055d:	e9 53 ff ff ff       	jmp    0x204b5
   20562:	e8 99 0a 00 00       	call   0x21000
   20567:	50                   	push   eax
   20568:	6a 27                	push   0x27
   2056a:	e8 71 05 00 00       	call   0x20ae0
   2056f:	e9 41 ff ff ff       	jmp    0x204b5
   20574:	b9 40 00 00 00       	mov    ecx,0x40
   20579:	8d a4 24 00 00 00 00 	lea    esp,[esp+0x0]
   20580:	a1 4c c1 08 00       	mov    eax,ds:0x8c14c
   20585:	ff 05 4c c1 08 00    	inc    DWORD PTR ds:0x8c14c
   2058b:	8a 00                	mov    al,BYTE PTR [eax]
   2058d:	25 ff 00 00 00       	and    eax,0xff
   20592:	84 88 b0 d6 09 00    	test   BYTE PTR [eax+0x9d6b0],cl
   20598:	75 e6                	jne    0x20580
   2059a:	ff 0d 4c c1 08 00    	dec    DWORD PTR ds:0x8c14c
   205a0:	b3 20                	mov    bl,0x20
   205a2:	a1 dc 56 09 00       	mov    eax,ds:0x956dc
   205a7:	88 18                	mov    BYTE PTR [eax],bl
   205a9:	ff 05 dc 56 09 00    	inc    DWORD PTR ds:0x956dc
   205af:	e9 01 ff ff ff       	jmp    0x204b5
   205b4:	10 01                	adc    BYTE PTR [ecx],al
   205b6:	02 00                	add    al,BYTE PTR [eax]
   205b8:	20 01                	and    BYTE PTR [ecx],al
   205ba:	02 00                	add    al,BYTE PTR [eax]
   205bc:	90                   	nop
   205bd:	01 02                	add    DWORD PTR [edx],eax
   205bf:	00 97 01 02 00 a6    	add    BYTE PTR [edi-0x59fffdff],dl
   205c5:	01 02                	add    DWORD PTR [edx],eax
   205c7:	00 b5 01 02 00 f0    	add    BYTE PTR [ebp-0xffffdff],dh
   205cd:	01 02                	add    DWORD PTR [edx],eax
	...
